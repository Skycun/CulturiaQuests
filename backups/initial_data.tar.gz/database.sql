--
-- PostgreSQL database dump
--

\restrict 1Q6FpTmzVorBwVFNMr10zIIXpsCgrR9d8MNjDefQhcFeWj3schANdMJfTyEskkj

-- Dumped from database version 14.20
-- Dumped by pg_dump version 14.20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    action_parameters jsonb,
    subject character varying(255),
    properties jsonb,
    conditions jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_permissions OWNER TO strapi;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_permissions_id_seq OWNER TO strapi;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_permissions_id_seq OWNED BY public.admin_permissions.id;


--
-- Name: admin_permissions_role_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.admin_permissions_role_lnk OWNER TO strapi;

--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_permissions_role_lnk_id_seq OWNER TO strapi;

--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_permissions_role_lnk_id_seq OWNED BY public.admin_permissions_role_lnk.id;


--
-- Name: admin_roles; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    description character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_roles OWNER TO strapi;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_roles_id_seq OWNER TO strapi;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_roles_id_seq OWNED BY public.admin_roles.id;


--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    document_id character varying(255),
    firstname character varying(255),
    lastname character varying(255),
    username character varying(255),
    email character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    registration_token character varying(255),
    is_active boolean,
    blocked boolean,
    prefered_language character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_users OWNER TO strapi;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_id_seq OWNER TO strapi;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: admin_users_roles_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.admin_users_roles_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    role_ord double precision,
    user_ord double precision
);


ALTER TABLE public.admin_users_roles_lnk OWNER TO strapi;

--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.admin_users_roles_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_roles_lnk_id_seq OWNER TO strapi;

--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.admin_users_roles_lnk_id_seq OWNED BY public.admin_users_roles_lnk.id;


--
-- Name: characters; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.characters (
    id integer NOT NULL,
    document_id character varying(255),
    firstname character varying(255),
    lastname character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.characters OWNER TO strapi;

--
-- Name: characters_guild_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.characters_guild_lnk (
    id integer NOT NULL,
    character_id integer,
    guild_id integer,
    character_ord double precision
);


ALTER TABLE public.characters_guild_lnk OWNER TO strapi;

--
-- Name: characters_guild_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.characters_guild_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.characters_guild_lnk_id_seq OWNER TO strapi;

--
-- Name: characters_guild_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.characters_guild_lnk_id_seq OWNED BY public.characters_guild_lnk.id;


--
-- Name: characters_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.characters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.characters_id_seq OWNER TO strapi;

--
-- Name: characters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.characters_id_seq OWNED BY public.characters.id;


--
-- Name: dialogs; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.dialogs (
    id integer NOT NULL,
    document_id character varying(255),
    text_type character varying(255),
    dialogues jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.dialogs OWNER TO strapi;

--
-- Name: dialogs_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.dialogs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dialogs_id_seq OWNER TO strapi;

--
-- Name: dialogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.dialogs_id_seq OWNED BY public.dialogs.id;


--
-- Name: dialogs_npc_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.dialogs_npc_lnk (
    id integer NOT NULL,
    dialog_id integer,
    npc_id integer,
    dialog_ord double precision
);


ALTER TABLE public.dialogs_npc_lnk OWNER TO strapi;

--
-- Name: dialogs_npc_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.dialogs_npc_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dialogs_npc_lnk_id_seq OWNER TO strapi;

--
-- Name: dialogs_npc_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.dialogs_npc_lnk_id_seq OWNED BY public.dialogs_npc_lnk.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.files (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    alternative_text character varying(255),
    caption character varying(255),
    width integer,
    height integer,
    formats jsonb,
    hash character varying(255),
    ext character varying(255),
    mime character varying(255),
    size numeric(10,2),
    url character varying(255),
    preview_url character varying(255),
    provider character varying(255),
    provider_metadata jsonb,
    folder_path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.files OWNER TO strapi;

--
-- Name: files_folder_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.files_folder_lnk (
    id integer NOT NULL,
    file_id integer,
    folder_id integer,
    file_ord double precision
);


ALTER TABLE public.files_folder_lnk OWNER TO strapi;

--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.files_folder_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_folder_lnk_id_seq OWNER TO strapi;

--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.files_folder_lnk_id_seq OWNED BY public.files_folder_lnk.id;


--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_id_seq OWNER TO strapi;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: files_related_mph; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.files_related_mph (
    id integer NOT NULL,
    file_id integer,
    related_id integer,
    related_type character varying(255),
    field character varying(255),
    "order" double precision
);


ALTER TABLE public.files_related_mph OWNER TO strapi;

--
-- Name: files_related_mph_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.files_related_mph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_related_mph_id_seq OWNER TO strapi;

--
-- Name: files_related_mph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.files_related_mph_id_seq OWNED BY public.files_related_mph.id;


--
-- Name: friendships; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.friendships (
    id integer NOT NULL,
    document_id character varying(255),
    quests_entry_unlocked integer,
    expedition_entry_unlocked integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.friendships OWNER TO strapi;

--
-- Name: friendships_guild_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.friendships_guild_lnk (
    id integer NOT NULL,
    friendship_id integer,
    guild_id integer,
    friendship_ord double precision
);


ALTER TABLE public.friendships_guild_lnk OWNER TO strapi;

--
-- Name: friendships_guild_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.friendships_guild_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.friendships_guild_lnk_id_seq OWNER TO strapi;

--
-- Name: friendships_guild_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.friendships_guild_lnk_id_seq OWNED BY public.friendships_guild_lnk.id;


--
-- Name: friendships_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.friendships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.friendships_id_seq OWNER TO strapi;

--
-- Name: friendships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.friendships_id_seq OWNED BY public.friendships.id;


--
-- Name: friendships_npc_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.friendships_npc_lnk (
    id integer NOT NULL,
    friendship_id integer,
    npc_id integer,
    friendship_ord double precision
);


ALTER TABLE public.friendships_npc_lnk OWNER TO strapi;

--
-- Name: friendships_npc_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.friendships_npc_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.friendships_npc_lnk_id_seq OWNER TO strapi;

--
-- Name: friendships_npc_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.friendships_npc_lnk_id_seq OWNED BY public.friendships_npc_lnk.id;


--
-- Name: guilds; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.guilds (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    gold integer,
    exp bigint,
    scrap integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.guilds OWNER TO strapi;

--
-- Name: guilds_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.guilds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guilds_id_seq OWNER TO strapi;

--
-- Name: guilds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.guilds_id_seq OWNED BY public.guilds.id;


--
-- Name: guilds_user_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.guilds_user_lnk (
    id integer NOT NULL,
    guild_id integer,
    user_id integer
);


ALTER TABLE public.guilds_user_lnk OWNER TO strapi;

--
-- Name: guilds_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.guilds_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guilds_user_lnk_id_seq OWNER TO strapi;

--
-- Name: guilds_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.guilds_user_lnk_id_seq OWNED BY public.guilds_user_lnk.id;


--
-- Name: i18n_locale; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.i18n_locale (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.i18n_locale OWNER TO strapi;

--
-- Name: i18n_locale_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.i18n_locale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.i18n_locale_id_seq OWNER TO strapi;

--
-- Name: i18n_locale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.i18n_locale_id_seq OWNED BY public.i18n_locale.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.items (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    level integer,
    index_damage integer,
    slot character varying(255),
    is_scrapped boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.items OWNER TO strapi;

--
-- Name: items_character_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.items_character_lnk (
    id integer NOT NULL,
    item_id integer,
    character_id integer,
    item_ord double precision
);


ALTER TABLE public.items_character_lnk OWNER TO strapi;

--
-- Name: items_character_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.items_character_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_character_lnk_id_seq OWNER TO strapi;

--
-- Name: items_character_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.items_character_lnk_id_seq OWNED BY public.items_character_lnk.id;


--
-- Name: items_guild_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.items_guild_lnk (
    id integer NOT NULL,
    item_id integer,
    guild_id integer,
    item_ord double precision
);


ALTER TABLE public.items_guild_lnk OWNER TO strapi;

--
-- Name: items_guild_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.items_guild_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_guild_lnk_id_seq OWNER TO strapi;

--
-- Name: items_guild_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.items_guild_lnk_id_seq OWNED BY public.items_guild_lnk.id;


--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_id_seq OWNER TO strapi;

--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: items_rarity_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.items_rarity_lnk (
    id integer NOT NULL,
    item_id integer,
    rarity_id integer,
    item_ord double precision
);


ALTER TABLE public.items_rarity_lnk OWNER TO strapi;

--
-- Name: items_rarity_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.items_rarity_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_rarity_lnk_id_seq OWNER TO strapi;

--
-- Name: items_rarity_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.items_rarity_lnk_id_seq OWNED BY public.items_rarity_lnk.id;


--
-- Name: items_runs_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.items_runs_lnk (
    id integer NOT NULL,
    item_id integer,
    run_id integer,
    run_ord double precision,
    item_ord double precision
);


ALTER TABLE public.items_runs_lnk OWNER TO strapi;

--
-- Name: items_runs_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.items_runs_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_runs_lnk_id_seq OWNER TO strapi;

--
-- Name: items_runs_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.items_runs_lnk_id_seq OWNED BY public.items_runs_lnk.id;


--
-- Name: items_tags_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.items_tags_lnk (
    id integer NOT NULL,
    item_id integer,
    tag_id integer,
    tag_ord double precision,
    item_ord double precision
);


ALTER TABLE public.items_tags_lnk OWNER TO strapi;

--
-- Name: items_tags_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.items_tags_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_tags_lnk_id_seq OWNER TO strapi;

--
-- Name: items_tags_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.items_tags_lnk_id_seq OWNED BY public.items_tags_lnk.id;


--
-- Name: items_visits_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.items_visits_lnk (
    id integer NOT NULL,
    item_id integer,
    visit_id integer,
    visit_ord double precision,
    item_ord double precision
);


ALTER TABLE public.items_visits_lnk OWNER TO strapi;

--
-- Name: items_visits_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.items_visits_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_visits_lnk_id_seq OWNER TO strapi;

--
-- Name: items_visits_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.items_visits_lnk_id_seq OWNED BY public.items_visits_lnk.id;


--
-- Name: museums; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.museums (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    lat double precision,
    lng double precision,
    geohash character varying(255),
    location jsonb,
    radius integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.museums OWNER TO strapi;

--
-- Name: museums_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.museums_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.museums_id_seq OWNER TO strapi;

--
-- Name: museums_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.museums_id_seq OWNED BY public.museums.id;


--
-- Name: museums_tags_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.museums_tags_lnk (
    id integer NOT NULL,
    museum_id integer,
    tag_id integer,
    tag_ord double precision,
    museum_ord double precision
);


ALTER TABLE public.museums_tags_lnk OWNER TO strapi;

--
-- Name: museums_tags_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.museums_tags_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.museums_tags_lnk_id_seq OWNER TO strapi;

--
-- Name: museums_tags_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.museums_tags_lnk_id_seq OWNED BY public.museums_tags_lnk.id;


--
-- Name: npcs; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.npcs (
    id integer NOT NULL,
    document_id character varying(255),
    firstname character varying(255),
    lastname character varying(255),
    pronouns character varying(255),
    quests_entry_available integer,
    expedition_entry_available integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.npcs OWNER TO strapi;

--
-- Name: npcs_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.npcs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.npcs_id_seq OWNER TO strapi;

--
-- Name: npcs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.npcs_id_seq OWNED BY public.npcs.id;


--
-- Name: pois; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.pois (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    lat double precision,
    lng double precision,
    geohash character varying(255),
    location jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.pois OWNER TO strapi;

--
-- Name: pois_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.pois_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pois_id_seq OWNER TO strapi;

--
-- Name: pois_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.pois_id_seq OWNED BY public.pois.id;


--
-- Name: quests; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.quests (
    id integer NOT NULL,
    document_id character varying(255),
    is_poi_a_completed boolean,
    is_poi_b_completed boolean,
    date_start timestamp(6) without time zone,
    date_end timestamp(6) without time zone,
    gold_earned integer,
    xp_earned integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.quests OWNER TO strapi;

--
-- Name: quests_guild_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.quests_guild_lnk (
    id integer NOT NULL,
    quest_id integer,
    guild_id integer,
    quest_ord double precision
);


ALTER TABLE public.quests_guild_lnk OWNER TO strapi;

--
-- Name: quests_guild_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.quests_guild_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quests_guild_lnk_id_seq OWNER TO strapi;

--
-- Name: quests_guild_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.quests_guild_lnk_id_seq OWNED BY public.quests_guild_lnk.id;


--
-- Name: quests_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.quests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quests_id_seq OWNER TO strapi;

--
-- Name: quests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.quests_id_seq OWNED BY public.quests.id;


--
-- Name: quests_npc_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.quests_npc_lnk (
    id integer NOT NULL,
    quest_id integer,
    npc_id integer,
    quest_ord double precision
);


ALTER TABLE public.quests_npc_lnk OWNER TO strapi;

--
-- Name: quests_npc_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.quests_npc_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quests_npc_lnk_id_seq OWNER TO strapi;

--
-- Name: quests_npc_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.quests_npc_lnk_id_seq OWNED BY public.quests_npc_lnk.id;


--
-- Name: quests_poi_a_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.quests_poi_a_lnk (
    id integer NOT NULL,
    quest_id integer,
    poi_id integer,
    quest_ord double precision
);


ALTER TABLE public.quests_poi_a_lnk OWNER TO strapi;

--
-- Name: quests_poi_a_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.quests_poi_a_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quests_poi_a_lnk_id_seq OWNER TO strapi;

--
-- Name: quests_poi_a_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.quests_poi_a_lnk_id_seq OWNED BY public.quests_poi_a_lnk.id;


--
-- Name: quests_poi_b_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.quests_poi_b_lnk (
    id integer NOT NULL,
    quest_id integer,
    poi_id integer,
    quest_ord double precision
);


ALTER TABLE public.quests_poi_b_lnk OWNER TO strapi;

--
-- Name: quests_poi_b_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.quests_poi_b_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quests_poi_b_lnk_id_seq OWNER TO strapi;

--
-- Name: quests_poi_b_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.quests_poi_b_lnk_id_seq OWNED BY public.quests_poi_b_lnk.id;


--
-- Name: rarities; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.rarities (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.rarities OWNER TO strapi;

--
-- Name: rarities_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.rarities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rarities_id_seq OWNER TO strapi;

--
-- Name: rarities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.rarities_id_seq OWNED BY public.rarities.id;


--
-- Name: runs; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.runs (
    id integer NOT NULL,
    document_id character varying(255),
    dps integer,
    date_start timestamp(6) without time zone,
    date_end timestamp(6) without time zone,
    gold_earned integer,
    xp_earned integer,
    threshold_reached integer,
    target_threshold integer,
    entry_unlocked boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.runs OWNER TO strapi;

--
-- Name: runs_guild_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.runs_guild_lnk (
    id integer NOT NULL,
    run_id integer,
    guild_id integer,
    run_ord double precision
);


ALTER TABLE public.runs_guild_lnk OWNER TO strapi;

--
-- Name: runs_guild_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.runs_guild_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.runs_guild_lnk_id_seq OWNER TO strapi;

--
-- Name: runs_guild_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.runs_guild_lnk_id_seq OWNED BY public.runs_guild_lnk.id;


--
-- Name: runs_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.runs_id_seq OWNER TO strapi;

--
-- Name: runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.runs_id_seq OWNED BY public.runs.id;


--
-- Name: runs_museum_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.runs_museum_lnk (
    id integer NOT NULL,
    run_id integer,
    museum_id integer,
    run_ord double precision
);


ALTER TABLE public.runs_museum_lnk OWNER TO strapi;

--
-- Name: runs_museum_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.runs_museum_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.runs_museum_lnk_id_seq OWNER TO strapi;

--
-- Name: runs_museum_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.runs_museum_lnk_id_seq OWNED BY public.runs_museum_lnk.id;


--
-- Name: runs_npc_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.runs_npc_lnk (
    id integer NOT NULL,
    run_id integer,
    npc_id integer,
    run_ord double precision
);


ALTER TABLE public.runs_npc_lnk OWNER TO strapi;

--
-- Name: runs_npc_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.runs_npc_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.runs_npc_lnk_id_seq OWNER TO strapi;

--
-- Name: runs_npc_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.runs_npc_lnk_id_seq OWNED BY public.runs_npc_lnk.id;


--
-- Name: strapi_ai_localization_jobs; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_ai_localization_jobs (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255) NOT NULL,
    source_locale character varying(255) NOT NULL,
    target_locales jsonb NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone
);


ALTER TABLE public.strapi_ai_localization_jobs OWNER TO strapi;

--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_ai_localization_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_ai_localization_jobs_id_seq OWNER TO strapi;

--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_ai_localization_jobs_id_seq OWNED BY public.strapi_ai_localization_jobs.id;


--
-- Name: strapi_api_token_permissions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_api_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_token_permissions OWNER TO strapi;

--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_api_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_api_token_permissions_id_seq OWNER TO strapi;

--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_api_token_permissions_id_seq OWNED BY public.strapi_api_token_permissions.id;


--
-- Name: strapi_api_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_api_token_permissions_token_lnk (
    id integer NOT NULL,
    api_token_permission_id integer,
    api_token_id integer,
    api_token_permission_ord double precision
);


ALTER TABLE public.strapi_api_token_permissions_token_lnk OWNER TO strapi;

--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_api_token_permissions_token_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq OWNED BY public.strapi_api_token_permissions_token_lnk.id;


--
-- Name: strapi_api_tokens; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_api_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    access_key character varying(255),
    encrypted_key text,
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_tokens OWNER TO strapi;

--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_api_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_api_tokens_id_seq OWNER TO strapi;

--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_api_tokens_id_seq OWNED BY public.strapi_api_tokens.id;


--
-- Name: strapi_core_store_settings; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_core_store_settings (
    id integer NOT NULL,
    key character varying(255),
    value text,
    type character varying(255),
    environment character varying(255),
    tag character varying(255)
);


ALTER TABLE public.strapi_core_store_settings OWNER TO strapi;

--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_core_store_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_core_store_settings_id_seq OWNER TO strapi;

--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_core_store_settings_id_seq OWNED BY public.strapi_core_store_settings.id;


--
-- Name: strapi_database_schema; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_database_schema (
    id integer NOT NULL,
    schema json,
    "time" timestamp without time zone,
    hash character varying(255)
);


ALTER TABLE public.strapi_database_schema OWNER TO strapi;

--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_database_schema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_database_schema_id_seq OWNER TO strapi;

--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_database_schema_id_seq OWNED BY public.strapi_database_schema.id;


--
-- Name: strapi_history_versions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_history_versions (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255),
    locale character varying(255),
    status character varying(255),
    data jsonb,
    schema jsonb,
    created_at timestamp(6) without time zone,
    created_by_id integer
);


ALTER TABLE public.strapi_history_versions OWNER TO strapi;

--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_history_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_history_versions_id_seq OWNER TO strapi;

--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_history_versions_id_seq OWNED BY public.strapi_history_versions.id;


--
-- Name: strapi_migrations; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_migrations (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations OWNER TO strapi;

--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_migrations_id_seq OWNER TO strapi;

--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_migrations_id_seq OWNED BY public.strapi_migrations.id;


--
-- Name: strapi_migrations_internal; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_migrations_internal (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations_internal OWNER TO strapi;

--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_migrations_internal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_migrations_internal_id_seq OWNER TO strapi;

--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_migrations_internal_id_seq OWNED BY public.strapi_migrations_internal.id;


--
-- Name: strapi_release_actions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_release_actions (
    id integer NOT NULL,
    document_id character varying(255),
    type character varying(255),
    content_type character varying(255),
    entry_document_id character varying(255),
    locale character varying(255),
    is_entry_valid boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer
);


ALTER TABLE public.strapi_release_actions OWNER TO strapi;

--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_release_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_release_actions_id_seq OWNER TO strapi;

--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_release_actions_id_seq OWNED BY public.strapi_release_actions.id;


--
-- Name: strapi_release_actions_release_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_release_actions_release_lnk (
    id integer NOT NULL,
    release_action_id integer,
    release_id integer,
    release_action_ord double precision
);


ALTER TABLE public.strapi_release_actions_release_lnk OWNER TO strapi;

--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_release_actions_release_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_release_actions_release_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_release_actions_release_lnk_id_seq OWNED BY public.strapi_release_actions_release_lnk.id;


--
-- Name: strapi_releases; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_releases (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    released_at timestamp(6) without time zone,
    scheduled_at timestamp(6) without time zone,
    timezone character varying(255),
    status character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_releases OWNER TO strapi;

--
-- Name: strapi_releases_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_releases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_releases_id_seq OWNER TO strapi;

--
-- Name: strapi_releases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_releases_id_seq OWNED BY public.strapi_releases.id;


--
-- Name: strapi_sessions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_sessions (
    id integer NOT NULL,
    document_id character varying(255),
    user_id character varying(255),
    session_id character varying(255),
    child_id character varying(255),
    device_id character varying(255),
    origin character varying(255),
    expires_at timestamp(6) without time zone,
    absolute_expires_at timestamp(6) without time zone,
    status character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_sessions OWNER TO strapi;

--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_sessions_id_seq OWNER TO strapi;

--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_sessions_id_seq OWNED BY public.strapi_sessions.id;


--
-- Name: strapi_transfer_token_permissions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_transfer_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_token_permissions OWNER TO strapi;

--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_transfer_token_permissions_id_seq OWNER TO strapi;

--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_id_seq OWNED BY public.strapi_transfer_token_permissions.id;


--
-- Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_transfer_token_permissions_token_lnk (
    id integer NOT NULL,
    transfer_token_permission_id integer,
    transfer_token_id integer,
    transfer_token_permission_ord double precision
);


ALTER TABLE public.strapi_transfer_token_permissions_token_lnk OWNER TO strapi;

--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNED BY public.strapi_transfer_token_permissions_token_lnk.id;


--
-- Name: strapi_transfer_tokens; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_transfer_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    access_key character varying(255),
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_tokens OWNER TO strapi;

--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_transfer_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_transfer_tokens_id_seq OWNER TO strapi;

--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_transfer_tokens_id_seq OWNED BY public.strapi_transfer_tokens.id;


--
-- Name: strapi_webhooks; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_webhooks (
    id integer NOT NULL,
    name character varying(255),
    url text,
    headers jsonb,
    events jsonb,
    enabled boolean
);


ALTER TABLE public.strapi_webhooks OWNER TO strapi;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_webhooks_id_seq OWNER TO strapi;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_webhooks_id_seq OWNED BY public.strapi_webhooks.id;


--
-- Name: strapi_workflows; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    content_types jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows OWNER TO strapi;

--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_id_seq OWNED BY public.strapi_workflows.id;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows_stage_required_to_publish_lnk (
    id integer NOT NULL,
    workflow_id integer,
    workflow_stage_id integer
);


ALTER TABLE public.strapi_workflows_stage_required_to_publish_lnk OWNER TO strapi;

--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNED BY public.strapi_workflows_stage_required_to_publish_lnk.id;


--
-- Name: strapi_workflows_stages; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows_stages (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    color character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows_stages OWNER TO strapi;

--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_stages_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_stages_id_seq OWNED BY public.strapi_workflows_stages.id;


--
-- Name: strapi_workflows_stages_permissions_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows_stages_permissions_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    permission_id integer,
    permission_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_permissions_lnk OWNER TO strapi;

--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_stages_permissions_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq OWNED BY public.strapi_workflows_stages_permissions_lnk.id;


--
-- Name: strapi_workflows_stages_workflow_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.strapi_workflows_stages_workflow_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    workflow_id integer,
    workflow_stage_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_workflow_lnk OWNER TO strapi;

--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strapi_workflows_stages_workflow_lnk_id_seq OWNER TO strapi;

--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq OWNED BY public.strapi_workflows_stages_workflow_lnk.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.tags OWNER TO strapi;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_id_seq OWNER TO strapi;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: up_permissions; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_permissions OWNER TO strapi;

--
-- Name: up_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_permissions_id_seq OWNER TO strapi;

--
-- Name: up_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_permissions_id_seq OWNED BY public.up_permissions.id;


--
-- Name: up_permissions_role_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.up_permissions_role_lnk OWNER TO strapi;

--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_permissions_role_lnk_id_seq OWNER TO strapi;

--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_permissions_role_lnk_id_seq OWNED BY public.up_permissions_role_lnk.id;


--
-- Name: up_roles; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_roles OWNER TO strapi;

--
-- Name: up_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_roles_id_seq OWNER TO strapi;

--
-- Name: up_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_roles_id_seq OWNED BY public.up_roles.id;


--
-- Name: up_users; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_users (
    id integer NOT NULL,
    document_id character varying(255),
    username character varying(255),
    email character varying(255),
    provider character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    confirmation_token character varying(255),
    confirmed boolean,
    blocked boolean,
    age integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_users OWNER TO strapi;

--
-- Name: up_users_guild_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_users_guild_lnk (
    id integer NOT NULL,
    user_id integer,
    guild_id integer
);


ALTER TABLE public.up_users_guild_lnk OWNER TO strapi;

--
-- Name: up_users_guild_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_users_guild_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_users_guild_lnk_id_seq OWNER TO strapi;

--
-- Name: up_users_guild_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_users_guild_lnk_id_seq OWNED BY public.up_users_guild_lnk.id;


--
-- Name: up_users_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_users_id_seq OWNER TO strapi;

--
-- Name: up_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_users_id_seq OWNED BY public.up_users.id;


--
-- Name: up_users_role_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.up_users_role_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    user_ord double precision
);


ALTER TABLE public.up_users_role_lnk OWNER TO strapi;

--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.up_users_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.up_users_role_lnk_id_seq OWNER TO strapi;

--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.up_users_role_lnk_id_seq OWNED BY public.up_users_role_lnk.id;


--
-- Name: upload_folders; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.upload_folders (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    path_id integer,
    path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.upload_folders OWNER TO strapi;

--
-- Name: upload_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.upload_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.upload_folders_id_seq OWNER TO strapi;

--
-- Name: upload_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.upload_folders_id_seq OWNED BY public.upload_folders.id;


--
-- Name: upload_folders_parent_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.upload_folders_parent_lnk (
    id integer NOT NULL,
    folder_id integer,
    inv_folder_id integer,
    folder_ord double precision
);


ALTER TABLE public.upload_folders_parent_lnk OWNER TO strapi;

--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.upload_folders_parent_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.upload_folders_parent_lnk_id_seq OWNER TO strapi;

--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.upload_folders_parent_lnk_id_seq OWNED BY public.upload_folders_parent_lnk.id;


--
-- Name: visits; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.visits (
    id integer NOT NULL,
    document_id character varying(255),
    open_count integer,
    last_opened_at timestamp(6) without time zone,
    total_gold_earned integer,
    total_exp_earned integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.visits OWNER TO strapi;

--
-- Name: visits_guild_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.visits_guild_lnk (
    id integer NOT NULL,
    visit_id integer,
    guild_id integer,
    visit_ord double precision
);


ALTER TABLE public.visits_guild_lnk OWNER TO strapi;

--
-- Name: visits_guild_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.visits_guild_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visits_guild_lnk_id_seq OWNER TO strapi;

--
-- Name: visits_guild_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.visits_guild_lnk_id_seq OWNED BY public.visits_guild_lnk.id;


--
-- Name: visits_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.visits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visits_id_seq OWNER TO strapi;

--
-- Name: visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.visits_id_seq OWNED BY public.visits.id;


--
-- Name: visits_poi_lnk; Type: TABLE; Schema: public; Owner: strapi
--

CREATE TABLE public.visits_poi_lnk (
    id integer NOT NULL,
    visit_id integer,
    poi_id integer,
    visit_ord double precision
);


ALTER TABLE public.visits_poi_lnk OWNER TO strapi;

--
-- Name: visits_poi_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: strapi
--

CREATE SEQUENCE public.visits_poi_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visits_poi_lnk_id_seq OWNER TO strapi;

--
-- Name: visits_poi_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: strapi
--

ALTER SEQUENCE public.visits_poi_lnk_id_seq OWNED BY public.visits_poi_lnk.id;


--
-- Name: admin_permissions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_id_seq'::regclass);


--
-- Name: admin_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_role_lnk_id_seq'::regclass);


--
-- Name: admin_roles id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_roles ALTER COLUMN id SET DEFAULT nextval('public.admin_roles_id_seq'::regclass);


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: admin_users_roles_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_users_roles_lnk_id_seq'::regclass);


--
-- Name: characters id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.characters ALTER COLUMN id SET DEFAULT nextval('public.characters_id_seq'::regclass);


--
-- Name: characters_guild_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.characters_guild_lnk ALTER COLUMN id SET DEFAULT nextval('public.characters_guild_lnk_id_seq'::regclass);


--
-- Name: dialogs id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.dialogs ALTER COLUMN id SET DEFAULT nextval('public.dialogs_id_seq'::regclass);


--
-- Name: dialogs_npc_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.dialogs_npc_lnk ALTER COLUMN id SET DEFAULT nextval('public.dialogs_npc_lnk_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: files_folder_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk ALTER COLUMN id SET DEFAULT nextval('public.files_folder_lnk_id_seq'::regclass);


--
-- Name: files_related_mph id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_related_mph ALTER COLUMN id SET DEFAULT nextval('public.files_related_mph_id_seq'::regclass);


--
-- Name: friendships id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships ALTER COLUMN id SET DEFAULT nextval('public.friendships_id_seq'::regclass);


--
-- Name: friendships_guild_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_guild_lnk ALTER COLUMN id SET DEFAULT nextval('public.friendships_guild_lnk_id_seq'::regclass);


--
-- Name: friendships_npc_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_npc_lnk ALTER COLUMN id SET DEFAULT nextval('public.friendships_npc_lnk_id_seq'::regclass);


--
-- Name: guilds id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.guilds ALTER COLUMN id SET DEFAULT nextval('public.guilds_id_seq'::regclass);


--
-- Name: guilds_user_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.guilds_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.guilds_user_lnk_id_seq'::regclass);


--
-- Name: i18n_locale id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.i18n_locale ALTER COLUMN id SET DEFAULT nextval('public.i18n_locale_id_seq'::regclass);


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: items_character_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_character_lnk ALTER COLUMN id SET DEFAULT nextval('public.items_character_lnk_id_seq'::regclass);


--
-- Name: items_guild_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_guild_lnk ALTER COLUMN id SET DEFAULT nextval('public.items_guild_lnk_id_seq'::regclass);


--
-- Name: items_rarity_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_rarity_lnk ALTER COLUMN id SET DEFAULT nextval('public.items_rarity_lnk_id_seq'::regclass);


--
-- Name: items_runs_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_runs_lnk ALTER COLUMN id SET DEFAULT nextval('public.items_runs_lnk_id_seq'::regclass);


--
-- Name: items_tags_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_tags_lnk ALTER COLUMN id SET DEFAULT nextval('public.items_tags_lnk_id_seq'::regclass);


--
-- Name: items_visits_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_visits_lnk ALTER COLUMN id SET DEFAULT nextval('public.items_visits_lnk_id_seq'::regclass);


--
-- Name: museums id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.museums ALTER COLUMN id SET DEFAULT nextval('public.museums_id_seq'::regclass);


--
-- Name: museums_tags_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.museums_tags_lnk ALTER COLUMN id SET DEFAULT nextval('public.museums_tags_lnk_id_seq'::regclass);


--
-- Name: npcs id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.npcs ALTER COLUMN id SET DEFAULT nextval('public.npcs_id_seq'::regclass);


--
-- Name: pois id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.pois ALTER COLUMN id SET DEFAULT nextval('public.pois_id_seq'::regclass);


--
-- Name: quests id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests ALTER COLUMN id SET DEFAULT nextval('public.quests_id_seq'::regclass);


--
-- Name: quests_guild_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_guild_lnk ALTER COLUMN id SET DEFAULT nextval('public.quests_guild_lnk_id_seq'::regclass);


--
-- Name: quests_npc_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_npc_lnk ALTER COLUMN id SET DEFAULT nextval('public.quests_npc_lnk_id_seq'::regclass);


--
-- Name: quests_poi_a_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_a_lnk ALTER COLUMN id SET DEFAULT nextval('public.quests_poi_a_lnk_id_seq'::regclass);


--
-- Name: quests_poi_b_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_b_lnk ALTER COLUMN id SET DEFAULT nextval('public.quests_poi_b_lnk_id_seq'::regclass);


--
-- Name: rarities id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.rarities ALTER COLUMN id SET DEFAULT nextval('public.rarities_id_seq'::regclass);


--
-- Name: runs id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs ALTER COLUMN id SET DEFAULT nextval('public.runs_id_seq'::regclass);


--
-- Name: runs_guild_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_guild_lnk ALTER COLUMN id SET DEFAULT nextval('public.runs_guild_lnk_id_seq'::regclass);


--
-- Name: runs_museum_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_museum_lnk ALTER COLUMN id SET DEFAULT nextval('public.runs_museum_lnk_id_seq'::regclass);


--
-- Name: runs_npc_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_npc_lnk ALTER COLUMN id SET DEFAULT nextval('public.runs_npc_lnk_id_seq'::regclass);


--
-- Name: strapi_ai_localization_jobs id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs ALTER COLUMN id SET DEFAULT nextval('public.strapi_ai_localization_jobs_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_api_tokens id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_tokens_id_seq'::regclass);


--
-- Name: strapi_core_store_settings id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_core_store_settings ALTER COLUMN id SET DEFAULT nextval('public.strapi_core_store_settings_id_seq'::regclass);


--
-- Name: strapi_database_schema id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_database_schema ALTER COLUMN id SET DEFAULT nextval('public.strapi_database_schema_id_seq'::regclass);


--
-- Name: strapi_history_versions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_history_versions ALTER COLUMN id SET DEFAULT nextval('public.strapi_history_versions_id_seq'::regclass);


--
-- Name: strapi_migrations id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_migrations ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_id_seq'::regclass);


--
-- Name: strapi_migrations_internal id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_migrations_internal ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_internal_id_seq'::regclass);


--
-- Name: strapi_release_actions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_id_seq'::regclass);


--
-- Name: strapi_release_actions_release_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_release_lnk_id_seq'::regclass);


--
-- Name: strapi_releases id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_releases ALTER COLUMN id SET DEFAULT nextval('public.strapi_releases_id_seq'::regclass);


--
-- Name: strapi_sessions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_sessions ALTER COLUMN id SET DEFAULT nextval('public.strapi_sessions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_transfer_tokens id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_tokens_id_seq'::regclass);


--
-- Name: strapi_webhooks id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_webhooks ALTER COLUMN id SET DEFAULT nextval('public.strapi_webhooks_id_seq'::regclass);


--
-- Name: strapi_workflows id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_id_seq'::regclass);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_permissions_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_permissions_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_workflow_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_workflow_lnk_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: up_permissions id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_id_seq'::regclass);


--
-- Name: up_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_role_lnk_id_seq'::regclass);


--
-- Name: up_roles id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_roles ALTER COLUMN id SET DEFAULT nextval('public.up_roles_id_seq'::regclass);


--
-- Name: up_users id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users ALTER COLUMN id SET DEFAULT nextval('public.up_users_id_seq'::regclass);


--
-- Name: up_users_guild_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_guild_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_users_guild_lnk_id_seq'::regclass);


--
-- Name: up_users_role_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_users_role_lnk_id_seq'::regclass);


--
-- Name: upload_folders id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_id_seq'::regclass);


--
-- Name: upload_folders_parent_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_parent_lnk_id_seq'::regclass);


--
-- Name: visits id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits ALTER COLUMN id SET DEFAULT nextval('public.visits_id_seq'::regclass);


--
-- Name: visits_guild_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_guild_lnk ALTER COLUMN id SET DEFAULT nextval('public.visits_guild_lnk_id_seq'::regclass);


--
-- Name: visits_poi_lnk id; Type: DEFAULT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_poi_lnk ALTER COLUMN id SET DEFAULT nextval('public.visits_poi_lnk_id_seq'::regclass);


--
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_permissions (id, document_id, action, action_parameters, subject, properties, conditions, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
2	yg23fsq3pfk2wf5ddvljxq85	plugin::content-manager.explorer.create	{}	api::dialog.dialog	{"fields": ["text_type", "dialogues", "npc"]}	[]	2025-12-15 15:33:24.32	2025-12-15 15:33:24.32	2025-12-15 15:33:24.32	\N	\N	\N
3	nhdmn19qsf9kjpq3u832di92	plugin::content-manager.explorer.create	{}	api::friendship.friendship	{"fields": ["quests_entry_unlocked", "expedition_entry_unlocked", "npc", "guild"]}	[]	2025-12-15 15:33:24.339	2025-12-15 15:33:24.339	2025-12-15 15:33:24.34	\N	\N	\N
4	nuq917vxd1l1ds6zw90c6yfn	plugin::content-manager.explorer.create	{}	api::guild.guild	{"fields": ["name", "gold", "exp", "scrap", "user", "characters", "items", "visits", "runs", "friendships", "quests"]}	[]	2025-12-15 15:33:24.36	2025-12-15 15:33:24.36	2025-12-15 15:33:24.36	\N	\N	\N
5	l68rqlft5g56clbs36uhtlxp	plugin::content-manager.explorer.create	{}	api::item.item	{"fields": ["name", "level", "index_damage", "slot", "isScrapped", "rarity", "guild", "character", "tags", "runs", "visits"]}	[]	2025-12-15 15:33:24.38	2025-12-15 15:33:24.38	2025-12-15 15:33:24.38	\N	\N	\N
6	tw8bwydh8jzytlgcu8okty3f	plugin::content-manager.explorer.create	{}	api::museum.museum	{"fields": ["name", "lat", "lng", "geohash", "tags", "runs", "location", "radius"]}	[]	2025-12-15 15:33:24.398	2025-12-15 15:33:24.398	2025-12-15 15:33:24.399	\N	\N	\N
7	tedebcg83x732n8qv0u4sx18	plugin::content-manager.explorer.create	{}	api::npc.npc	{"fields": ["firstname", "lastname", "pronouns", "quests_entry_available", "expedition_entry_available", "friendships", "quests", "dialogs", "runs"]}	[]	2025-12-15 15:33:24.415	2025-12-15 15:33:24.415	2025-12-15 15:33:24.416	\N	\N	\N
8	x8rxpezbe3z24hhxyn35gbp2	plugin::content-manager.explorer.create	{}	api::poi.poi	{"fields": ["name", "lat", "lng", "geohash", "visits", "quests_a", "quests_b", "location"]}	[]	2025-12-15 15:33:24.431	2025-12-15 15:33:24.431	2025-12-15 15:33:24.431	\N	\N	\N
9	dxmztu1wlww79lb4jz3y23jp	plugin::content-manager.explorer.create	{}	api::quest.quest	{"fields": ["is_poi_a_completed", "is_poi_b_completed", "date_start", "date_end", "gold_earned", "xp_earned", "guild", "npc", "poi_a", "poi_b"]}	[]	2025-12-15 15:33:24.45	2025-12-15 15:33:24.45	2025-12-15 15:33:24.45	\N	\N	\N
10	lipb9kvg4w0ayvath84c85ib	plugin::content-manager.explorer.create	{}	api::rarity.rarity	{"fields": ["name", "items"]}	[]	2025-12-15 15:33:24.471	2025-12-15 15:33:24.471	2025-12-15 15:33:24.471	\N	\N	\N
11	r5a5ear6ql874sy43oog8uw3	plugin::content-manager.explorer.create	{}	api::run.run	{"fields": ["dps", "date_start", "date_end", "gold_earned", "xp_earned", "threshold_reached", "target_threshold", "entry_unlocked", "guild", "museum", "npc", "items"]}	[]	2025-12-15 15:33:24.489	2025-12-15 15:33:24.489	2025-12-15 15:33:24.489	\N	\N	\N
12	ap7p362owgj7fknalc5qonkm	plugin::content-manager.explorer.create	{}	api::tag.tag	{"fields": ["name", "items", "museums"]}	[]	2025-12-15 15:33:24.509	2025-12-15 15:33:24.509	2025-12-15 15:33:24.51	\N	\N	\N
13	dyxush0jvo5zdh0khxm658m1	plugin::content-manager.explorer.create	{}	api::visit.visit	{"fields": ["open_count", "last_opened_at", "total_gold_earned", "total_exp_earned", "guild", "poi", "items"]}	[]	2025-12-15 15:33:24.527	2025-12-15 15:33:24.527	2025-12-15 15:33:24.527	\N	\N	\N
15	czn6zs77nmkqnwdgalvbbn3h	plugin::content-manager.explorer.read	{}	api::dialog.dialog	{"fields": ["text_type", "dialogues", "npc"]}	[]	2025-12-15 15:33:24.566	2025-12-15 15:33:24.566	2025-12-15 15:33:24.566	\N	\N	\N
16	btpploe5l6omq88cu4eaiqqv	plugin::content-manager.explorer.read	{}	api::friendship.friendship	{"fields": ["quests_entry_unlocked", "expedition_entry_unlocked", "npc", "guild"]}	[]	2025-12-15 15:33:24.588	2025-12-15 15:33:24.588	2025-12-15 15:33:24.588	\N	\N	\N
17	runuy3vjbq0ehzsgf23gy3e7	plugin::content-manager.explorer.read	{}	api::guild.guild	{"fields": ["name", "gold", "exp", "scrap", "user", "characters", "items", "visits", "runs", "friendships", "quests"]}	[]	2025-12-15 15:33:24.605	2025-12-15 15:33:24.605	2025-12-15 15:33:24.606	\N	\N	\N
18	uuqrgj69m4bpsqasj05fxvgl	plugin::content-manager.explorer.read	{}	api::item.item	{"fields": ["name", "level", "index_damage", "slot", "isScrapped", "rarity", "guild", "character", "tags", "runs", "visits"]}	[]	2025-12-15 15:33:24.621	2025-12-15 15:33:24.621	2025-12-15 15:33:24.621	\N	\N	\N
19	t0zfrl1iyth91vd28w6xovf8	plugin::content-manager.explorer.read	{}	api::museum.museum	{"fields": ["name", "lat", "lng", "geohash", "tags", "runs", "location", "radius"]}	[]	2025-12-15 15:33:24.637	2025-12-15 15:33:24.637	2025-12-15 15:33:24.638	\N	\N	\N
20	li416ouckktxm5zbgcif0d1p	plugin::content-manager.explorer.read	{}	api::npc.npc	{"fields": ["firstname", "lastname", "pronouns", "quests_entry_available", "expedition_entry_available", "friendships", "quests", "dialogs", "runs"]}	[]	2025-12-15 15:33:24.654	2025-12-15 15:33:24.654	2025-12-15 15:33:24.654	\N	\N	\N
21	btntn2pvkfmr6lncdqyw1vs0	plugin::content-manager.explorer.read	{}	api::poi.poi	{"fields": ["name", "lat", "lng", "geohash", "visits", "quests_a", "quests_b", "location"]}	[]	2025-12-15 15:33:24.669	2025-12-15 15:33:24.669	2025-12-15 15:33:24.669	\N	\N	\N
22	eom28s0brfu344ct4xw5vu9l	plugin::content-manager.explorer.read	{}	api::quest.quest	{"fields": ["is_poi_a_completed", "is_poi_b_completed", "date_start", "date_end", "gold_earned", "xp_earned", "guild", "npc", "poi_a", "poi_b"]}	[]	2025-12-15 15:33:24.684	2025-12-15 15:33:24.684	2025-12-15 15:33:24.685	\N	\N	\N
23	fq15lhc4z83dr7bu17s1ktww	plugin::content-manager.explorer.read	{}	api::rarity.rarity	{"fields": ["name", "items"]}	[]	2025-12-15 15:33:24.699	2025-12-15 15:33:24.699	2025-12-15 15:33:24.7	\N	\N	\N
24	xzhj7n3yztrey9ws62o8j0hm	plugin::content-manager.explorer.read	{}	api::run.run	{"fields": ["dps", "date_start", "date_end", "gold_earned", "xp_earned", "threshold_reached", "target_threshold", "entry_unlocked", "guild", "museum", "npc", "items"]}	[]	2025-12-15 15:33:24.713	2025-12-15 15:33:24.713	2025-12-15 15:33:24.714	\N	\N	\N
25	h8ohwuln86doznadkhjcrbdj	plugin::content-manager.explorer.read	{}	api::tag.tag	{"fields": ["name", "items", "museums"]}	[]	2025-12-15 15:33:24.727	2025-12-15 15:33:24.727	2025-12-15 15:33:24.727	\N	\N	\N
26	j6pa83e8zq8c5o6l88lu8h42	plugin::content-manager.explorer.read	{}	api::visit.visit	{"fields": ["open_count", "last_opened_at", "total_gold_earned", "total_exp_earned", "guild", "poi", "items"]}	[]	2025-12-15 15:33:24.74	2025-12-15 15:33:24.74	2025-12-15 15:33:24.74	\N	\N	\N
28	wl3zck9edxn8bf3pm1128yts	plugin::content-manager.explorer.update	{}	api::dialog.dialog	{"fields": ["text_type", "dialogues", "npc"]}	[]	2025-12-15 15:33:24.77	2025-12-15 15:33:24.77	2025-12-15 15:33:24.77	\N	\N	\N
29	z4clllzw8a139etqntwgy9zi	plugin::content-manager.explorer.update	{}	api::friendship.friendship	{"fields": ["quests_entry_unlocked", "expedition_entry_unlocked", "npc", "guild"]}	[]	2025-12-15 15:33:24.785	2025-12-15 15:33:24.785	2025-12-15 15:33:24.785	\N	\N	\N
30	fjzk7w1fjc9wyp83iqwdef2t	plugin::content-manager.explorer.update	{}	api::guild.guild	{"fields": ["name", "gold", "exp", "scrap", "user", "characters", "items", "visits", "runs", "friendships", "quests"]}	[]	2025-12-15 15:33:24.797	2025-12-15 15:33:24.797	2025-12-15 15:33:24.797	\N	\N	\N
27	zmibs8ikfjvvqca2rcztqq70	plugin::content-manager.explorer.update	{}	api::character.character	{"fields": ["firstname", "lastname", "guild", "items"]}	[]	2025-12-15 15:33:24.755	2025-12-18 13:19:42.523	2025-12-15 15:33:24.755	\N	\N	\N
31	epgzqxs5kagpzh9eomsk5tgs	plugin::content-manager.explorer.update	{}	api::item.item	{"fields": ["name", "level", "index_damage", "slot", "isScrapped", "rarity", "guild", "character", "tags", "runs", "visits"]}	[]	2025-12-15 15:33:24.811	2025-12-15 15:33:24.811	2025-12-15 15:33:24.812	\N	\N	\N
32	ixotvx1u55v8o0yn1mmc9nq1	plugin::content-manager.explorer.update	{}	api::museum.museum	{"fields": ["name", "lat", "lng", "geohash", "tags", "runs", "location", "radius"]}	[]	2025-12-15 15:33:24.831	2025-12-15 15:33:24.831	2025-12-15 15:33:24.831	\N	\N	\N
33	ayz27klwsv4ytzqm0req5zd1	plugin::content-manager.explorer.update	{}	api::npc.npc	{"fields": ["firstname", "lastname", "pronouns", "quests_entry_available", "expedition_entry_available", "friendships", "quests", "dialogs", "runs"]}	[]	2025-12-15 15:33:24.846	2025-12-15 15:33:24.846	2025-12-15 15:33:24.847	\N	\N	\N
34	p930r1os7nc863x2apx6zsdf	plugin::content-manager.explorer.update	{}	api::poi.poi	{"fields": ["name", "lat", "lng", "geohash", "visits", "quests_a", "quests_b", "location"]}	[]	2025-12-15 15:33:24.862	2025-12-15 15:33:24.862	2025-12-15 15:33:24.863	\N	\N	\N
35	ceh696dxq0qc9doefxatgx5k	plugin::content-manager.explorer.update	{}	api::quest.quest	{"fields": ["is_poi_a_completed", "is_poi_b_completed", "date_start", "date_end", "gold_earned", "xp_earned", "guild", "npc", "poi_a", "poi_b"]}	[]	2025-12-15 15:33:24.878	2025-12-15 15:33:24.878	2025-12-15 15:33:24.878	\N	\N	\N
36	sldd9idmxi1j953621arboym	plugin::content-manager.explorer.update	{}	api::rarity.rarity	{"fields": ["name", "items"]}	[]	2025-12-15 15:33:24.892	2025-12-15 15:33:24.892	2025-12-15 15:33:24.893	\N	\N	\N
37	pw3f87z4u5gwz3fj6qi6nz4r	plugin::content-manager.explorer.update	{}	api::run.run	{"fields": ["dps", "date_start", "date_end", "gold_earned", "xp_earned", "threshold_reached", "target_threshold", "entry_unlocked", "guild", "museum", "npc", "items"]}	[]	2025-12-15 15:33:24.905	2025-12-15 15:33:24.905	2025-12-15 15:33:24.906	\N	\N	\N
38	h40yo9lh4cix74ywxsiw8bdy	plugin::content-manager.explorer.update	{}	api::tag.tag	{"fields": ["name", "items", "museums"]}	[]	2025-12-15 15:33:24.923	2025-12-15 15:33:24.923	2025-12-15 15:33:24.923	\N	\N	\N
39	kndvan1xib1b5mq9ubajoeax	plugin::content-manager.explorer.update	{}	api::visit.visit	{"fields": ["open_count", "last_opened_at", "total_gold_earned", "total_exp_earned", "guild", "poi", "items"]}	[]	2025-12-15 15:33:24.939	2025-12-15 15:33:24.939	2025-12-15 15:33:24.939	\N	\N	\N
40	bgr5fqkap8lw9wt9ix6hsoh4	plugin::content-manager.explorer.delete	{}	api::character.character	{}	[]	2025-12-15 15:33:24.954	2025-12-15 15:33:24.954	2025-12-15 15:33:24.954	\N	\N	\N
41	wq7rzrn9iwaqlgty8qgfl3qd	plugin::content-manager.explorer.delete	{}	api::dialog.dialog	{}	[]	2025-12-15 15:33:24.968	2025-12-15 15:33:24.968	2025-12-15 15:33:24.968	\N	\N	\N
42	pbfc6boablic7omuoicctalu	plugin::content-manager.explorer.delete	{}	api::friendship.friendship	{}	[]	2025-12-15 15:33:24.984	2025-12-15 15:33:24.984	2025-12-15 15:33:24.985	\N	\N	\N
43	f2ympog839cvbstoox65wk55	plugin::content-manager.explorer.delete	{}	api::guild.guild	{}	[]	2025-12-15 15:33:25.002	2025-12-15 15:33:25.002	2025-12-15 15:33:25.002	\N	\N	\N
44	yvli0oh9nppu5a86wjmg6fkw	plugin::content-manager.explorer.delete	{}	api::item.item	{}	[]	2025-12-15 15:33:25.025	2025-12-15 15:33:25.025	2025-12-15 15:33:25.025	\N	\N	\N
45	o6h9aav7lp1xe35f31m42hyg	plugin::content-manager.explorer.delete	{}	api::museum.museum	{}	[]	2025-12-15 15:33:25.041	2025-12-15 15:33:25.041	2025-12-15 15:33:25.041	\N	\N	\N
46	k2kbvddvl69oj5ib0mpnx6qp	plugin::content-manager.explorer.delete	{}	api::npc.npc	{}	[]	2025-12-15 15:33:25.067	2025-12-15 15:33:25.067	2025-12-15 15:33:25.068	\N	\N	\N
47	qhee0r89euqz4af67y0snyz2	plugin::content-manager.explorer.delete	{}	api::poi.poi	{}	[]	2025-12-15 15:33:25.095	2025-12-15 15:33:25.095	2025-12-15 15:33:25.096	\N	\N	\N
48	jhzk7kwiezen60hr17ssi8tw	plugin::content-manager.explorer.delete	{}	api::quest.quest	{}	[]	2025-12-15 15:33:25.123	2025-12-15 15:33:25.123	2025-12-15 15:33:25.124	\N	\N	\N
49	ic95z2sq85r1ool7nprc9t4d	plugin::content-manager.explorer.delete	{}	api::rarity.rarity	{}	[]	2025-12-15 15:33:25.173	2025-12-15 15:33:25.173	2025-12-15 15:33:25.173	\N	\N	\N
50	p3tgjarits06795kj492cmxx	plugin::content-manager.explorer.delete	{}	api::run.run	{}	[]	2025-12-15 15:33:25.193	2025-12-15 15:33:25.193	2025-12-15 15:33:25.194	\N	\N	\N
51	u1jlp4eqqufm6tkx8sqyp7ke	plugin::content-manager.explorer.delete	{}	api::tag.tag	{}	[]	2025-12-15 15:33:25.206	2025-12-15 15:33:25.206	2025-12-15 15:33:25.207	\N	\N	\N
52	i873xev95c0snsjljy7btkte	plugin::content-manager.explorer.delete	{}	api::visit.visit	{}	[]	2025-12-15 15:33:25.219	2025-12-15 15:33:25.219	2025-12-15 15:33:25.219	\N	\N	\N
53	q4mem0gchn8izf65e1n0zofz	plugin::content-manager.explorer.publish	{}	api::character.character	{}	[]	2025-12-15 15:33:25.232	2025-12-15 15:33:25.232	2025-12-15 15:33:25.233	\N	\N	\N
54	q3a1uvush8ouo6yiln80x6ct	plugin::content-manager.explorer.publish	{}	api::dialog.dialog	{}	[]	2025-12-15 15:33:25.246	2025-12-15 15:33:25.246	2025-12-15 15:33:25.246	\N	\N	\N
55	uj33ejttckx2lz1gvdorzg2o	plugin::content-manager.explorer.publish	{}	api::friendship.friendship	{}	[]	2025-12-15 15:33:25.268	2025-12-15 15:33:25.268	2025-12-15 15:33:25.269	\N	\N	\N
56	i2i2ycb19z8u4jmo6nb72cfq	plugin::content-manager.explorer.publish	{}	api::guild.guild	{}	[]	2025-12-15 15:33:25.288	2025-12-15 15:33:25.288	2025-12-15 15:33:25.288	\N	\N	\N
57	yto0w50l0bhwlqegvoxc8s2l	plugin::content-manager.explorer.publish	{}	api::item.item	{}	[]	2025-12-15 15:33:25.307	2025-12-15 15:33:25.307	2025-12-15 15:33:25.308	\N	\N	\N
58	sjnnrdfvx042w73wtsnj9tf0	plugin::content-manager.explorer.publish	{}	api::museum.museum	{}	[]	2025-12-15 15:33:25.331	2025-12-15 15:33:25.331	2025-12-15 15:33:25.331	\N	\N	\N
59	jru4xsfml96ho0tzfe4ml585	plugin::content-manager.explorer.publish	{}	api::npc.npc	{}	[]	2025-12-15 15:33:25.349	2025-12-15 15:33:25.349	2025-12-15 15:33:25.356	\N	\N	\N
60	l5n0o5ci0fa1q9cj101l8efk	plugin::content-manager.explorer.publish	{}	api::poi.poi	{}	[]	2025-12-15 15:33:25.372	2025-12-15 15:33:25.372	2025-12-15 15:33:25.372	\N	\N	\N
61	mij4beypqlsca0n9bgtnqgow	plugin::content-manager.explorer.publish	{}	api::quest.quest	{}	[]	2025-12-15 15:33:25.385	2025-12-15 15:33:25.385	2025-12-15 15:33:25.386	\N	\N	\N
62	nwp8tbn68k67cbnclfcx2pal	plugin::content-manager.explorer.publish	{}	api::rarity.rarity	{}	[]	2025-12-15 15:33:25.399	2025-12-15 15:33:25.399	2025-12-15 15:33:25.399	\N	\N	\N
63	zvixreyod8zmdso3sun8c2va	plugin::content-manager.explorer.publish	{}	api::run.run	{}	[]	2025-12-15 15:33:25.413	2025-12-15 15:33:25.413	2025-12-15 15:33:25.413	\N	\N	\N
64	qv33p27ggq5fl8xl2g8cwt09	plugin::content-manager.explorer.publish	{}	api::tag.tag	{}	[]	2025-12-15 15:33:25.426	2025-12-15 15:33:25.426	2025-12-15 15:33:25.427	\N	\N	\N
65	guajx2950637ipnn038ukmju	plugin::content-manager.explorer.publish	{}	api::visit.visit	{}	[]	2025-12-15 15:33:25.439	2025-12-15 15:33:25.439	2025-12-15 15:33:25.44	\N	\N	\N
66	o35k6iulw5hvhvlfbf4hodaq	plugin::upload.read	{}	\N	{}	[]	2025-12-15 15:33:25.453	2025-12-15 15:33:25.453	2025-12-15 15:33:25.453	\N	\N	\N
67	ec1ih4xgbxbvcpccohs881c2	plugin::upload.configure-view	{}	\N	{}	[]	2025-12-15 15:33:25.467	2025-12-15 15:33:25.467	2025-12-15 15:33:25.467	\N	\N	\N
68	hrqezd5mb84h7uf3kwdt6d11	plugin::upload.assets.create	{}	\N	{}	[]	2025-12-15 15:33:25.48	2025-12-15 15:33:25.48	2025-12-15 15:33:25.48	\N	\N	\N
69	gkgyhvrtnuo5zva1r176ocmv	plugin::upload.assets.update	{}	\N	{}	[]	2025-12-15 15:33:25.491	2025-12-15 15:33:25.491	2025-12-15 15:33:25.492	\N	\N	\N
70	qwhmu81celkju4skmdjy09aw	plugin::upload.assets.download	{}	\N	{}	[]	2025-12-15 15:33:25.507	2025-12-15 15:33:25.507	2025-12-15 15:33:25.507	\N	\N	\N
71	x2focrsiq3dcfbgrr7ud316m	plugin::upload.assets.copy-link	{}	\N	{}	[]	2025-12-15 15:33:25.522	2025-12-15 15:33:25.522	2025-12-15 15:33:25.522	\N	\N	\N
73	rogmw7e8lvapegrjqyr0b9qe	plugin::content-manager.explorer.create	{}	api::dialog.dialog	{"fields": ["text_type", "dialogues", "npc"]}	["admin::is-creator"]	2025-12-15 15:33:25.563	2025-12-15 15:33:25.563	2025-12-15 15:33:25.563	\N	\N	\N
74	phs11kq0ax7x70rn0ac5sdj9	plugin::content-manager.explorer.create	{}	api::friendship.friendship	{"fields": ["quests_entry_unlocked", "expedition_entry_unlocked", "npc", "guild"]}	["admin::is-creator"]	2025-12-15 15:33:25.578	2025-12-15 15:33:25.578	2025-12-15 15:33:25.578	\N	\N	\N
75	jtu2nruaebb0rly2sf223adt	plugin::content-manager.explorer.create	{}	api::guild.guild	{"fields": ["name", "gold", "exp", "scrap", "user", "characters", "items", "visits", "runs", "friendships", "quests"]}	["admin::is-creator"]	2025-12-15 15:33:25.593	2025-12-15 15:33:25.593	2025-12-15 15:33:25.593	\N	\N	\N
142	yvuxl31mi92vmj808a0xfezw	plugin::content-manager.explorer.create	{}	api::tag.tag	{"fields": ["name", "items", "museums"]}	[]	2025-12-15 15:33:26.645	2025-12-15 15:33:26.645	2025-12-15 15:33:26.645	\N	\N	\N
76	uznuurox3xoj0xx2hgx0fdfs	plugin::content-manager.explorer.create	{}	api::item.item	{"fields": ["name", "level", "index_damage", "slot", "isScrapped", "rarity", "guild", "character", "tags", "runs", "visits"]}	["admin::is-creator"]	2025-12-15 15:33:25.606	2025-12-15 15:33:25.606	2025-12-15 15:33:25.606	\N	\N	\N
77	a4ggzue13spjnmnmw6q7b7py	plugin::content-manager.explorer.create	{}	api::museum.museum	{"fields": ["name", "lat", "lng", "geohash", "tags", "runs", "location", "radius"]}	["admin::is-creator"]	2025-12-15 15:33:25.619	2025-12-15 15:33:25.619	2025-12-15 15:33:25.619	\N	\N	\N
78	z4g8n16z67mx3huqe47zzi8n	plugin::content-manager.explorer.create	{}	api::npc.npc	{"fields": ["firstname", "lastname", "pronouns", "quests_entry_available", "expedition_entry_available", "friendships", "quests", "dialogs", "runs"]}	["admin::is-creator"]	2025-12-15 15:33:25.635	2025-12-15 15:33:25.635	2025-12-15 15:33:25.635	\N	\N	\N
79	vfpl0t6ey39gbr0ik71a0rpy	plugin::content-manager.explorer.create	{}	api::poi.poi	{"fields": ["name", "lat", "lng", "geohash", "visits", "quests_a", "quests_b", "location"]}	["admin::is-creator"]	2025-12-15 15:33:25.647	2025-12-15 15:33:25.647	2025-12-15 15:33:25.647	\N	\N	\N
80	b4bjdnikstjtt30cgw4ms3l5	plugin::content-manager.explorer.create	{}	api::quest.quest	{"fields": ["is_poi_a_completed", "is_poi_b_completed", "date_start", "date_end", "gold_earned", "xp_earned", "guild", "npc", "poi_a", "poi_b"]}	["admin::is-creator"]	2025-12-15 15:33:25.662	2025-12-15 15:33:25.662	2025-12-15 15:33:25.662	\N	\N	\N
81	crb96b7b1cmaziw46yihj87y	plugin::content-manager.explorer.create	{}	api::rarity.rarity	{"fields": ["name", "items"]}	["admin::is-creator"]	2025-12-15 15:33:25.675	2025-12-15 15:33:25.675	2025-12-15 15:33:25.675	\N	\N	\N
82	w64ugs0i9xr544t7ycgg8cn8	plugin::content-manager.explorer.create	{}	api::run.run	{"fields": ["dps", "date_start", "date_end", "gold_earned", "xp_earned", "threshold_reached", "target_threshold", "entry_unlocked", "guild", "museum", "npc", "items"]}	["admin::is-creator"]	2025-12-15 15:33:25.686	2025-12-15 15:33:25.686	2025-12-15 15:33:25.687	\N	\N	\N
83	rcm1hqvvln340fd3ygdnggvp	plugin::content-manager.explorer.create	{}	api::tag.tag	{"fields": ["name", "items", "museums"]}	["admin::is-creator"]	2025-12-15 15:33:25.699	2025-12-15 15:33:25.699	2025-12-15 15:33:25.699	\N	\N	\N
84	qckb9mnin5o0bfrqy9ikp07q	plugin::content-manager.explorer.create	{}	api::visit.visit	{"fields": ["open_count", "last_opened_at", "total_gold_earned", "total_exp_earned", "guild", "poi", "items"]}	["admin::is-creator"]	2025-12-15 15:33:25.712	2025-12-15 15:33:25.712	2025-12-15 15:33:25.712	\N	\N	\N
86	uvkb9zva9b5y1ze2vkdclxjy	plugin::content-manager.explorer.read	{}	api::dialog.dialog	{"fields": ["text_type", "dialogues", "npc"]}	["admin::is-creator"]	2025-12-15 15:33:25.738	2025-12-15 15:33:25.738	2025-12-15 15:33:25.738	\N	\N	\N
87	y5x514vqqt7krv5jr2ohp0t3	plugin::content-manager.explorer.read	{}	api::friendship.friendship	{"fields": ["quests_entry_unlocked", "expedition_entry_unlocked", "npc", "guild"]}	["admin::is-creator"]	2025-12-15 15:33:25.754	2025-12-15 15:33:25.754	2025-12-15 15:33:25.755	\N	\N	\N
88	wybxe2ton1ncszyktoyqt1w7	plugin::content-manager.explorer.read	{}	api::guild.guild	{"fields": ["name", "gold", "exp", "scrap", "user", "characters", "items", "visits", "runs", "friendships", "quests"]}	["admin::is-creator"]	2025-12-15 15:33:25.769	2025-12-15 15:33:25.769	2025-12-15 15:33:25.77	\N	\N	\N
89	fzr93oiyn6heh8iufbrwjnn0	plugin::content-manager.explorer.read	{}	api::item.item	{"fields": ["name", "level", "index_damage", "slot", "isScrapped", "rarity", "guild", "character", "tags", "runs", "visits"]}	["admin::is-creator"]	2025-12-15 15:33:25.789	2025-12-15 15:33:25.789	2025-12-15 15:33:25.789	\N	\N	\N
90	o8mg5drhccyctzn79uy1qyqf	plugin::content-manager.explorer.read	{}	api::museum.museum	{"fields": ["name", "lat", "lng", "geohash", "tags", "runs", "location", "radius"]}	["admin::is-creator"]	2025-12-15 15:33:25.825	2025-12-15 15:33:25.825	2025-12-15 15:33:25.825	\N	\N	\N
91	rwud4wwiuartdov8zgl01jhx	plugin::content-manager.explorer.read	{}	api::npc.npc	{"fields": ["firstname", "lastname", "pronouns", "quests_entry_available", "expedition_entry_available", "friendships", "quests", "dialogs", "runs"]}	["admin::is-creator"]	2025-12-15 15:33:25.839	2025-12-15 15:33:25.839	2025-12-15 15:33:25.839	\N	\N	\N
92	eo5vx0ozxj0sg32us7nuiez9	plugin::content-manager.explorer.read	{}	api::poi.poi	{"fields": ["name", "lat", "lng", "geohash", "visits", "quests_a", "quests_b", "location"]}	["admin::is-creator"]	2025-12-15 15:33:25.882	2025-12-15 15:33:25.882	2025-12-15 15:33:25.882	\N	\N	\N
93	sej3lt60n8ljjufd1dfcgvrj	plugin::content-manager.explorer.read	{}	api::quest.quest	{"fields": ["is_poi_a_completed", "is_poi_b_completed", "date_start", "date_end", "gold_earned", "xp_earned", "guild", "npc", "poi_a", "poi_b"]}	["admin::is-creator"]	2025-12-15 15:33:25.899	2025-12-15 15:33:25.899	2025-12-15 15:33:25.899	\N	\N	\N
94	tu1ov23t4skunj75uz8c0af9	plugin::content-manager.explorer.read	{}	api::rarity.rarity	{"fields": ["name", "items"]}	["admin::is-creator"]	2025-12-15 15:33:25.922	2025-12-15 15:33:25.922	2025-12-15 15:33:25.923	\N	\N	\N
95	wthyy964ca60wpucvgo7zjsn	plugin::content-manager.explorer.read	{}	api::run.run	{"fields": ["dps", "date_start", "date_end", "gold_earned", "xp_earned", "threshold_reached", "target_threshold", "entry_unlocked", "guild", "museum", "npc", "items"]}	["admin::is-creator"]	2025-12-15 15:33:25.936	2025-12-15 15:33:25.936	2025-12-15 15:33:25.937	\N	\N	\N
96	d2u2c6qrzkcclvhdgt09nbl6	plugin::content-manager.explorer.read	{}	api::tag.tag	{"fields": ["name", "items", "museums"]}	["admin::is-creator"]	2025-12-15 15:33:25.955	2025-12-15 15:33:25.955	2025-12-15 15:33:25.956	\N	\N	\N
97	btfoaxd333xfq6f46b70jh7j	plugin::content-manager.explorer.read	{}	api::visit.visit	{"fields": ["open_count", "last_opened_at", "total_gold_earned", "total_exp_earned", "guild", "poi", "items"]}	["admin::is-creator"]	2025-12-15 15:33:25.975	2025-12-15 15:33:25.975	2025-12-15 15:33:25.976	\N	\N	\N
99	y0et7ylwi4mijthyxz16026e	plugin::content-manager.explorer.update	{}	api::dialog.dialog	{"fields": ["text_type", "dialogues", "npc"]}	["admin::is-creator"]	2025-12-15 15:33:26.005	2025-12-15 15:33:26.005	2025-12-15 15:33:26.005	\N	\N	\N
100	s7so0lhd248wrjpl7xo2rupf	plugin::content-manager.explorer.update	{}	api::friendship.friendship	{"fields": ["quests_entry_unlocked", "expedition_entry_unlocked", "npc", "guild"]}	["admin::is-creator"]	2025-12-15 15:33:26.018	2025-12-15 15:33:26.018	2025-12-15 15:33:26.018	\N	\N	\N
101	fshj9b3mtpzyw3own0kfmwls	plugin::content-manager.explorer.update	{}	api::guild.guild	{"fields": ["name", "gold", "exp", "scrap", "user", "characters", "items", "visits", "runs", "friendships", "quests"]}	["admin::is-creator"]	2025-12-15 15:33:26.034	2025-12-15 15:33:26.034	2025-12-15 15:33:26.035	\N	\N	\N
102	bjm9jrl73qcbx3811l2ys6pd	plugin::content-manager.explorer.update	{}	api::item.item	{"fields": ["name", "level", "index_damage", "slot", "isScrapped", "rarity", "guild", "character", "tags", "runs", "visits"]}	["admin::is-creator"]	2025-12-15 15:33:26.049	2025-12-15 15:33:26.049	2025-12-15 15:33:26.049	\N	\N	\N
103	qa73wmx0rpgyalmn98zqbhl2	plugin::content-manager.explorer.update	{}	api::museum.museum	{"fields": ["name", "lat", "lng", "geohash", "tags", "runs", "location", "radius"]}	["admin::is-creator"]	2025-12-15 15:33:26.06	2025-12-15 15:33:26.06	2025-12-15 15:33:26.061	\N	\N	\N
104	kq04anan0q5v9znz8bjfhgj3	plugin::content-manager.explorer.update	{}	api::npc.npc	{"fields": ["firstname", "lastname", "pronouns", "quests_entry_available", "expedition_entry_available", "friendships", "quests", "dialogs", "runs"]}	["admin::is-creator"]	2025-12-15 15:33:26.071	2025-12-15 15:33:26.071	2025-12-15 15:33:26.071	\N	\N	\N
181	em9hyaobsi2n3ji3slheskks	plugin::content-manager.explorer.delete	{}	api::quest.quest	{}	[]	2025-12-15 15:33:27.202	2025-12-15 15:33:27.202	2025-12-15 15:33:27.202	\N	\N	\N
105	o7hx0bvpmh19u27m6cshzzan	plugin::content-manager.explorer.update	{}	api::poi.poi	{"fields": ["name", "lat", "lng", "geohash", "visits", "quests_a", "quests_b", "location"]}	["admin::is-creator"]	2025-12-15 15:33:26.083	2025-12-15 15:33:26.083	2025-12-15 15:33:26.083	\N	\N	\N
106	vpep85f32x1spxmlxokwbj25	plugin::content-manager.explorer.update	{}	api::quest.quest	{"fields": ["is_poi_a_completed", "is_poi_b_completed", "date_start", "date_end", "gold_earned", "xp_earned", "guild", "npc", "poi_a", "poi_b"]}	["admin::is-creator"]	2025-12-15 15:33:26.094	2025-12-15 15:33:26.094	2025-12-15 15:33:26.094	\N	\N	\N
107	ynoooc5ak7kxtnoc1rirnboy	plugin::content-manager.explorer.update	{}	api::rarity.rarity	{"fields": ["name", "items"]}	["admin::is-creator"]	2025-12-15 15:33:26.104	2025-12-15 15:33:26.104	2025-12-15 15:33:26.104	\N	\N	\N
108	dkuyrlexradwqri1b51y55b6	plugin::content-manager.explorer.update	{}	api::run.run	{"fields": ["dps", "date_start", "date_end", "gold_earned", "xp_earned", "threshold_reached", "target_threshold", "entry_unlocked", "guild", "museum", "npc", "items"]}	["admin::is-creator"]	2025-12-15 15:33:26.115	2025-12-15 15:33:26.115	2025-12-15 15:33:26.115	\N	\N	\N
109	n5d679mmdeolpxksi1lfui7z	plugin::content-manager.explorer.update	{}	api::tag.tag	{"fields": ["name", "items", "museums"]}	["admin::is-creator"]	2025-12-15 15:33:26.127	2025-12-15 15:33:26.127	2025-12-15 15:33:26.127	\N	\N	\N
110	q5nugjr2qr74no57k083fzai	plugin::content-manager.explorer.update	{}	api::visit.visit	{"fields": ["open_count", "last_opened_at", "total_gold_earned", "total_exp_earned", "guild", "poi", "items"]}	["admin::is-creator"]	2025-12-15 15:33:26.139	2025-12-15 15:33:26.139	2025-12-15 15:33:26.14	\N	\N	\N
111	qmexf41fou5jc8cvc8n3ip9p	plugin::content-manager.explorer.delete	{}	api::character.character	{}	["admin::is-creator"]	2025-12-15 15:33:26.153	2025-12-15 15:33:26.153	2025-12-15 15:33:26.153	\N	\N	\N
112	zba6iq3uvxi9pbwi61dbxgih	plugin::content-manager.explorer.delete	{}	api::dialog.dialog	{}	["admin::is-creator"]	2025-12-15 15:33:26.166	2025-12-15 15:33:26.166	2025-12-15 15:33:26.166	\N	\N	\N
113	xvx4nvd0nspcjyovejfz5cpf	plugin::content-manager.explorer.delete	{}	api::friendship.friendship	{}	["admin::is-creator"]	2025-12-15 15:33:26.178	2025-12-15 15:33:26.178	2025-12-15 15:33:26.179	\N	\N	\N
114	tp2ranp7x8kz0se2dppxub77	plugin::content-manager.explorer.delete	{}	api::guild.guild	{}	["admin::is-creator"]	2025-12-15 15:33:26.192	2025-12-15 15:33:26.192	2025-12-15 15:33:26.192	\N	\N	\N
115	heg2ezddcg24xfwj9ashb0ph	plugin::content-manager.explorer.delete	{}	api::item.item	{}	["admin::is-creator"]	2025-12-15 15:33:26.205	2025-12-15 15:33:26.205	2025-12-15 15:33:26.205	\N	\N	\N
116	k5c5cgo61gmasbp8e35c6cd1	plugin::content-manager.explorer.delete	{}	api::museum.museum	{}	["admin::is-creator"]	2025-12-15 15:33:26.217	2025-12-15 15:33:26.217	2025-12-15 15:33:26.217	\N	\N	\N
117	zpw7k8wzc8uf17xgcyqxpwn8	plugin::content-manager.explorer.delete	{}	api::npc.npc	{}	["admin::is-creator"]	2025-12-15 15:33:26.231	2025-12-15 15:33:26.231	2025-12-15 15:33:26.232	\N	\N	\N
118	pm2nw8ke003i969tp5cw59fu	plugin::content-manager.explorer.delete	{}	api::poi.poi	{}	["admin::is-creator"]	2025-12-15 15:33:26.245	2025-12-15 15:33:26.245	2025-12-15 15:33:26.245	\N	\N	\N
119	usvfftoqz3zdq8fljtg9wlc2	plugin::content-manager.explorer.delete	{}	api::quest.quest	{}	["admin::is-creator"]	2025-12-15 15:33:26.257	2025-12-15 15:33:26.257	2025-12-15 15:33:26.258	\N	\N	\N
120	pu2fkwppxvvv45qltnxon4pv	plugin::content-manager.explorer.delete	{}	api::rarity.rarity	{}	["admin::is-creator"]	2025-12-15 15:33:26.268	2025-12-15 15:33:26.268	2025-12-15 15:33:26.268	\N	\N	\N
121	xetyo8vpar5gnu32miy0j67r	plugin::content-manager.explorer.delete	{}	api::run.run	{}	["admin::is-creator"]	2025-12-15 15:33:26.281	2025-12-15 15:33:26.281	2025-12-15 15:33:26.281	\N	\N	\N
122	vr9lhg2nbw7s1f2bwz1rozzt	plugin::content-manager.explorer.delete	{}	api::tag.tag	{}	["admin::is-creator"]	2025-12-15 15:33:26.294	2025-12-15 15:33:26.294	2025-12-15 15:33:26.294	\N	\N	\N
123	pi0kiceitxktupl71dj6arww	plugin::content-manager.explorer.delete	{}	api::visit.visit	{}	["admin::is-creator"]	2025-12-15 15:33:26.307	2025-12-15 15:33:26.307	2025-12-15 15:33:26.307	\N	\N	\N
124	oq1ua59twa915afykqkxcgi0	plugin::upload.read	{}	\N	{}	["admin::is-creator"]	2025-12-15 15:33:26.32	2025-12-15 15:33:26.32	2025-12-15 15:33:26.32	\N	\N	\N
125	jni46g71iarfajz49e14ztwi	plugin::upload.configure-view	{}	\N	{}	[]	2025-12-15 15:33:26.332	2025-12-15 15:33:26.332	2025-12-15 15:33:26.333	\N	\N	\N
126	s8phgrqq4y8grjyh3hd37xwt	plugin::upload.assets.create	{}	\N	{}	[]	2025-12-15 15:33:26.346	2025-12-15 15:33:26.346	2025-12-15 15:33:26.346	\N	\N	\N
127	y4gw10piz885hfgtpinwgq51	plugin::upload.assets.update	{}	\N	{}	["admin::is-creator"]	2025-12-15 15:33:26.357	2025-12-15 15:33:26.357	2025-12-15 15:33:26.357	\N	\N	\N
128	xun1mqw4rs1cgbepfvkbehk8	plugin::upload.assets.download	{}	\N	{}	[]	2025-12-15 15:33:26.369	2025-12-15 15:33:26.369	2025-12-15 15:33:26.369	\N	\N	\N
129	pa1d327mci0olilgn1hlztw2	plugin::upload.assets.copy-link	{}	\N	{}	[]	2025-12-15 15:33:26.382	2025-12-15 15:33:26.382	2025-12-15 15:33:26.382	\N	\N	\N
130	hbzjt1zqbs6zlwht2yso8xt2	plugin::content-manager.explorer.create	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role", "guild", "age"]}	[]	2025-12-15 15:33:26.482	2025-12-15 15:33:26.482	2025-12-15 15:33:26.482	\N	\N	\N
132	hiiz78z7fl2rzwc85pkf2wrq	plugin::content-manager.explorer.create	{}	api::dialog.dialog	{"fields": ["text_type", "dialogues", "npc"]}	[]	2025-12-15 15:33:26.508	2025-12-15 15:33:26.508	2025-12-15 15:33:26.508	\N	\N	\N
133	ws1pgp6mc9a898644pbig57d	plugin::content-manager.explorer.create	{}	api::friendship.friendship	{"fields": ["quests_entry_unlocked", "expedition_entry_unlocked", "npc", "guild"]}	[]	2025-12-15 15:33:26.525	2025-12-15 15:33:26.525	2025-12-15 15:33:26.525	\N	\N	\N
134	kmphkmuh1bqhzgu025jqzxlm	plugin::content-manager.explorer.create	{}	api::guild.guild	{"fields": ["name", "gold", "exp", "scrap", "user", "characters", "items", "visits", "runs", "friendships", "quests"]}	[]	2025-12-15 15:33:26.539	2025-12-15 15:33:26.539	2025-12-15 15:33:26.539	\N	\N	\N
136	ktlmynepj6l3jwwwobfwbvzv	plugin::content-manager.explorer.create	{}	api::museum.museum	{"fields": ["name", "lat", "lng", "geohash", "tags", "runs", "location", "radius"]}	[]	2025-12-15 15:33:26.565	2025-12-15 15:33:26.565	2025-12-15 15:33:26.566	\N	\N	\N
166	xqimagwlrsfhyeoqp7fkcl7n	plugin::content-manager.explorer.update	{}	api::poi.poi	{"fields": ["name", "lat", "lng", "geohash", "visits", "quests_a", "quests_b", "location"]}	[]	2025-12-15 15:33:26.976	2025-12-15 15:33:26.976	2025-12-15 15:33:26.977	\N	\N	\N
137	i6plw1de767jtn0uowvaicm1	plugin::content-manager.explorer.create	{}	api::npc.npc	{"fields": ["firstname", "lastname", "pronouns", "quests_entry_available", "expedition_entry_available", "friendships", "quests", "dialogs", "runs"]}	[]	2025-12-15 15:33:26.579	2025-12-15 15:33:26.579	2025-12-15 15:33:26.579	\N	\N	\N
138	frf6553zm0laskbxd2jqjp19	plugin::content-manager.explorer.create	{}	api::poi.poi	{"fields": ["name", "lat", "lng", "geohash", "visits", "quests_a", "quests_b", "location"]}	[]	2025-12-15 15:33:26.591	2025-12-15 15:33:26.591	2025-12-15 15:33:26.592	\N	\N	\N
139	rcqf5oloe37d18jfa6j0hesw	plugin::content-manager.explorer.create	{}	api::quest.quest	{"fields": ["is_poi_a_completed", "is_poi_b_completed", "date_start", "date_end", "gold_earned", "xp_earned", "guild", "npc", "poi_a", "poi_b"]}	[]	2025-12-15 15:33:26.604	2025-12-15 15:33:26.604	2025-12-15 15:33:26.605	\N	\N	\N
140	z91i378llgfvnnte296gj7r5	plugin::content-manager.explorer.create	{}	api::rarity.rarity	{"fields": ["name", "items"]}	[]	2025-12-15 15:33:26.616	2025-12-15 15:33:26.616	2025-12-15 15:33:26.616	\N	\N	\N
141	fdsj057uilf8aspcwebr6f6u	plugin::content-manager.explorer.create	{}	api::run.run	{"fields": ["dps", "date_start", "date_end", "gold_earned", "xp_earned", "threshold_reached", "target_threshold", "entry_unlocked", "guild", "museum", "npc", "items"]}	[]	2025-12-15 15:33:26.63	2025-12-15 15:33:26.63	2025-12-15 15:33:26.632	\N	\N	\N
143	a81bmirjw33xwvbwstpo3jg8	plugin::content-manager.explorer.create	{}	api::visit.visit	{"fields": ["open_count", "last_opened_at", "total_gold_earned", "total_exp_earned", "guild", "poi", "items"]}	[]	2025-12-15 15:33:26.657	2025-12-15 15:33:26.657	2025-12-15 15:33:26.658	\N	\N	\N
144	a0dryu6n9bexwjfptg58bxqr	plugin::content-manager.explorer.read	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role", "guild", "age"]}	[]	2025-12-15 15:33:26.67	2025-12-15 15:33:26.67	2025-12-15 15:33:26.67	\N	\N	\N
146	yr8t53xghieh2rvx6au197sj	plugin::content-manager.explorer.read	{}	api::dialog.dialog	{"fields": ["text_type", "dialogues", "npc"]}	[]	2025-12-15 15:33:26.694	2025-12-15 15:33:26.694	2025-12-15 15:33:26.695	\N	\N	\N
147	z0f0b50ho6lppm2pfvdqacca	plugin::content-manager.explorer.read	{}	api::friendship.friendship	{"fields": ["quests_entry_unlocked", "expedition_entry_unlocked", "npc", "guild"]}	[]	2025-12-15 15:33:26.707	2025-12-15 15:33:26.707	2025-12-15 15:33:26.707	\N	\N	\N
148	oy9qc9fesfci93uaxuig7yyc	plugin::content-manager.explorer.read	{}	api::guild.guild	{"fields": ["name", "gold", "exp", "scrap", "user", "characters", "items", "visits", "runs", "friendships", "quests"]}	[]	2025-12-15 15:33:26.719	2025-12-15 15:33:26.719	2025-12-15 15:33:26.719	\N	\N	\N
150	a2gcbqdwt88e103lg0i1n3jo	plugin::content-manager.explorer.read	{}	api::museum.museum	{"fields": ["name", "lat", "lng", "geohash", "tags", "runs", "location", "radius"]}	[]	2025-12-15 15:33:26.744	2025-12-15 15:33:26.744	2025-12-15 15:33:26.744	\N	\N	\N
151	jd3av4i0pqmf0pdzb5uq90xo	plugin::content-manager.explorer.read	{}	api::npc.npc	{"fields": ["firstname", "lastname", "pronouns", "quests_entry_available", "expedition_entry_available", "friendships", "quests", "dialogs", "runs"]}	[]	2025-12-15 15:33:26.756	2025-12-15 15:33:26.756	2025-12-15 15:33:26.756	\N	\N	\N
152	otarlfw3iklppc0utbtkr4yf	plugin::content-manager.explorer.read	{}	api::poi.poi	{"fields": ["name", "lat", "lng", "geohash", "visits", "quests_a", "quests_b", "location"]}	[]	2025-12-15 15:33:26.768	2025-12-15 15:33:26.768	2025-12-15 15:33:26.768	\N	\N	\N
153	tb7km893cehktawgp0nayuod	plugin::content-manager.explorer.read	{}	api::quest.quest	{"fields": ["is_poi_a_completed", "is_poi_b_completed", "date_start", "date_end", "gold_earned", "xp_earned", "guild", "npc", "poi_a", "poi_b"]}	[]	2025-12-15 15:33:26.779	2025-12-15 15:33:26.779	2025-12-15 15:33:26.78	\N	\N	\N
154	ryfbmj3hoqf0b0gitm5pc7x4	plugin::content-manager.explorer.read	{}	api::rarity.rarity	{"fields": ["name", "items"]}	[]	2025-12-15 15:33:26.793	2025-12-15 15:33:26.793	2025-12-15 15:33:26.793	\N	\N	\N
155	gpkac203qycm5jhibm2erh0v	plugin::content-manager.explorer.read	{}	api::run.run	{"fields": ["dps", "date_start", "date_end", "gold_earned", "xp_earned", "threshold_reached", "target_threshold", "entry_unlocked", "guild", "museum", "npc", "items"]}	[]	2025-12-15 15:33:26.805	2025-12-15 15:33:26.805	2025-12-15 15:33:26.805	\N	\N	\N
156	r6xzp49os80g59fwz6iejuwl	plugin::content-manager.explorer.read	{}	api::tag.tag	{"fields": ["name", "items", "museums"]}	[]	2025-12-15 15:33:26.817	2025-12-15 15:33:26.817	2025-12-15 15:33:26.818	\N	\N	\N
157	ii81fwq4hkq3rr48qlcxec6s	plugin::content-manager.explorer.read	{}	api::visit.visit	{"fields": ["open_count", "last_opened_at", "total_gold_earned", "total_exp_earned", "guild", "poi", "items"]}	[]	2025-12-15 15:33:26.83	2025-12-15 15:33:26.83	2025-12-15 15:33:26.83	\N	\N	\N
158	py5vyqlqrzwlug5hclbx2fde	plugin::content-manager.explorer.update	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role", "guild", "age"]}	[]	2025-12-15 15:33:26.842	2025-12-15 15:33:26.842	2025-12-15 15:33:26.842	\N	\N	\N
160	v7mfpkwj1r6ox7535uejgx87	plugin::content-manager.explorer.update	{}	api::dialog.dialog	{"fields": ["text_type", "dialogues", "npc"]}	[]	2025-12-15 15:33:26.88	2025-12-15 15:33:26.88	2025-12-15 15:33:26.88	\N	\N	\N
161	ypu6mqfr6rl42qh8qlo1qce5	plugin::content-manager.explorer.update	{}	api::friendship.friendship	{"fields": ["quests_entry_unlocked", "expedition_entry_unlocked", "npc", "guild"]}	[]	2025-12-15 15:33:26.905	2025-12-15 15:33:26.905	2025-12-15 15:33:26.905	\N	\N	\N
162	z9gb8409zqaw8xz63h45blrg	plugin::content-manager.explorer.update	{}	api::guild.guild	{"fields": ["name", "gold", "exp", "scrap", "user", "characters", "items", "visits", "runs", "friendships", "quests"]}	[]	2025-12-15 15:33:26.925	2025-12-15 15:33:26.925	2025-12-15 15:33:26.925	\N	\N	\N
164	qf849idmgnr4l7n7a6e5xbd7	plugin::content-manager.explorer.update	{}	api::museum.museum	{"fields": ["name", "lat", "lng", "geohash", "tags", "runs", "location", "radius"]}	[]	2025-12-15 15:33:26.951	2025-12-15 15:33:26.951	2025-12-15 15:33:26.951	\N	\N	\N
165	csivvih2cnz6d269t31d7jkd	plugin::content-manager.explorer.update	{}	api::npc.npc	{"fields": ["firstname", "lastname", "pronouns", "quests_entry_available", "expedition_entry_available", "friendships", "quests", "dialogs", "runs"]}	[]	2025-12-15 15:33:26.964	2025-12-15 15:33:26.964	2025-12-15 15:33:26.964	\N	\N	\N
167	nfgko6f3laii9vr2g0tm8xpj	plugin::content-manager.explorer.update	{}	api::quest.quest	{"fields": ["is_poi_a_completed", "is_poi_b_completed", "date_start", "date_end", "gold_earned", "xp_earned", "guild", "npc", "poi_a", "poi_b"]}	[]	2025-12-15 15:33:26.989	2025-12-15 15:33:26.989	2025-12-15 15:33:26.989	\N	\N	\N
168	poapv76wue45v1hwbzbjlksc	plugin::content-manager.explorer.update	{}	api::rarity.rarity	{"fields": ["name", "items"]}	[]	2025-12-15 15:33:27.003	2025-12-15 15:33:27.003	2025-12-15 15:33:27.003	\N	\N	\N
169	y8nn45lfh9vt0q4k7160tdmf	plugin::content-manager.explorer.update	{}	api::run.run	{"fields": ["dps", "date_start", "date_end", "gold_earned", "xp_earned", "threshold_reached", "target_threshold", "entry_unlocked", "guild", "museum", "npc", "items"]}	[]	2025-12-15 15:33:27.016	2025-12-15 15:33:27.016	2025-12-15 15:33:27.017	\N	\N	\N
170	v768r132mszik4du941b1ssb	plugin::content-manager.explorer.update	{}	api::tag.tag	{"fields": ["name", "items", "museums"]}	[]	2025-12-15 15:33:27.029	2025-12-15 15:33:27.029	2025-12-15 15:33:27.029	\N	\N	\N
171	j2xtu2jj198soj2wsn7irro5	plugin::content-manager.explorer.update	{}	api::visit.visit	{"fields": ["open_count", "last_opened_at", "total_gold_earned", "total_exp_earned", "guild", "poi", "items"]}	[]	2025-12-15 15:33:27.041	2025-12-15 15:33:27.041	2025-12-15 15:33:27.042	\N	\N	\N
172	wf9kbchsqnw3ls7893m3jecx	plugin::content-manager.explorer.delete	{}	plugin::users-permissions.user	{}	[]	2025-12-15 15:33:27.054	2025-12-15 15:33:27.054	2025-12-15 15:33:27.054	\N	\N	\N
173	n4zjk7u4s9s03jcruvyka52o	plugin::content-manager.explorer.delete	{}	api::character.character	{}	[]	2025-12-15 15:33:27.072	2025-12-15 15:33:27.072	2025-12-15 15:33:27.073	\N	\N	\N
174	am7bchj139dyee0r8dow4t2b	plugin::content-manager.explorer.delete	{}	api::dialog.dialog	{}	[]	2025-12-15 15:33:27.107	2025-12-15 15:33:27.107	2025-12-15 15:33:27.107	\N	\N	\N
175	zfry1i65zia41si1m1c5u9ft	plugin::content-manager.explorer.delete	{}	api::friendship.friendship	{}	[]	2025-12-15 15:33:27.12	2025-12-15 15:33:27.12	2025-12-15 15:33:27.12	\N	\N	\N
176	dvh2ojpkqp66u36r7qxo4nu9	plugin::content-manager.explorer.delete	{}	api::guild.guild	{}	[]	2025-12-15 15:33:27.133	2025-12-15 15:33:27.133	2025-12-15 15:33:27.133	\N	\N	\N
177	x4betwwmrmvsjj2ureqf6out	plugin::content-manager.explorer.delete	{}	api::item.item	{}	[]	2025-12-15 15:33:27.146	2025-12-15 15:33:27.146	2025-12-15 15:33:27.146	\N	\N	\N
178	up2odlc80wo0905dxhfnju22	plugin::content-manager.explorer.delete	{}	api::museum.museum	{}	[]	2025-12-15 15:33:27.164	2025-12-15 15:33:27.164	2025-12-15 15:33:27.165	\N	\N	\N
179	ydyiraaio9nwfxc5fguncxno	plugin::content-manager.explorer.delete	{}	api::npc.npc	{}	[]	2025-12-15 15:33:27.176	2025-12-15 15:33:27.176	2025-12-15 15:33:27.177	\N	\N	\N
180	rlt2b38e8y7pol6vgho8or40	plugin::content-manager.explorer.delete	{}	api::poi.poi	{}	[]	2025-12-15 15:33:27.19	2025-12-15 15:33:27.19	2025-12-15 15:33:27.19	\N	\N	\N
182	hx8ogzjb4nwqdo4c3mcst52w	plugin::content-manager.explorer.delete	{}	api::rarity.rarity	{}	[]	2025-12-15 15:33:27.215	2025-12-15 15:33:27.215	2025-12-15 15:33:27.215	\N	\N	\N
183	ysq5rarl3rn020cahyum9s6a	plugin::content-manager.explorer.delete	{}	api::run.run	{}	[]	2025-12-15 15:33:27.228	2025-12-15 15:33:27.228	2025-12-15 15:33:27.229	\N	\N	\N
184	hfy5ye07luoa20olbwgxmeam	plugin::content-manager.explorer.delete	{}	api::tag.tag	{}	[]	2025-12-15 15:33:27.242	2025-12-15 15:33:27.242	2025-12-15 15:33:27.242	\N	\N	\N
185	n3brkyxba3s4ifb0yrogxfxt	plugin::content-manager.explorer.delete	{}	api::visit.visit	{}	[]	2025-12-15 15:33:27.255	2025-12-15 15:33:27.255	2025-12-15 15:33:27.255	\N	\N	\N
186	me3vyh6wysinjugj7rodtyjb	plugin::content-manager.explorer.publish	{}	plugin::users-permissions.user	{}	[]	2025-12-15 15:33:27.268	2025-12-15 15:33:27.268	2025-12-15 15:33:27.269	\N	\N	\N
187	z62cap2dgvwqmuewl0diw5h7	plugin::content-manager.explorer.publish	{}	api::character.character	{}	[]	2025-12-15 15:33:27.281	2025-12-15 15:33:27.281	2025-12-15 15:33:27.281	\N	\N	\N
188	xk3ds30rpl5wp6sfvi3nglaq	plugin::content-manager.explorer.publish	{}	api::dialog.dialog	{}	[]	2025-12-15 15:33:27.294	2025-12-15 15:33:27.294	2025-12-15 15:33:27.294	\N	\N	\N
189	mvhzfm9zlxljt54kyklfqe1q	plugin::content-manager.explorer.publish	{}	api::friendship.friendship	{}	[]	2025-12-15 15:33:27.309	2025-12-15 15:33:27.309	2025-12-15 15:33:27.31	\N	\N	\N
190	c5d1enovt2kt2g9tffyupnz2	plugin::content-manager.explorer.publish	{}	api::guild.guild	{}	[]	2025-12-15 15:33:27.323	2025-12-15 15:33:27.323	2025-12-15 15:33:27.323	\N	\N	\N
191	dhue8udxc0li3u127uaptxex	plugin::content-manager.explorer.publish	{}	api::item.item	{}	[]	2025-12-15 15:33:27.337	2025-12-15 15:33:27.337	2025-12-15 15:33:27.338	\N	\N	\N
192	jj3k2c04ef8lqzcmm0jlyh62	plugin::content-manager.explorer.publish	{}	api::museum.museum	{}	[]	2025-12-15 15:33:27.352	2025-12-15 15:33:27.352	2025-12-15 15:33:27.352	\N	\N	\N
193	ok6rsi85wteyefo48e8ytfrc	plugin::content-manager.explorer.publish	{}	api::npc.npc	{}	[]	2025-12-15 15:33:27.364	2025-12-15 15:33:27.364	2025-12-15 15:33:27.365	\N	\N	\N
194	oxwx9bhc953iy9dqder8jl8u	plugin::content-manager.explorer.publish	{}	api::poi.poi	{}	[]	2025-12-15 15:33:27.377	2025-12-15 15:33:27.377	2025-12-15 15:33:27.378	\N	\N	\N
195	gm3l0vitriw2m83ecenzv2f5	plugin::content-manager.explorer.publish	{}	api::quest.quest	{}	[]	2025-12-15 15:33:27.389	2025-12-15 15:33:27.389	2025-12-15 15:33:27.39	\N	\N	\N
196	dgyok48nwq4huohlftw5of17	plugin::content-manager.explorer.publish	{}	api::rarity.rarity	{}	[]	2025-12-15 15:33:27.403	2025-12-15 15:33:27.403	2025-12-15 15:33:27.404	\N	\N	\N
197	ituk6qblgr3qz9me6jnwokkb	plugin::content-manager.explorer.publish	{}	api::run.run	{}	[]	2025-12-15 15:33:27.418	2025-12-15 15:33:27.418	2025-12-15 15:33:27.418	\N	\N	\N
198	loqlqzss1qgvjkw0oyu1iprz	plugin::content-manager.explorer.publish	{}	api::tag.tag	{}	[]	2025-12-15 15:33:27.432	2025-12-15 15:33:27.432	2025-12-15 15:33:27.432	\N	\N	\N
199	wko8kqjtjtoirp11fqyhamxt	plugin::content-manager.explorer.publish	{}	api::visit.visit	{}	[]	2025-12-15 15:33:27.445	2025-12-15 15:33:27.445	2025-12-15 15:33:27.445	\N	\N	\N
200	z2rti42lacte3rjpc19rh2md	plugin::content-manager.single-types.configure-view	{}	\N	{}	[]	2025-12-15 15:33:27.46	2025-12-15 15:33:27.46	2025-12-15 15:33:27.46	\N	\N	\N
201	ajz26ff6tnbp64c0p3tw1csl	plugin::content-manager.collection-types.configure-view	{}	\N	{}	[]	2025-12-15 15:33:27.474	2025-12-15 15:33:27.474	2025-12-15 15:33:27.474	\N	\N	\N
202	l37u7xg3unlvny89ikys27xu	plugin::content-manager.components.configure-layout	{}	\N	{}	[]	2025-12-15 15:33:27.487	2025-12-15 15:33:27.487	2025-12-15 15:33:27.487	\N	\N	\N
203	lv440vpyan2504rxntiqv8pj	plugin::content-type-builder.read	{}	\N	{}	[]	2025-12-15 15:33:27.501	2025-12-15 15:33:27.501	2025-12-15 15:33:27.501	\N	\N	\N
204	cbj4yied4dnvwevnjexpi6hj	plugin::email.settings.read	{}	\N	{}	[]	2025-12-15 15:33:27.515	2025-12-15 15:33:27.515	2025-12-15 15:33:27.515	\N	\N	\N
205	vkamcc2giu848snrhgz77ekn	plugin::upload.read	{}	\N	{}	[]	2025-12-15 15:33:27.53	2025-12-15 15:33:27.53	2025-12-15 15:33:27.531	\N	\N	\N
206	de9d9awjzukg6a5saoityuw0	plugin::upload.assets.create	{}	\N	{}	[]	2025-12-15 15:33:27.544	2025-12-15 15:33:27.544	2025-12-15 15:33:27.544	\N	\N	\N
207	u9lbvksh1gynhp6awfuvqsna	plugin::upload.assets.update	{}	\N	{}	[]	2025-12-15 15:33:27.558	2025-12-15 15:33:27.558	2025-12-15 15:33:27.558	\N	\N	\N
208	legg5wx1e42dp0ma3vr53iat	plugin::upload.assets.download	{}	\N	{}	[]	2025-12-15 15:33:27.572	2025-12-15 15:33:27.572	2025-12-15 15:33:27.572	\N	\N	\N
209	ba9u4gjdi0sf5atvltys5q4l	plugin::upload.assets.copy-link	{}	\N	{}	[]	2025-12-15 15:33:27.584	2025-12-15 15:33:27.584	2025-12-15 15:33:27.585	\N	\N	\N
210	oqnrocu48e0vmraui0hmefmv	plugin::upload.configure-view	{}	\N	{}	[]	2025-12-15 15:33:27.599	2025-12-15 15:33:27.599	2025-12-15 15:33:27.599	\N	\N	\N
211	jcw0hkgatgizpujk9v1zkt5o	plugin::upload.settings.read	{}	\N	{}	[]	2025-12-15 15:33:27.612	2025-12-15 15:33:27.612	2025-12-15 15:33:27.612	\N	\N	\N
212	ede27y6f90awrzv14az2ibss	plugin::i18n.locale.create	{}	\N	{}	[]	2025-12-15 15:33:27.624	2025-12-15 15:33:27.624	2025-12-15 15:33:27.625	\N	\N	\N
213	flsujskkzclv4uuna2exej8i	plugin::i18n.locale.read	{}	\N	{}	[]	2025-12-15 15:33:27.636	2025-12-15 15:33:27.636	2025-12-15 15:33:27.636	\N	\N	\N
214	po2y0ck2tuuednwo824vvgom	plugin::i18n.locale.update	{}	\N	{}	[]	2025-12-15 15:33:27.65	2025-12-15 15:33:27.65	2025-12-15 15:33:27.65	\N	\N	\N
215	z80fc1ry61sdkjpns3le8hyy	plugin::i18n.locale.delete	{}	\N	{}	[]	2025-12-15 15:33:27.662	2025-12-15 15:33:27.662	2025-12-15 15:33:27.663	\N	\N	\N
216	t50cg7h43nhdkcms6igubf2q	plugin::users-permissions.roles.create	{}	\N	{}	[]	2025-12-15 15:33:27.677	2025-12-15 15:33:27.677	2025-12-15 15:33:27.677	\N	\N	\N
217	lasu4m5utlgwvm8b34qytz7q	plugin::users-permissions.roles.read	{}	\N	{}	[]	2025-12-15 15:33:27.691	2025-12-15 15:33:27.691	2025-12-15 15:33:27.691	\N	\N	\N
218	d8ckogny7ys1t5lu3x2p9noz	plugin::users-permissions.roles.update	{}	\N	{}	[]	2025-12-15 15:33:27.703	2025-12-15 15:33:27.703	2025-12-15 15:33:27.704	\N	\N	\N
219	kha6j8s3swv9fk2n3vzvofkz	plugin::users-permissions.roles.delete	{}	\N	{}	[]	2025-12-15 15:33:27.718	2025-12-15 15:33:27.718	2025-12-15 15:33:27.718	\N	\N	\N
220	gg4brwcoy4lofwoflk0fy1zq	plugin::users-permissions.providers.read	{}	\N	{}	[]	2025-12-15 15:33:27.731	2025-12-15 15:33:27.731	2025-12-15 15:33:27.731	\N	\N	\N
221	okq6o91co2dosmrfl98nmith	plugin::users-permissions.providers.update	{}	\N	{}	[]	2025-12-15 15:33:27.745	2025-12-15 15:33:27.745	2025-12-15 15:33:27.745	\N	\N	\N
222	gcn8fauajdessfwfj2tkb3yq	plugin::users-permissions.email-templates.read	{}	\N	{}	[]	2025-12-15 15:33:27.762	2025-12-15 15:33:27.762	2025-12-15 15:33:27.762	\N	\N	\N
223	hh6kvwslkdf66x0pp6jkyvpq	plugin::users-permissions.email-templates.update	{}	\N	{}	[]	2025-12-15 15:33:27.775	2025-12-15 15:33:27.775	2025-12-15 15:33:27.775	\N	\N	\N
224	b3j9safglwd3jrdz2cl2dz62	plugin::users-permissions.advanced-settings.read	{}	\N	{}	[]	2025-12-15 15:33:27.789	2025-12-15 15:33:27.789	2025-12-15 15:33:27.789	\N	\N	\N
225	u80ln0fotdn8l7j5ahvay1xm	plugin::users-permissions.advanced-settings.update	{}	\N	{}	[]	2025-12-15 15:33:27.801	2025-12-15 15:33:27.801	2025-12-15 15:33:27.801	\N	\N	\N
226	qekdi8os5vz1hnabo0v0lg4s	admin::marketplace.read	{}	\N	{}	[]	2025-12-15 15:33:27.813	2025-12-15 15:33:27.813	2025-12-15 15:33:27.814	\N	\N	\N
227	ilzf88xxi0ggrjknh49i28st	admin::webhooks.create	{}	\N	{}	[]	2025-12-15 15:33:27.826	2025-12-15 15:33:27.826	2025-12-15 15:33:27.826	\N	\N	\N
228	n9mlw4bd9r6qk1qm6r7qi8ke	admin::webhooks.read	{}	\N	{}	[]	2025-12-15 15:33:27.838	2025-12-15 15:33:27.838	2025-12-15 15:33:27.838	\N	\N	\N
229	ofyv80v09aua6v4kjll63pvx	admin::webhooks.update	{}	\N	{}	[]	2025-12-15 15:33:27.85	2025-12-15 15:33:27.85	2025-12-15 15:33:27.85	\N	\N	\N
230	p8o97mtmkvh6fis6t4af0ivc	admin::webhooks.delete	{}	\N	{}	[]	2025-12-15 15:33:27.863	2025-12-15 15:33:27.863	2025-12-15 15:33:27.863	\N	\N	\N
231	fj5096acslqgv1cqudnbskch	admin::users.create	{}	\N	{}	[]	2025-12-15 15:33:27.875	2025-12-15 15:33:27.875	2025-12-15 15:33:27.875	\N	\N	\N
232	gp1qpqeprswhvn64zfcujno5	admin::users.read	{}	\N	{}	[]	2025-12-15 15:33:27.888	2025-12-15 15:33:27.888	2025-12-15 15:33:27.888	\N	\N	\N
233	dv4ngyqrb8cpythxjto61yhd	admin::users.update	{}	\N	{}	[]	2025-12-15 15:33:27.901	2025-12-15 15:33:27.901	2025-12-15 15:33:27.901	\N	\N	\N
234	chtrdx2b2kqzsxcd6vhdy4je	admin::users.delete	{}	\N	{}	[]	2025-12-15 15:33:27.914	2025-12-15 15:33:27.914	2025-12-15 15:33:27.914	\N	\N	\N
235	tf85zc4enonixsfem2nzen08	admin::roles.create	{}	\N	{}	[]	2025-12-15 15:33:27.926	2025-12-15 15:33:27.926	2025-12-15 15:33:27.926	\N	\N	\N
236	z4orylms6vo113z5cso0pq6c	admin::roles.read	{}	\N	{}	[]	2025-12-15 15:33:27.938	2025-12-15 15:33:27.938	2025-12-15 15:33:27.938	\N	\N	\N
237	q37tfxt2rlzbud7ypv2ovn08	admin::roles.update	{}	\N	{}	[]	2025-12-15 15:33:27.951	2025-12-15 15:33:27.951	2025-12-15 15:33:27.951	\N	\N	\N
238	ot79ctb0g4fv6i2oypbt70gy	admin::roles.delete	{}	\N	{}	[]	2025-12-15 15:33:27.965	2025-12-15 15:33:27.965	2025-12-15 15:33:27.965	\N	\N	\N
239	mhdc6gv8huy163ljk0wr7ub4	admin::api-tokens.access	{}	\N	{}	[]	2025-12-15 15:33:27.978	2025-12-15 15:33:27.978	2025-12-15 15:33:27.979	\N	\N	\N
240	ibuxy6wli7zi68awk73o4yhb	admin::api-tokens.create	{}	\N	{}	[]	2025-12-15 15:33:27.993	2025-12-15 15:33:27.993	2025-12-15 15:33:27.993	\N	\N	\N
241	yy5zfxlu45zg8ul0rm23ijjy	admin::api-tokens.read	{}	\N	{}	[]	2025-12-15 15:33:28.007	2025-12-15 15:33:28.007	2025-12-15 15:33:28.007	\N	\N	\N
242	rsh8ntemni2zth3s7kmr90cn	admin::api-tokens.update	{}	\N	{}	[]	2025-12-15 15:33:28.02	2025-12-15 15:33:28.02	2025-12-15 15:33:28.021	\N	\N	\N
243	mg8qzbuynwmnphnpird24d91	admin::api-tokens.regenerate	{}	\N	{}	[]	2025-12-15 15:33:28.035	2025-12-15 15:33:28.035	2025-12-15 15:33:28.035	\N	\N	\N
244	zvi6maly2jefif4o6cz2m8o7	admin::api-tokens.delete	{}	\N	{}	[]	2025-12-15 15:33:28.048	2025-12-15 15:33:28.048	2025-12-15 15:33:28.048	\N	\N	\N
245	tszhzm7e2qdmdtyanhc769x6	admin::project-settings.update	{}	\N	{}	[]	2025-12-15 15:33:28.06	2025-12-15 15:33:28.06	2025-12-15 15:33:28.06	\N	\N	\N
246	se69dedhywbi8flzuk05w0r5	admin::project-settings.read	{}	\N	{}	[]	2025-12-15 15:33:28.069	2025-12-15 15:33:28.069	2025-12-15 15:33:28.07	\N	\N	\N
247	cs57nbt9ondkhl3xe8yio67f	admin::transfer.tokens.access	{}	\N	{}	[]	2025-12-15 15:33:28.08	2025-12-15 15:33:28.08	2025-12-15 15:33:28.08	\N	\N	\N
248	iw6n7italcxmd47e6nq6szmu	admin::transfer.tokens.create	{}	\N	{}	[]	2025-12-15 15:33:28.101	2025-12-15 15:33:28.101	2025-12-15 15:33:28.102	\N	\N	\N
249	f528ie7twwip7j6xb8ll32wu	admin::transfer.tokens.read	{}	\N	{}	[]	2025-12-15 15:33:28.112	2025-12-15 15:33:28.112	2025-12-15 15:33:28.113	\N	\N	\N
250	pg8v63mnj328b6uaxtm4lgmi	admin::transfer.tokens.update	{}	\N	{}	[]	2025-12-15 15:33:28.126	2025-12-15 15:33:28.126	2025-12-15 15:33:28.126	\N	\N	\N
251	wp76isu2arbaziuhkngu9sme	admin::transfer.tokens.regenerate	{}	\N	{}	[]	2025-12-15 15:33:28.138	2025-12-15 15:33:28.138	2025-12-15 15:33:28.139	\N	\N	\N
252	b8h0rxhs5lrhie49y9m9tl1z	admin::transfer.tokens.delete	{}	\N	{}	[]	2025-12-15 15:33:28.15	2025-12-15 15:33:28.15	2025-12-15 15:33:28.151	\N	\N	\N
253	jp4uoubnq1fuoe3nw2lczxyc	plugin::content-manager.explorer.create	{}	api::item.item	{"fields": ["name", "level", "index_damage", "slot", "isScrapped", "rarity", "guild", "character", "tags", "runs", "visits", "icon"]}	[]	2025-12-18 11:20:00.159	2025-12-18 11:20:00.159	2025-12-18 11:20:00.16	\N	\N	\N
254	h49pqhyrsris1t98jho47z95	plugin::content-manager.explorer.read	{}	api::item.item	{"fields": ["name", "level", "index_damage", "slot", "isScrapped", "rarity", "guild", "character", "tags", "runs", "visits", "icon"]}	[]	2025-12-18 11:20:00.176	2025-12-18 11:20:00.176	2025-12-18 11:20:00.177	\N	\N	\N
255	qn6kl653yaxrcz7e0tmnk46d	plugin::content-manager.explorer.update	{}	api::item.item	{"fields": ["name", "level", "index_damage", "slot", "isScrapped", "rarity", "guild", "character", "tags", "runs", "visits", "icon"]}	[]	2025-12-18 11:20:00.183	2025-12-18 11:20:00.183	2025-12-18 11:20:00.184	\N	\N	\N
256	fhd3l0proa6o2u5fzdy2op5w	plugin::content-manager.explorer.create	{}	api::character.character	{"fields": ["firstname", "lastname", "guild", "items", "icon"]}	[]	2025-12-18 13:19:42.421	2025-12-18 13:19:42.421	2025-12-18 13:19:42.422	\N	\N	\N
257	nd3de9l0axr3u9edbxeu4fwd	plugin::content-manager.explorer.read	{}	api::character.character	{"fields": ["firstname", "lastname", "guild", "items", "icon"]}	[]	2025-12-18 13:19:42.44	2025-12-18 13:19:42.44	2025-12-18 13:19:42.44	\N	\N	\N
258	n9r1soya8ume15rufnsevnjo	plugin::content-manager.explorer.update	{}	api::character.character	{"fields": ["firstname", "lastname", "guild", "items", "icon"]}	[]	2025-12-18 13:19:42.46	2025-12-18 13:19:42.46	2025-12-18 13:19:42.46	\N	\N	\N
1	dunup29i5ba4rrklrkjqjk1v	plugin::content-manager.explorer.create	{}	api::character.character	{"fields": ["firstname", "lastname", "guild", "items"]}	[]	2025-12-15 15:33:24.282	2025-12-18 13:19:42.523	2025-12-15 15:33:24.283	\N	\N	\N
14	nahunm856v2h3pzcumg9035x	plugin::content-manager.explorer.read	{}	api::character.character	{"fields": ["firstname", "lastname", "guild", "items"]}	[]	2025-12-15 15:33:24.547	2025-12-18 13:19:42.523	2025-12-15 15:33:24.547	\N	\N	\N
98	ffu9c92vaf68n4gcfisouj9s	plugin::content-manager.explorer.update	{}	api::character.character	{"fields": ["firstname", "lastname", "guild", "items"]}	["admin::is-creator"]	2025-12-15 15:33:25.991	2025-12-18 13:19:42.523	2025-12-15 15:33:25.991	\N	\N	\N
72	a2lnn9ecborz1cg03ol1ies4	plugin::content-manager.explorer.create	{}	api::character.character	{"fields": ["firstname", "lastname", "guild", "items"]}	["admin::is-creator"]	2025-12-15 15:33:25.547	2025-12-18 13:19:42.523	2025-12-15 15:33:25.548	\N	\N	\N
85	k1o6jtmw9gyoua9gsdkb3k10	plugin::content-manager.explorer.read	{}	api::character.character	{"fields": ["firstname", "lastname", "guild", "items"]}	["admin::is-creator"]	2025-12-15 15:33:25.726	2025-12-18 13:19:42.523	2025-12-15 15:33:25.726	\N	\N	\N
\.


--
-- Data for Name: admin_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	2	1
2	2	2	2
3	3	2	3
4	4	2	4
5	5	2	5
6	6	2	6
7	7	2	7
8	8	2	8
9	9	2	9
10	10	2	10
11	11	2	11
12	12	2	12
13	13	2	13
14	14	2	14
15	15	2	15
16	16	2	16
17	17	2	17
18	18	2	18
19	19	2	19
20	20	2	20
21	21	2	21
22	22	2	22
23	23	2	23
24	24	2	24
25	25	2	25
26	26	2	26
27	27	2	27
28	28	2	28
29	29	2	29
30	30	2	30
31	31	2	31
32	32	2	32
33	33	2	33
34	34	2	34
35	35	2	35
36	36	2	36
37	37	2	37
38	38	2	38
39	39	2	39
40	40	2	40
41	41	2	41
42	42	2	42
43	43	2	43
44	44	2	44
45	45	2	45
46	46	2	46
47	47	2	47
48	48	2	48
49	49	2	49
50	50	2	50
51	51	2	51
52	52	2	52
53	53	2	53
54	54	2	54
55	55	2	55
56	56	2	56
57	57	2	57
58	58	2	58
59	59	2	59
60	60	2	60
61	61	2	61
62	62	2	62
63	63	2	63
64	64	2	64
65	65	2	65
66	66	2	66
67	67	2	67
68	68	2	68
69	69	2	69
70	70	2	70
71	71	2	71
72	72	3	1
73	73	3	2
74	74	3	3
75	75	3	4
76	76	3	5
77	77	3	6
78	78	3	7
79	79	3	8
80	80	3	9
81	81	3	10
82	82	3	11
83	83	3	12
84	84	3	13
85	85	3	14
86	86	3	15
87	87	3	16
88	88	3	17
89	89	3	18
90	90	3	19
91	91	3	20
92	92	3	21
93	93	3	22
94	94	3	23
95	95	3	24
96	96	3	25
97	97	3	26
98	98	3	27
99	99	3	28
100	100	3	29
101	101	3	30
102	102	3	31
103	103	3	32
104	104	3	33
105	105	3	34
106	106	3	35
107	107	3	36
108	108	3	37
109	109	3	38
110	110	3	39
111	111	3	40
112	112	3	41
113	113	3	42
114	114	3	43
115	115	3	44
116	116	3	45
117	117	3	46
118	118	3	47
119	119	3	48
120	120	3	49
121	121	3	50
122	122	3	51
123	123	3	52
124	124	3	53
125	125	3	54
126	126	3	55
127	127	3	56
128	128	3	57
129	129	3	58
130	130	1	1
132	132	1	3
133	133	1	4
134	134	1	5
136	136	1	7
137	137	1	8
138	138	1	9
139	139	1	10
140	140	1	11
141	141	1	12
142	142	1	13
143	143	1	14
144	144	1	15
146	146	1	17
147	147	1	18
148	148	1	19
150	150	1	21
151	151	1	22
152	152	1	23
153	153	1	24
154	154	1	25
155	155	1	26
156	156	1	27
157	157	1	28
158	158	1	29
160	160	1	31
161	161	1	32
162	162	1	33
164	164	1	35
165	165	1	36
166	166	1	37
167	167	1	38
168	168	1	39
169	169	1	40
170	170	1	41
171	171	1	42
172	172	1	43
173	173	1	44
174	174	1	45
175	175	1	46
176	176	1	47
177	177	1	48
178	178	1	49
179	179	1	50
180	180	1	51
181	181	1	52
182	182	1	53
183	183	1	54
184	184	1	55
185	185	1	56
186	186	1	57
187	187	1	58
188	188	1	59
189	189	1	60
190	190	1	61
191	191	1	62
192	192	1	63
193	193	1	64
194	194	1	65
195	195	1	66
196	196	1	67
197	197	1	68
198	198	1	69
199	199	1	70
200	200	1	71
201	201	1	72
202	202	1	73
203	203	1	74
204	204	1	75
205	205	1	76
206	206	1	77
207	207	1	78
208	208	1	79
209	209	1	80
210	210	1	81
211	211	1	82
212	212	1	83
213	213	1	84
214	214	1	85
215	215	1	86
216	216	1	87
217	217	1	88
218	218	1	89
219	219	1	90
220	220	1	91
221	221	1	92
222	222	1	93
223	223	1	94
224	224	1	95
225	225	1	96
226	226	1	97
227	227	1	98
228	228	1	99
229	229	1	100
230	230	1	101
231	231	1	102
232	232	1	103
233	233	1	104
234	234	1	105
235	235	1	106
236	236	1	107
237	237	1	108
238	238	1	109
239	239	1	110
240	240	1	111
241	241	1	112
242	242	1	113
243	243	1	114
244	244	1	115
245	245	1	116
246	246	1	117
247	247	1	118
248	248	1	119
249	249	1	120
250	250	1	121
251	251	1	122
252	252	1	123
253	253	1	124
254	254	1	125
255	255	1	126
256	256	1	127
257	257	1	128
258	258	1	129
\.


--
-- Data for Name: admin_roles; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_roles (id, document_id, name, code, description, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	xz8t4c4qd2p0qr8jgqs9abgs	Super Admin	strapi-super-admin	Super Admins can access and manage all features and settings.	2025-12-15 15:33:24.14	2025-12-15 15:33:24.14	2025-12-15 15:33:24.141	\N	\N	\N
2	x4fiqlsweqey02niuwm545uu	Editor	strapi-editor	Editors can manage and publish contents including those of other users.	2025-12-15 15:33:24.173	2025-12-15 15:33:24.173	2025-12-15 15:33:24.174	\N	\N	\N
3	nutvhsnvh42ocl39oq3oqzak	Author	strapi-author	Authors can manage the content they have created.	2025-12-15 15:33:24.185	2025-12-15 15:33:24.185	2025-12-15 15:33:24.185	\N	\N	\N
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_users (id, document_id, firstname, lastname, username, email, password, reset_password_token, registration_token, is_active, blocked, prefered_language, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	m1v8peryr1xg97m6ssktinw3	Brice	Ledanois	\N	ledanoisb@gmail.com	$2a$10$Kvq0ml0Quvy9cLvTJW1bful1qJVyGOwDb8uF7zFdKD/wXilCbugOm	\N	\N	t	f	\N	2025-12-15 15:38:32.98	2025-12-15 15:38:32.98	2025-12-15 15:38:32.981	\N	\N	\N
2	uvj6nrdn31oiox9p94s5hivi	Ethan	Raulin	\N	rauleth31@gmail.com	$2a$10$6yB6d4H8EQM0hcbM38RS9eIyZBTZjuWgseiWq4Z.mS9X9152oOPIi	\N	4b8b8400be2692eb60bb69ee4238d206c63cb84e	t	f	\N	2026-01-03 14:54:07.17	2026-01-03 14:55:04.079	2026-01-03 14:54:07.171	\N	\N	\N
3	ag4kuw3rzzfmetnbtpywk38p	Lelio	Buton	\N	buton1@live.fr	$2a$10$2P1BFMmeMk6.0FIoOWZHBeWxVALKYAFDh6fOCZ7N4gcWIvCAoqyKq	\N	b971b3e6d401aeeaf6dda84d4e663837e447d6b3	t	f	\N	2026-01-03 14:55:27.036	2026-01-03 14:58:02.139	2026-01-03 14:55:27.037	\N	\N	\N
\.


--
-- Data for Name: admin_users_roles_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.admin_users_roles_lnk (id, user_id, role_id, role_ord, user_ord) FROM stdin;
1	1	1	1	1
2	2	1	1	2
4	3	1	1	3
\.


--
-- Data for Name: characters; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.characters (id, document_id, firstname, lastname, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
15	zmvggytxqjq53s6k2rqrlpd5	Zoldrak		2025-12-29 01:30:11.981	2025-12-29 01:30:11.981	\N	\N	\N	\N
\.


--
-- Data for Name: characters_guild_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.characters_guild_lnk (id, character_id, guild_id, character_ord) FROM stdin;
19	15	10	1
\.


--
-- Data for Name: dialogs; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.dialogs (id, document_id, text_type, dialogues, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
7	gmcgtrdqsimkxprozrh6nw4i	journal_entries	["Il a y a une vingtaine d'année, Denrick s'est fait un nom auprès des jeunes recrues au sein de l'armée royale. Connu pour avoir non seulement participé à déjouer un complot contre la couronne, selon les rumeurs il serait l'un des seuls à avoir eu la chance et l'honneur de voir Monarque de ses propres yeux.. ou plutôt de son propre œil. Car dans l'armée, honneur rime souvent avec horreur. Son fait d'arme lui ayant couté un des ses yeux, il a décidé de prendre sa retraite pour ne plus jamais avoir à manier l'épée autrement que pour se défendre. Il aurait pu se lancer dans une carrière politique mais a décider de rester proche de ce par quoi il a toujours vécu. Malgré sa main en moins, il se donne toujours à fond pour forger des armes aussi belles et puissante que ce qu'il avait pour habitude de manier. \\"Qui vivra par l'épée mourra par l'épée\\" il est donc persuadé que quelqu'un viendra un jour se venger. Et il décide de vivre chaque seconde comme si c'était la dernière de sa vie.", "D'aucun pense qu'il a trouvé sa rédemption aux côtés d'Adra, à former des plus jeunes. Il fait tout son possible pour avertir les plus jeunes sur la vie de soldat. Cependant, quand il voit dans les yeux de certains la flamme. Cette flamme qui a parfois vibrer dans ces propres yeux. La flamme de la détermination, la flamme de la volonté. Cette flamme qui montre l'envie de se dépasser pour atteindre certains sommets. Alors devant ces âmes brûlante de témérité, Denrick le Forgeron voit son feu intérieur ravivé et se donne corps et âme dans la formation des élèves.", "Lorsqu'il était jeune, Denrick était dans un fiacre avec son père et sa mère. Il fut arrêté au milieu de la forêt. Lorsque la porte s'ouvrit, il vu un homme, d'un mètre quatre-vingts, dans la vingtaine, les cheveux brun et les yeux verrons. Son regard perçait les ténèbres de la porte, son œil gauche, bleu gris, semblait vif, balayant entre chaque personne à l'intérieur. Le droit, noisette ambré, lui semblait presque vide. Comme plus lent il semblait presque suivre les mouvements de son homologue. À l'inverse de ce qu'on pourrait penser, Denrick a vu en lui une forme inspirante. Quelqu'un de libre, faisant ce qu'il voulait, faisant fî des conséquences. Il a alors grandi en idéalisant ce bandit, au plus grand détriment de son père d'ailleurs.", "Quand il eu 20 ans, Denrick eut envie d'embrasser cette vie de hors-la-loi. Il se prépara donc à cambrioler un échoppe quand soudain, alors qu'il fut sur le point de se lancer, il senti une main sur son épaule. En se retournant, il vit un vieux soldat, la mine sombre, les yeux fatigués. Denrick cru alors qu'il était fichu. \\"Qui vivra par l'épée mourra par l'épée\\". À ces mots Denrick regarda plus attentivement les yeux du soldat et reconnu ces mêmes yeux verrons qui, 10 ans auparavant, l'avaient tant marqué. Il s'effondra alors au sol, désespéré. À grande surprise, le soldat lui dit simplement de rentrer chez lui. C'est ainsi qu'il décida de rentrer chez lui et de se préparer au concours de soldat pour suivre les traces de celui qu'il a considéré, par deux fois, comme son mentor."]	2025-12-15 15:41:25.657	2025-12-15 15:44:47.781	\N	\N	1	\N
5	tlcuupvpmtqn4rsjygpzz1gn	journal_entries	["Espiègle et qui aime le sarcasme Toben le Meunier a pour habitude de toujours tourner en dérision les personnes qui lui demande un service. Encore en conflit avec Garen le Chasseur et Joric le Tavernier car trop directe et manquant souvent de tact, il n'hésite pas à dire tout haut ce qu'il pense d'eux. Beaucoup pourrait donc le trouver bourru et antipathique. Mais certains savent qu'en réalité Toben teste les gens. Il observe leurs réactions, jauge leurs limites. Et si quelqu'un lui répond du tac au tac, voir même rigole aux pics de Toben, alors celui-ci devient presque plus doux. Comme ci, au travers de ses joutes verbal, Toben cherchait plus quelqu'un avec qui dialoguer et qui pourrait le comprendre.", "Cependant, il a pour habitude de toujours faire plus de pain que nécessaire et de donner le surplus aux plus démunies. Toujours en râlant bien sûr, presque même en insultant les personnes qu'il aide. Comme si la générosité le mettait mal à l'aise. Comme s'il avait peur que la communauté puisse voir une forme de faiblesse derrière la main qu'il tend. Mais malgré tout, Toben reviendra encore le lendemain aider ceux qui en ont besoin. Personne ne l'a jamais vu refuser un ventre vide. Comme s'il savait exactement ce que ça faisait que d'avoir faim.", "N'ayant jamais connu son père et après avoir perdu sa mère, il a apprit tôt à manipuler et trahir les gens qui lui tendaient la main, convaincu que la générosité n'existait pas et que personne ne lui donnerait rien sans attendre une contrepartie en retour. Toben a connu la famine, le froid et la maladie. Il a connu la violence, la peur et la honte de voler du pain pour survivre. Ce passé l'a rendu méfiant et parfois en désaccord avec l'ordre établi, mais il l'a rendu aussi d'une incroyable résilience.", "Depuis plusieurs années les incursions des monstres se font rare. Mais Toben n'a jamais oublié la nuit où ils ont assassiné sa famille en même temps que sa naïveté d'enfant. Alors qu'il voyait les gens fuir autour de lui, il ne cessait de se répéter que les gardes allaient bientôt arriver pour les protéger. Après tout ils avaient juré de tous les protéger. Mais il a alors senti quelqu'un le tirer violemment en arrière. Sa propre mère l'a alors plaqué au sol, le recouvrant. \\"Ne fait plus de bruit. Retiens ton souffle. Ne dis plus rien.\\". Les paroles de sa mère ont résonné en boucle dans sa tête. Il se les répétait alors qu'il sentait la chaleur quitter petit à petit le corps de sa propre mère. Et c'est là, caché, qu'il a observé les monstres de près pour la première fois. Leurs mouvements, leurs bruits, leurs rythmes même. Il les as observés pendant des heures et des heures, jusqu'à ce que les gardes arrivent. Ce que personne n'a envie de voir, lui l'a vécu, contre son gré, ce jour là. Depuis ce jour Toben connait les monstres mieux que beaucoup de gardes entraînés."]	2025-12-15 15:41:25.559	2025-12-15 15:46:51.845	\N	\N	1	\N
1	u54f61gakix2nh6uazbib0k7	journal_entries	["Malori, aussi nommé Lori par ses connaissances, est une postière autant maladroite que dévoué dans son travail. Elle parcours les terres de Culturia livrant lettres et colis parfois plus ou moins douteux. \\"Cela fait parti du boulot n'est-ce pas ?\\", ce répète t-elle sans cesses. Elle est bien consciente que son patron l'utilise un peu trop, mais faire de son mieux est son leitmotiv. Sa plus grande gaffe : Renverser malheureusement une potion de croissance accéléré sur des ronces, cela à coupé la route pendant plusieurs jours. Personne ne le sait, enfin c'est-ce qu'elle croit.", "La famille Marnett vous dis quelque choses, maitre de guilde. Cette famille est connu dans la cour en tant qu'exécutant ou conseillés de Monarque. D'après des rumeurs, le nom de Malori viendrais de sa mère, Vlori Marnett une discrète conseillère au trône. Issue d'une union secrète entre sa mère et un soldat, Malori est exilé très tôt des rempares, depuis elle à toujours vécu avec sa tante jusqu'à sa très ressente émancipation. L'idée de retourner à la soie lui déplait, jugeant être plus utile au peuple qu'à la royauté.", "Il y a quelques semaines, vous voyez Malori régulièrement aller à la taverne. Au delà d'étancher sa fatigue à coup de peinte, elle bois souvent à une table seule penné par la solitude de vivre seule. Malgré les contacts régulier avec ses clients, se confesser est très dur. Pour se vider la tête et passer du bon temps, elle se rend régulièrement chez l'ancien, Haldo, où ils discutent hypothèses et réflexion plus ou moins pertinente. De son jeune âge Malori à tant à apprendre, elle en ait persuadé.", "Malgré l'énergie débordante et la maladresse caractéristique de Malori qui fait son charme, plusieurs personnes sont méfiantes à propos d'elle. À force de vouloir prouver sa valeur, elle en perd souvent le sens des priorités et ne prend pas assez de temps pour elle. \\"C'est en faisant trop qu'elle va se perdre\\" a-t-elle entendu il y a longtemps à propos d'elle. Depuis, la maladresse est devenu une de ses caractéristiques. Son plus gros défaut est qu'elle ne se laisse pas le temps de grandir et veux déjà adosser des responsabilités qu'elle ne peux pas tenir. Peut-être en lien avec sa mère. Qui sait ?"]	2025-12-15 15:41:25.34	2025-12-15 15:47:12.207	\N	\N	1	\N
13	umglbpbnjhjqlnw85y7bq36a	journal_entries	["Toren, depuis son enfance, se tient le dos droit. Regardant droit devant lui, ne répondant que quand c'est nécessaire, que quand c'est justifié. Habitué aux cérémonies depuis son enfance où il se tenait aux côtés de son père, il n'était là que comme symbole de la réussite familiale. \\"Qu'il est poli !\\", \\"Comme il est sage !\\". Autant de compliment qu'il s'avait n'était pas dirigé à lui mais plus à son paternel, Orren Brauvin.", "Lors de son adolescence, Toren a voyagé à travers tous le pays pour sa formation. Son père avait de grand projet pour lui et il le savait. Etudier jusqu'à l'aube, dormir quelques heures à peine, visiter les plus grands chantier du pays des le matin, assister à des représentations l'après-midi, manger à la table des plus grand le soir et se remettre à ses livres juste après. Ce fut son quotidien pendant de nombreuses années. Aujourd'hui quand Toren regarde en arrière, il se souvient de ses années comme celles où il s'est perdu lui même. Face à la pression, face à la peur des responsabilités, Toren aujourd'hui est toujours la cible de nombreuses angoisses et cauchemars le réveillant à toutes les heures de la nuit.", "Relativement fortuné et notamment grâce à l'héritage de ses parents eux aussi architectes, Toren a développé très tôt une passion pour le dessin et un attrait pour l'argent. En voulant rendre son géniteur fier de lui, il a essayé d'augmenter les bénéfices des chantiers en réduisant les salaires et en baissant la qualité des matériaux de construction. Malheureusement, c'est quand il fut missionné de l'un des plus grand chantiers du pays que le scandale a été révélé par Tessa la Mercenaire. Il ne faisait pas que couper son ciment à l'eau, il ne respectait même aucune des normes de sécurité instauré dans le pays par le gouvernement de Monarque. Toren n'a jamais vu autant de déception dans le regard de son père, mais quel ne fut pas sa surprise quand il découvrit dans les journaux que son père s'était livré de son propre chef aux gardes. Se dénonçant à la place de son fils. Depuis Toren porte une haine envers la mercenaire et lui même.", "Aujourd'hui, Toren s'efforce de redorer son image en redoublant de perspicacité dans ces travaux. Il a décidé de grandir et d'évoluer, il s'est rendu compte qu'il ne voulait plus de cette vie. Après avoir entendu des rumeurs comme quoi Malori serait à l'origine liée à la famille Marnett, il a trouvé en elle une alliée dans sa quête de changement de vie. À deux, ils aiment se moquer du monde de l'argenterie et des faux-semblants."]	2025-12-15 15:41:25.919	2025-12-15 15:49:00.875	\N	\N	1	\N
11	yyl92rfd5wc7pklojmgw7cv7	journal_entries	["Toujours de pairs avec son frère cadet Marn, Bram le Boucher a grandi en s'occupant de lui après la perte de leurs parents quand il était très jeune. D'abord à la rue, il a écumer les petits boulots avant de découvrir celui de boucher qu'il n'a alors jamais quitté. Bram est grand, charismatique et beaucoup de gens sentent qu'ils peuvent se reposer sur lui pour les aider, voyant en lui une figure paternelle. Bram se donne toujours à 100% pour aider au maximum la communauté.", "Multi casquette, Bram n'hésite pas à sacrifier ses heures de sommeil pour essayer de régler les problèmes d'autrui come s'il s'agissait des siens. Cependant, malgré sa nature réconfortante et généreuse, quiconque s'approche un tant soit peu trop près de son frère avec de mauvaise attention verra en un visage de Bram que peut de gens ont pu croiser dans leur vie. La figure stoïque, calme et implacable laisse alors la place à une colère froide, brutale et presque même sournoise.", "Parmi les petits boulots qu'il a fait dans sa vie, Bram a rencontré Denrick Largent à la caserne. Les deux se sont immédiatement détesté. Chacun a vue en l'autre un adversaire potentielle sur la route vers la gloire et le succès. Chacun se dépassant au fur et à mesure pour se faire remarquer par les instructeurs. Des que l'un prenait l'avantage, l'autre se dépassait mais lorsque Bram entendit les rumeurs comme quoi Denrick aurait réussi à déjouer un complot contre Monarque, il su qu'il ne pourra plus jamais le rattraper. Il quitta alors le monde militaire et se mit en quête d'un nouveau travail.", "Avec les années, Bram a développé une certaine façon d'éviter les questions trop précises sur leurs parents. Marn croit qu'il s'agit simplement de douleur mal cicatrisée, mais la vérité est plus lourde : Bram a appris un détail qu'il juge trop difficile à porter pour son cadet. Il vit avec ce secret depuis si longtemps qu'il ne sait plus s'il le protège… ou s'il l'enferme."]	2025-12-15 15:41:25.833	2025-12-15 15:49:21.266	\N	\N	1	\N
9	a4t3axkkj7fq26b6eqoxi9ct	journal_entries	["Toujours dans son bateau de pêche mais cependant jamais vraiment loin de son ainé, Marn aime la sensation de liberté que lui offre son bateau. Amateurs de plaisanterie, les gens diraient de lui qu'il est joyeux, souriant et simple de vie. Il y a cependant au fond de ses yeux une lueur faisant miroiter la douleur de ne pas avoir connus ses parents ainsi qu'une profondeur que seul ses proches ne peuvent que soupçonner.", "Philosophe dans l'âme, il aime réfléchir quand il pêche de longue heures sur l'eau. Il sera d'ailleurs toujours ravi d'emmener un compagnon avec lui pour discuter de sujet profonds à l'abri des oreilles indiscrètes. Toutes les personnes l'ayant accompagné se retrouve surprises de la capacité de Marn a sembler simple d'apparence, étant détaché de beaucoup de propriété matériel, cachant un esprit aiguisé et un avis précis sur chaque sujet qu'il aborde. Comme s'il avait déjà réfléchis longuement à chaque sujet de société.", "Amoureux de la nature, Marn fais son propre composte, il élève ses propres vers pour la pêche, trouve ses champignons dans la forêt et aime passer du temps en cuisine pour préparer des recettes mariant des saveurs des bois et des mers. Malheureusement, il a comme mauvais habitude de souvent rendre visite à Joric le Tavernier pour qu'il lui remplisse quelques verres quand il a besoin de vider son esprit de ses pensées morose.", "L'humeur de Marn semble suivre celle de la mer. Quand l'eau est calme, il se montre léger et bavard. Mais lorsque les vagues se gonflent, il devient grave. Presque trop réfléchi, comme si l'océan réveillait un poids qu'il tente habituellement de dissimuler. Ses proches disent en plaisantant qu'il est \\"à marée humaine\\", mais eux seuls savent qu'il y a un fond de vérité derrière ces mots."]	2025-12-15 15:41:25.747	2025-12-15 15:44:27.804	\N	\N	1	\N
15	a4t3axkkj7fq26b6eqoxi9ct	journal_entries	["Toujours dans son bateau de pêche mais cependant jamais vraiment loin de son ainé, Marn aime la sensation de liberté que lui offre son bateau. Amateurs de plaisanterie, les gens diraient de lui qu'il est joyeux, souriant et simple de vie. Il y a cependant au fond de ses yeux une lueur faisant miroiter la douleur de ne pas avoir connus ses parents ainsi qu'une profondeur que seul ses proches ne peuvent que soupçonner.", "Philosophe dans l'âme, il aime réfléchir quand il pêche de longue heures sur l'eau. Il sera d'ailleurs toujours ravi d'emmener un compagnon avec lui pour discuter de sujet profonds à l'abri des oreilles indiscrètes. Toutes les personnes l'ayant accompagné se retrouve surprises de la capacité de Marn a sembler simple d'apparence, étant détaché de beaucoup de propriété matériel, cachant un esprit aiguisé et un avis précis sur chaque sujet qu'il aborde. Comme s'il avait déjà réfléchis longuement à chaque sujet de société.", "Amoureux de la nature, Marn fais son propre composte, il élève ses propres vers pour la pêche, trouve ses champignons dans la forêt et aime passer du temps en cuisine pour préparer des recettes mariant des saveurs des bois et des mers. Malheureusement, il a comme mauvais habitude de souvent rendre visite à Joric le Tavernier pour qu'il lui remplisse quelques verres quand il a besoin de vider son esprit de ses pensées morose.", "L'humeur de Marn semble suivre celle de la mer. Quand l'eau est calme, il se montre léger et bavard. Mais lorsque les vagues se gonflent, il devient grave. Presque trop réfléchi, comme si l'océan réveillait un poids qu'il tente habituellement de dissimuler. Ses proches disent en plaisantant qu'il est \\"à marée humaine\\", mais eux seuls savent qu'il y a un fond de vérité derrière ces mots."]	2025-12-15 15:41:25.747	2025-12-15 15:44:27.804	2025-12-15 15:44:27.855	\N	1	\N
16	gmcgtrdqsimkxprozrh6nw4i	journal_entries	["Il a y a une vingtaine d'année, Denrick s'est fait un nom auprès des jeunes recrues au sein de l'armée royale. Connu pour avoir non seulement participé à déjouer un complot contre la couronne, selon les rumeurs il serait l'un des seuls à avoir eu la chance et l'honneur de voir Monarque de ses propres yeux.. ou plutôt de son propre œil. Car dans l'armée, honneur rime souvent avec horreur. Son fait d'arme lui ayant couté un des ses yeux, il a décidé de prendre sa retraite pour ne plus jamais avoir à manier l'épée autrement que pour se défendre. Il aurait pu se lancer dans une carrière politique mais a décider de rester proche de ce par quoi il a toujours vécu. Malgré sa main en moins, il se donne toujours à fond pour forger des armes aussi belles et puissante que ce qu'il avait pour habitude de manier. \\"Qui vivra par l'épée mourra par l'épée\\" il est donc persuadé que quelqu'un viendra un jour se venger. Et il décide de vivre chaque seconde comme si c'était la dernière de sa vie.", "D'aucun pense qu'il a trouvé sa rédemption aux côtés d'Adra, à former des plus jeunes. Il fait tout son possible pour avertir les plus jeunes sur la vie de soldat. Cependant, quand il voit dans les yeux de certains la flamme. Cette flamme qui a parfois vibrer dans ces propres yeux. La flamme de la détermination, la flamme de la volonté. Cette flamme qui montre l'envie de se dépasser pour atteindre certains sommets. Alors devant ces âmes brûlante de témérité, Denrick le Forgeron voit son feu intérieur ravivé et se donne corps et âme dans la formation des élèves.", "Lorsqu'il était jeune, Denrick était dans un fiacre avec son père et sa mère. Il fut arrêté au milieu de la forêt. Lorsque la porte s'ouvrit, il vu un homme, d'un mètre quatre-vingts, dans la vingtaine, les cheveux brun et les yeux verrons. Son regard perçait les ténèbres de la porte, son œil gauche, bleu gris, semblait vif, balayant entre chaque personne à l'intérieur. Le droit, noisette ambré, lui semblait presque vide. Comme plus lent il semblait presque suivre les mouvements de son homologue. À l'inverse de ce qu'on pourrait penser, Denrick a vu en lui une forme inspirante. Quelqu'un de libre, faisant ce qu'il voulait, faisant fî des conséquences. Il a alors grandi en idéalisant ce bandit, au plus grand détriment de son père d'ailleurs.", "Quand il eu 20 ans, Denrick eut envie d'embrasser cette vie de hors-la-loi. Il se prépara donc à cambrioler un échoppe quand soudain, alors qu'il fut sur le point de se lancer, il senti une main sur son épaule. En se retournant, il vit un vieux soldat, la mine sombre, les yeux fatigués. Denrick cru alors qu'il était fichu. \\"Qui vivra par l'épée mourra par l'épée\\". À ces mots Denrick regarda plus attentivement les yeux du soldat et reconnu ces mêmes yeux verrons qui, 10 ans auparavant, l'avaient tant marqué. Il s'effondra alors au sol, désespéré. À grande surprise, le soldat lui dit simplement de rentrer chez lui. C'est ainsi qu'il décida de rentrer chez lui et de se préparer au concours de soldat pour suivre les traces de celui qu'il a considéré, par deux fois, comme son mentor."]	2025-12-15 15:41:25.657	2025-12-15 15:44:47.781	2025-12-15 15:44:47.828	\N	1	\N
3	pl29bc8tlkfngaqzuz1r5z43	journal_entries	["Les premiers souvenirs de sa propre vie sont lui entrain de courir, à bout de souffle, sans regarder en arrière, droit vers la forêt. Les branches lui lacéraient le visage, il trébuchait sur les racines, s'écroulant de tout son saoul par terre, s'éraflant les jambes sur les pierres. Il ne se souvient plus combien de temps il a couru, il se souvient seulement s'être effondré de fatigue après s'être caché dans une grotte.", "Le lendemain matin il s'est réveillé avec des coups de langue sur le visage. En ouvrant les yeux, il a vu face à lui une louve. Mais Garen n'a pas ressenti de la peur, il a ressenti presque instantanément une connexion avec l'animal. Voyant en elle une forme de tendresse affective, presque maternelle. Il a alors grandi avec elle, chassant avec elle, se nourrissant avec elle, dormant avec elle, formant presque une meute. Il n'a jamais compris pourquoi la louve ne l'a pas attaqué, il était endormie et affaiblie. Mais il a toujours ressentie de la reconnaissance à son égard, se demandant si, sans elle, il aurait pu survire toutes ces années.", "Une fois devenue adulte, Garen eu envie de revenir à la civilisation humaine. Il a donc décidé d'exploiter la compétences qu'il a passé tant d'année à aiguiser en devenant chasseur En dehors de sa vie professionnel, Garen s'est rendu compte d'un profond attachement pour les animaux, en particulier les lapins. Lors de son arrivé à la civilisation, Garen ne savait pas comment tisser des liens avec autrui, alors qu'il commençait à hésiter à retourner à la forêt, il reçu de la part de cadeau de la part de Mira la Tisseuse un lapin nommé Roger ce qui le convaincue de rester une bonne fois pour tout.", "Cependant Garen cache un lourd secret. Un secret que même Mira la tisseuse ne connait pas. Garen a découvert que les normes de la société était parfois trop pesantes pour lui à un point tel qu'il retournait presque à l'était sauvage. Garen a par la suite découvert la solution face à cette remonté de ses instincts. Une fois la nuit tombé, il participe à des combats clandestins, afin de se défouler. Animaux, humains, tout y passe. Garen est connu pour se battre comme un loup, avec ardeur et bestialité. Garen a trouvé une forme de stabilité dans son quotidien. Chasseur le jour et combattant la nuit, c'est ainsi qu'il estime sa place dans la communauté."]	2025-12-15 15:41:25.443	2025-12-15 15:45:48.217	\N	\N	1	\N
17	pl29bc8tlkfngaqzuz1r5z43	journal_entries	["Les premiers souvenirs de sa propre vie sont lui entrain de courir, à bout de souffle, sans regarder en arrière, droit vers la forêt. Les branches lui lacéraient le visage, il trébuchait sur les racines, s'écroulant de tout son saoul par terre, s'éraflant les jambes sur les pierres. Il ne se souvient plus combien de temps il a couru, il se souvient seulement s'être effondré de fatigue après s'être caché dans une grotte.", "Le lendemain matin il s'est réveillé avec des coups de langue sur le visage. En ouvrant les yeux, il a vu face à lui une louve. Mais Garen n'a pas ressenti de la peur, il a ressenti presque instantanément une connexion avec l'animal. Voyant en elle une forme de tendresse affective, presque maternelle. Il a alors grandi avec elle, chassant avec elle, se nourrissant avec elle, dormant avec elle, formant presque une meute. Il n'a jamais compris pourquoi la louve ne l'a pas attaqué, il était endormie et affaiblie. Mais il a toujours ressentie de la reconnaissance à son égard, se demandant si, sans elle, il aurait pu survire toutes ces années.", "Une fois devenue adulte, Garen eu envie de revenir à la civilisation humaine. Il a donc décidé d'exploiter la compétences qu'il a passé tant d'année à aiguiser en devenant chasseur En dehors de sa vie professionnel, Garen s'est rendu compte d'un profond attachement pour les animaux, en particulier les lapins. Lors de son arrivé à la civilisation, Garen ne savait pas comment tisser des liens avec autrui, alors qu'il commençait à hésiter à retourner à la forêt, il reçu de la part de cadeau de la part de Mira la Tisseuse un lapin nommé Roger ce qui le convaincue de rester une bonne fois pour tout.", "Cependant Garen cache un lourd secret. Un secret que même Mira la tisseuse ne connait pas. Garen a découvert que les normes de la société était parfois trop pesantes pour lui à un point tel qu'il retournait presque à l'était sauvage. Garen a par la suite découvert la solution face à cette remonté de ses instincts. Une fois la nuit tombé, il participe à des combats clandestins, afin de se défouler. Animaux, humains, tout y passe. Garen est connu pour se battre comme un loup, avec ardeur et bestialité. Garen a trouvé une forme de stabilité dans son quotidien. Chasseur le jour et combattant la nuit, c'est ainsi qu'il estime sa place dans la communauté."]	2025-12-15 15:41:25.443	2025-12-15 15:45:48.217	2025-12-15 15:45:48.261	\N	1	\N
18	tlcuupvpmtqn4rsjygpzz1gn	journal_entries	["Espiègle et qui aime le sarcasme Toben le Meunier a pour habitude de toujours tourner en dérision les personnes qui lui demande un service. Encore en conflit avec Garen le Chasseur et Joric le Tavernier car trop directe et manquant souvent de tact, il n'hésite pas à dire tout haut ce qu'il pense d'eux. Beaucoup pourrait donc le trouver bourru et antipathique. Mais certains savent qu'en réalité Toben teste les gens. Il observe leurs réactions, jauge leurs limites. Et si quelqu'un lui répond du tac au tac, voir même rigole aux pics de Toben, alors celui-ci devient presque plus doux. Comme ci, au travers de ses joutes verbal, Toben cherchait plus quelqu'un avec qui dialoguer et qui pourrait le comprendre.", "Cependant, il a pour habitude de toujours faire plus de pain que nécessaire et de donner le surplus aux plus démunies. Toujours en râlant bien sûr, presque même en insultant les personnes qu'il aide. Comme si la générosité le mettait mal à l'aise. Comme s'il avait peur que la communauté puisse voir une forme de faiblesse derrière la main qu'il tend. Mais malgré tout, Toben reviendra encore le lendemain aider ceux qui en ont besoin. Personne ne l'a jamais vu refuser un ventre vide. Comme s'il savait exactement ce que ça faisait que d'avoir faim.", "N'ayant jamais connu son père et après avoir perdu sa mère, il a apprit tôt à manipuler et trahir les gens qui lui tendaient la main, convaincu que la générosité n'existait pas et que personne ne lui donnerait rien sans attendre une contrepartie en retour. Toben a connu la famine, le froid et la maladie. Il a connu la violence, la peur et la honte de voler du pain pour survivre. Ce passé l'a rendu méfiant et parfois en désaccord avec l'ordre établi, mais il l'a rendu aussi d'une incroyable résilience.", "Depuis plusieurs années les incursions des monstres se font rare. Mais Toben n'a jamais oublié la nuit où ils ont assassiné sa famille en même temps que sa naïveté d'enfant. Alors qu'il voyait les gens fuir autour de lui, il ne cessait de se répéter que les gardes allaient bientôt arriver pour les protéger. Après tout ils avaient juré de tous les protéger. Mais il a alors senti quelqu'un le tirer violemment en arrière. Sa propre mère l'a alors plaqué au sol, le recouvrant. \\"Ne fait plus de bruit. Retiens ton souffle. Ne dis plus rien.\\". Les paroles de sa mère ont résonné en boucle dans sa tête. Il se les répétait alors qu'il sentait la chaleur quitter petit à petit le corps de sa propre mère. Et c'est là, caché, qu'il a observé les monstres de près pour la première fois. Leurs mouvements, leurs bruits, leurs rythmes même. Il les as observés pendant des heures et des heures, jusqu'à ce que les gardes arrivent. Ce que personne n'a envie de voir, lui l'a vécu, contre son gré, ce jour là. Depuis ce jour Toben connait les monstres mieux que beaucoup de gardes entraînés."]	2025-12-15 15:41:25.559	2025-12-15 15:46:51.845	2025-12-15 15:46:51.899	\N	1	\N
19	u54f61gakix2nh6uazbib0k7	journal_entries	["Malori, aussi nommé Lori par ses connaissances, est une postière autant maladroite que dévoué dans son travail. Elle parcours les terres de Culturia livrant lettres et colis parfois plus ou moins douteux. \\"Cela fait parti du boulot n'est-ce pas ?\\", ce répète t-elle sans cesses. Elle est bien consciente que son patron l'utilise un peu trop, mais faire de son mieux est son leitmotiv. Sa plus grande gaffe : Renverser malheureusement une potion de croissance accéléré sur des ronces, cela à coupé la route pendant plusieurs jours. Personne ne le sait, enfin c'est-ce qu'elle croit.", "La famille Marnett vous dis quelque choses, maitre de guilde. Cette famille est connu dans la cour en tant qu'exécutant ou conseillés de Monarque. D'après des rumeurs, le nom de Malori viendrais de sa mère, Vlori Marnett une discrète conseillère au trône. Issue d'une union secrète entre sa mère et un soldat, Malori est exilé très tôt des rempares, depuis elle à toujours vécu avec sa tante jusqu'à sa très ressente émancipation. L'idée de retourner à la soie lui déplait, jugeant être plus utile au peuple qu'à la royauté.", "Il y a quelques semaines, vous voyez Malori régulièrement aller à la taverne. Au delà d'étancher sa fatigue à coup de peinte, elle bois souvent à une table seule penné par la solitude de vivre seule. Malgré les contacts régulier avec ses clients, se confesser est très dur. Pour se vider la tête et passer du bon temps, elle se rend régulièrement chez l'ancien, Haldo, où ils discutent hypothèses et réflexion plus ou moins pertinente. De son jeune âge Malori à tant à apprendre, elle en ait persuadé.", "Malgré l'énergie débordante et la maladresse caractéristique de Malori qui fait son charme, plusieurs personnes sont méfiantes à propos d'elle. À force de vouloir prouver sa valeur, elle en perd souvent le sens des priorités et ne prend pas assez de temps pour elle. \\"C'est en faisant trop qu'elle va se perdre\\" a-t-elle entendu il y a longtemps à propos d'elle. Depuis, la maladresse est devenu une de ses caractéristiques. Son plus gros défaut est qu'elle ne se laisse pas le temps de grandir et veux déjà adosser des responsabilités qu'elle ne peux pas tenir. Peut-être en lien avec sa mère. Qui sait ?"]	2025-12-15 15:41:25.34	2025-12-15 15:47:12.207	2025-12-15 15:47:12.247	\N	1	\N
20	umglbpbnjhjqlnw85y7bq36a	journal_entries	["Toren, depuis son enfance, se tient le dos droit. Regardant droit devant lui, ne répondant que quand c'est nécessaire, que quand c'est justifié. Habitué aux cérémonies depuis son enfance où il se tenait aux côtés de son père, il n'était là que comme symbole de la réussite familiale. \\"Qu'il est poli !\\", \\"Comme il est sage !\\". Autant de compliment qu'il s'avait n'était pas dirigé à lui mais plus à son paternel, Orren Brauvin.", "Lors de son adolescence, Toren a voyagé à travers tous le pays pour sa formation. Son père avait de grand projet pour lui et il le savait. Etudier jusqu'à l'aube, dormir quelques heures à peine, visiter les plus grands chantier du pays des le matin, assister à des représentations l'après-midi, manger à la table des plus grand le soir et se remettre à ses livres juste après. Ce fut son quotidien pendant de nombreuses années. Aujourd'hui quand Toren regarde en arrière, il se souvient de ses années comme celles où il s'est perdu lui même. Face à la pression, face à la peur des responsabilités, Toren aujourd'hui est toujours la cible de nombreuses angoisses et cauchemars le réveillant à toutes les heures de la nuit.", "Relativement fortuné et notamment grâce à l'héritage de ses parents eux aussi architectes, Toren a développé très tôt une passion pour le dessin et un attrait pour l'argent. En voulant rendre son géniteur fier de lui, il a essayé d'augmenter les bénéfices des chantiers en réduisant les salaires et en baissant la qualité des matériaux de construction. Malheureusement, c'est quand il fut missionné de l'un des plus grand chantiers du pays que le scandale a été révélé par Tessa la Mercenaire. Il ne faisait pas que couper son ciment à l'eau, il ne respectait même aucune des normes de sécurité instauré dans le pays par le gouvernement de Monarque. Toren n'a jamais vu autant de déception dans le regard de son père, mais quel ne fut pas sa surprise quand il découvrit dans les journaux que son père s'était livré de son propre chef aux gardes. Se dénonçant à la place de son fils. Depuis Toren porte une haine envers la mercenaire et lui même.", "Aujourd'hui, Toren s'efforce de redorer son image en redoublant de perspicacité dans ces travaux. Il a décidé de grandir et d'évoluer, il s'est rendu compte qu'il ne voulait plus de cette vie. Après avoir entendu des rumeurs comme quoi Malori serait à l'origine liée à la famille Marnett, il a trouvé en elle une alliée dans sa quête de changement de vie. À deux, ils aiment se moquer du monde de l'argenterie et des faux-semblants."]	2025-12-15 15:41:25.919	2025-12-15 15:49:00.875	2025-12-15 15:49:00.915	\N	1	\N
21	yyl92rfd5wc7pklojmgw7cv7	journal_entries	["Toujours de pairs avec son frère cadet Marn, Bram le Boucher a grandi en s'occupant de lui après la perte de leurs parents quand il était très jeune. D'abord à la rue, il a écumer les petits boulots avant de découvrir celui de boucher qu'il n'a alors jamais quitté. Bram est grand, charismatique et beaucoup de gens sentent qu'ils peuvent se reposer sur lui pour les aider, voyant en lui une figure paternelle. Bram se donne toujours à 100% pour aider au maximum la communauté.", "Multi casquette, Bram n'hésite pas à sacrifier ses heures de sommeil pour essayer de régler les problèmes d'autrui come s'il s'agissait des siens. Cependant, malgré sa nature réconfortante et généreuse, quiconque s'approche un tant soit peu trop près de son frère avec de mauvaise attention verra en un visage de Bram que peut de gens ont pu croiser dans leur vie. La figure stoïque, calme et implacable laisse alors la place à une colère froide, brutale et presque même sournoise.", "Parmi les petits boulots qu'il a fait dans sa vie, Bram a rencontré Denrick Largent à la caserne. Les deux se sont immédiatement détesté. Chacun a vue en l'autre un adversaire potentielle sur la route vers la gloire et le succès. Chacun se dépassant au fur et à mesure pour se faire remarquer par les instructeurs. Des que l'un prenait l'avantage, l'autre se dépassait mais lorsque Bram entendit les rumeurs comme quoi Denrick aurait réussi à déjouer un complot contre Monarque, il su qu'il ne pourra plus jamais le rattraper. Il quitta alors le monde militaire et se mit en quête d'un nouveau travail.", "Avec les années, Bram a développé une certaine façon d'éviter les questions trop précises sur leurs parents. Marn croit qu'il s'agit simplement de douleur mal cicatrisée, mais la vérité est plus lourde : Bram a appris un détail qu'il juge trop difficile à porter pour son cadet. Il vit avec ce secret depuis si longtemps qu'il ne sait plus s'il le protège… ou s'il l'enferme."]	2025-12-15 15:41:25.833	2025-12-15 15:49:21.266	2025-12-15 15:49:21.31	\N	1	\N
\.


--
-- Data for Name: dialogs_npc_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.dialogs_npc_lnk (id, dialog_id, npc_id, dialog_ord) FROM stdin;
15	9	9	1
17	7	7	1
19	3	3	1
21	5	5	1
23	1	1	1
25	13	13	1
27	11	11	1
29	20	15	1
30	21	16	1
31	18	17	1
32	15	18	1
34	16	20	1
36	17	22	1
38	19	24	1
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.files (id, document_id, name, alternative_text, caption, width, height, formats, hash, ext, mime, size, url, preview_url, provider, provider_metadata, folder_path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
6	sp2a0kp8uvgzm522dz1xcpuq	nature-icon.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_nature_icon_fdba7199c9.png", "hash": "thumbnail_nature_icon_fdba7199c9", "mime": "image/png", "name": "thumbnail_nature-icon.png", "path": null, "size": 20.58, "width": 156, "height": 156, "sizeInBytes": 20575}}	nature_icon_fdba7199c9	.png	image/png	30.45	/uploads/nature_icon_fdba7199c9.png	\N	local	\N	/4	2025-12-18 13:38:22.477	2025-12-18 13:38:22.477	2025-12-18 13:38:22.478	1	1	\N
7	oxvgpjo98xwshw65ctfssqmp	make-icon.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_make_icon_ab5d4388a0.png", "hash": "thumbnail_make_icon_ab5d4388a0", "mime": "image/png", "name": "thumbnail_make-icon.png", "path": null, "size": 26.93, "width": 156, "height": 156, "sizeInBytes": 26934}}	make_icon_ab5d4388a0	.png	image/png	34.18	/uploads/make_icon_ab5d4388a0.png	\N	local	\N	/4	2025-12-18 13:38:22.481	2025-12-18 13:38:22.481	2025-12-18 13:38:22.481	1	1	\N
8	pp7ot05z5xtz7t7tvrzmg4ao	science-icon.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_science_icon_de9b4b6ca9.png", "hash": "thumbnail_science_icon_de9b4b6ca9", "mime": "image/png", "name": "thumbnail_science-icon.png", "path": null, "size": 12.11, "width": 156, "height": 156, "sizeInBytes": 12109}}	science_icon_de9b4b6ca9	.png	image/png	20.97	/uploads/science_icon_de9b4b6ca9.png	\N	local	\N	/4	2025-12-18 13:38:22.502	2025-12-18 13:38:22.502	2025-12-18 13:38:22.502	1	1	\N
9	bxk1708cbjzo94z1hlqnv913	art-icon.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_art_icon_560faffe7a.png", "hash": "thumbnail_art_icon_560faffe7a", "mime": "image/png", "name": "thumbnail_art-icon.png", "path": null, "size": 22.56, "width": 156, "height": 156, "sizeInBytes": 22555}}	art_icon_560faffe7a	.png	image/png	40.91	/uploads/art_icon_560faffe7a.png	\N	local	\N	/4	2025-12-18 13:38:22.514	2025-12-18 13:38:22.514	2025-12-18 13:38:22.514	1	1	\N
10	vpoybgzz4th6p7kabyo8f2gl	society-icon.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_society_icon_d71590f78a.png", "hash": "thumbnail_society_icon_d71590f78a", "mime": "image/png", "name": "thumbnail_society-icon.png", "path": null, "size": 11.11, "width": 156, "height": 156, "sizeInBytes": 11111}}	society_icon_d71590f78a	.png	image/png	13.89	/uploads/society_icon_d71590f78a.png	\N	local	\N	/4	2025-12-18 13:38:22.518	2025-12-18 13:38:22.518	2025-12-18 13:38:22.518	1	1	\N
11	op1d6pn67x8ibzdk95inc2so	history-icon.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_history_icon_e38a28ad18.png", "hash": "thumbnail_history_icon_e38a28ad18", "mime": "image/png", "name": "thumbnail_history-icon.png", "path": null, "size": 31.26, "width": 156, "height": 156, "sizeInBytes": 31260}}	history_icon_e38a28ad18	.png	image/png	51.35	/uploads/history_icon_e38a28ad18.png	\N	local	\N	/4	2025-12-18 13:38:22.593	2025-12-18 13:38:22.593	2025-12-18 13:38:22.593	1	1	\N
12	k1iv9jwpd3tl799cb359ad72	helmet3.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_helmet3_dbaa46198e.png", "hash": "thumbnail_helmet3_dbaa46198e", "mime": "image/png", "name": "thumbnail_helmet3.png", "path": null, "size": 24.09, "width": 156, "height": 156, "sizeInBytes": 24087}}	helmet3_dbaa46198e	.png	image/png	28.73	/uploads/helmet3_dbaa46198e.png	\N	local	\N	/3	2025-12-18 13:38:44.691	2025-12-18 13:38:44.691	2025-12-18 13:38:44.691	1	1	\N
13	p7lncxvzhmz1s4t8j20m8l2r	helmet2.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_helmet2_adee291d7a.png", "hash": "thumbnail_helmet2_adee291d7a", "mime": "image/png", "name": "thumbnail_helmet2.png", "path": null, "size": 21.02, "width": 156, "height": 156, "sizeInBytes": 21019}}	helmet2_adee291d7a	.png	image/png	31.37	/uploads/helmet2_adee291d7a.png	\N	local	\N	/3	2025-12-18 13:38:44.73	2025-12-18 13:38:44.73	2025-12-18 13:38:44.73	1	1	\N
14	hpcso135lff7nxw6cas8lcks	helmet1.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_helmet1_0ac479cc6f.png", "hash": "thumbnail_helmet1_0ac479cc6f", "mime": "image/png", "name": "thumbnail_helmet1.png", "path": null, "size": 22.79, "width": 156, "height": 156, "sizeInBytes": 22790}}	helmet1_0ac479cc6f	.png	image/png	33.74	/uploads/helmet1_0ac479cc6f.png	\N	local	\N	/3	2025-12-18 13:38:44.744	2025-12-18 13:38:44.744	2025-12-18 13:38:44.745	1	1	\N
16	tkggn2a5gg0m8iqeo725nktf	charm3.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_charm3_233d4dd76e.png", "hash": "thumbnail_charm3_233d4dd76e", "mime": "image/png", "name": "thumbnail_charm3.png", "path": null, "size": 30.26, "width": 156, "height": 156, "sizeInBytes": 30257}}	charm3_233d4dd76e	.png	image/png	56.59	/uploads/charm3_233d4dd76e.png	\N	local	\N	/2	2025-12-18 13:39:03.726	2025-12-18 13:39:03.726	2025-12-18 13:39:03.726	1	1	\N
2	hrt24vb485qbcwcniozt52jg	char1.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_char1_1963d5b91c.png", "hash": "thumbnail_char1_1963d5b91c", "mime": "image/png", "name": "thumbnail_char1.png", "path": null, "size": 21.57, "width": 156, "height": 156, "sizeInBytes": 21572}}	char1_1963d5b91c	.png	image/png	46.72	/uploads/char1_1963d5b91c.png	\N	local	\N	/5	2025-12-18 13:18:32.924	2025-12-18 13:41:24.75	2025-12-18 13:18:32.925	1	1	\N
3	hw3ei055ty41cmhqcbxvutsz	char4.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_char4_b1abba9c5d.png", "hash": "thumbnail_char4_b1abba9c5d", "mime": "image/png", "name": "thumbnail_char4.png", "path": null, "size": 19.13, "width": 156, "height": 156, "sizeInBytes": 19125}}	char4_b1abba9c5d	.png	image/png	41.51	/uploads/char4_b1abba9c5d.png	\N	local	\N	/5	2025-12-18 13:18:32.94	2025-12-18 13:41:38.305	2025-12-18 13:18:32.94	1	1	\N
4	t82p5guczxqncd2icyrh1axi	char2.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_char2_376432e3c2.png", "hash": "thumbnail_char2_376432e3c2", "mime": "image/png", "name": "thumbnail_char2.png", "path": null, "size": 20.61, "width": 156, "height": 156, "sizeInBytes": 20607}}	char2_376432e3c2	.png	image/png	44.98	/uploads/char2_376432e3c2.png	\N	local	\N	/5	2025-12-18 13:18:32.956	2025-12-18 13:41:49.795	2025-12-18 13:18:32.956	1	1	\N
5	v3sdjusrn3j2pj253l4idzmz	char3.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_char3_0e8e106145.png", "hash": "thumbnail_char3_0e8e106145", "mime": "image/png", "name": "thumbnail_char3.png", "path": null, "size": 21.71, "width": 156, "height": 156, "sizeInBytes": 21707}}	char3_0e8e106145	.png	image/png	42.12	/uploads/char3_0e8e106145.png	\N	local	\N	/5	2025-12-18 13:18:32.963	2025-12-18 13:41:51.928	2025-12-18 13:18:32.963	1	1	\N
17	larhrhjtc1ilgg5wq5wu623l	charm2.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_charm2_a35c516a3e.png", "hash": "thumbnail_charm2_a35c516a3e", "mime": "image/png", "name": "thumbnail_charm2.png", "path": null, "size": 22.73, "width": 156, "height": 156, "sizeInBytes": 22727}}	charm2_a35c516a3e	.png	image/png	39.84	/uploads/charm2_a35c516a3e.png	\N	local	\N	/2	2025-12-18 13:39:03.735	2025-12-18 13:39:03.735	2025-12-18 13:39:03.735	1	1	\N
18	ejdbg9uxi57e8aa3khkodwok	weapon2.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_weapon2_418beeac60.png", "hash": "thumbnail_weapon2_418beeac60", "mime": "image/png", "name": "thumbnail_weapon2.png", "path": null, "size": 14.82, "width": 156, "height": 156, "sizeInBytes": 14824}}	weapon2_418beeac60	.png	image/png	18.50	/uploads/weapon2_418beeac60.png	\N	local	\N	/1	2025-12-18 13:39:15.534	2025-12-18 13:39:15.534	2025-12-18 13:39:15.535	1	1	\N
15	enc1fx8ahvhc2niln139vqon	charm1.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_charm1_4a910d0e82.png", "hash": "thumbnail_charm1_4a910d0e82", "mime": "image/png", "name": "thumbnail_charm1.png", "path": null, "size": 17.57, "width": 156, "height": 156, "sizeInBytes": 17566}}	charm1_4a910d0e82	.png	image/png	28.71	/uploads/charm1_4a910d0e82.png	\N	local	\N	/2	2025-12-18 13:39:03.662	2025-12-18 13:39:55.646	2025-12-18 13:39:03.663	1	1	\N
20	sexwere6a3fo1vuz3qklio27	weapon1.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_weapon1_26f7090df6.png", "hash": "thumbnail_weapon1_26f7090df6", "mime": "image/png", "name": "thumbnail_weapon1.png", "path": null, "size": 9.78, "width": 156, "height": 156, "sizeInBytes": 9783}}	weapon1_26f7090df6	.png	image/png	18.08	/uploads/weapon1_26f7090df6.png	\N	local	\N	/1	2025-12-18 13:39:15.566	2025-12-18 14:06:09.792	2025-12-18 13:39:15.566	1	1	\N
19	tgi12ta6q048c8k1fd5e4igj	weapon3.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_weapon3_32f4a50f36.png", "hash": "thumbnail_weapon3_32f4a50f36", "mime": "image/png", "name": "thumbnail_weapon3.png", "path": null, "size": 13.79, "width": 156, "height": 156, "sizeInBytes": 13787}}	weapon3_32f4a50f36	.png	image/png	19.39	/uploads/weapon3_32f4a50f36.png	\N	local	\N	/1	2025-12-18 13:39:15.536	2025-12-28 16:10:51.337	2025-12-18 13:39:15.536	1	1	\N
21	vibxa1s8krqtlgletaqig0et	basic_helmet.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_basic_helmet_6d6f9c0200.png", "hash": "thumbnail_basic_helmet_6d6f9c0200", "mime": "image/png", "name": "thumbnail_basic_helmet.png", "path": null, "size": 22.03, "width": 156, "height": 156, "sizeInBytes": 22032}}	basic_helmet_6d6f9c0200	.png	image/png	26.08	/uploads/basic_helmet_6d6f9c0200.png	\N	local	\N	/3	2025-12-28 16:17:54.371	2025-12-28 16:17:54.371	2025-12-28 16:17:54.371	1	1	\N
22	ulmi170ngx9qn0eq7borfcwg	basic_charm.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_basic_charm_b87c798500.png", "hash": "thumbnail_basic_charm_b87c798500", "mime": "image/png", "name": "thumbnail_basic_charm.png", "path": null, "size": 16.97, "width": 156, "height": 156, "sizeInBytes": 16965}}	basic_charm_b87c798500	.png	image/png	22.59	/uploads/basic_charm_b87c798500.png	\N	local	\N	/2	2025-12-28 16:18:17.845	2025-12-28 16:18:17.845	2025-12-28 16:18:17.845	1	1	\N
23	s3wm6buhlcehog9r60sjwmjr	basic_sword.png	\N	\N	500	500	{"thumbnail": {"ext": ".png", "url": "/uploads/thumbnail_basic_sword_5b4f8b30ab.png", "hash": "thumbnail_basic_sword_5b4f8b30ab", "mime": "image/png", "name": "thumbnail_basic_sword.png", "path": null, "size": 13.52, "width": 156, "height": 156, "sizeInBytes": 13516}}	basic_sword_5b4f8b30ab	.png	image/png	15.36	/uploads/basic_sword_5b4f8b30ab.png	\N	local	\N	/1	2025-12-28 16:18:37.996	2025-12-28 16:18:37.996	2025-12-28 16:18:37.997	1	1	\N
\.


--
-- Data for Name: files_folder_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.files_folder_lnk (id, file_id, folder_id, file_ord) FROM stdin;
2	2	5	1
3	3	5	1
4	4	5	2
5	5	5	2
6	6	4	1
7	7	4	1
8	8	4	2
9	9	4	2
10	10	4	3
11	11	4	4
12	12	3	1
13	13	3	2
14	14	3	3
15	15	2	1
16	16	2	2
17	17	2	2
18	18	1	1
19	19	1	1
20	20	1	2
32	21	3	4
33	22	2	3
34	23	1	3
\.


--
-- Data for Name: files_related_mph; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.files_related_mph (id, file_id, related_id, related_type, field, "order") FROM stdin;
3	15	5	api::item.item	icon	1
4	15	8	api::item.item	icon	1
6	14	9	api::item.item	icon	1
7	19	1	api::item.item	icon	1
8	19	10	api::item.item	icon	1
9	2	3	api::character.character	icon	1
10	2	6	api::character.character	icon	1
12	5	7	api::character.character	icon	1
13	14	3	api::item.item	icon	1
14	14	11	api::item.item	icon	1
16	20	13	api::item.item	icon	1
18	20	14	api::item.item	icon	1
20	20	15	api::item.item	icon	1
22	20	16	api::item.item	icon	1
24	20	17	api::item.item	icon	1
25	20	12	api::item.item	icon	1
26	20	18	api::item.item	icon	1
28	5	8	api::character.character	icon	1
30	2	9	api::character.character	icon	1
32	5	10	api::character.character	icon	1
33	4	1	api::character.character	icon	1
34	4	11	api::character.character	icon	1
35	3	12	api::character.character	icon	1
36	2	13	api::character.character	icon	1
40	15	21	api::item.item	icon	1
41	15	22	api::item.item	icon	1
42	14	20	api::item.item	icon	1
43	14	23	api::item.item	icon	1
45	20	24	api::item.item	icon	1
47	19	25	api::item.item	icon	1
48	19	19	api::item.item	icon	1
49	19	26	api::item.item	icon	1
50	2	14	api::character.character	icon	1
54	22	29	api::item.item	icon	1
55	22	30	api::item.item	icon	1
56	21	28	api::item.item	icon	1
57	21	31	api::item.item	icon	1
58	23	27	api::item.item	icon	1
59	23	32	api::item.item	icon	1
60	2	15	api::character.character	icon	1
61	23	33	api::item.item	icon	1
62	21	34	api::item.item	icon	1
63	22	35	api::item.item	icon	1
\.


--
-- Data for Name: friendships; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.friendships (id, document_id, quests_entry_unlocked, expedition_entry_unlocked, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: friendships_guild_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.friendships_guild_lnk (id, friendship_id, guild_id, friendship_ord) FROM stdin;
\.


--
-- Data for Name: friendships_npc_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.friendships_npc_lnk (id, friendship_id, npc_id, friendship_ord) FROM stdin;
\.


--
-- Data for Name: guilds; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.guilds (id, document_id, name, gold, exp, scrap, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
10	hu8oen0ufv43w6qqtb2vdili	Les chevaliers du ciels	0	0	0	2025-12-29 01:30:11.971	2025-12-29 01:30:11.971	\N	\N	\N	\N
\.


--
-- Data for Name: guilds_user_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.guilds_user_lnk (id, guild_id, user_id) FROM stdin;
7	10	9
\.


--
-- Data for Name: i18n_locale; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.i18n_locale (id, document_id, name, code, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	ggi7vnu04b2l1eckv62qkosv	English (en)	en	2025-12-15 15:33:23.721	2025-12-15 15:33:23.721	2025-12-15 15:33:23.727	\N	\N	\N
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.items (id, document_id, name, level, index_damage, slot, is_scrapped, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
33	kzid1lyb892vpi0bsua9l64j	Épée classique	1	10	weapon	f	2025-12-29 01:30:12.001	2025-12-29 01:30:12.001	\N	\N	\N	\N
34	muoz8lo6w7d139wm0bz6wdm0	Casque classique	1	10	helmet	f	2025-12-29 01:30:12.015	2025-12-29 01:30:12.015	\N	\N	\N	\N
35	yea6w3leing9sz5u7xq4n7vu	Bague classique	1	10	charm	f	2025-12-29 01:30:12.027	2025-12-29 01:30:12.027	\N	\N	\N	\N
\.


--
-- Data for Name: items_character_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.items_character_lnk (id, item_id, character_id, item_ord) FROM stdin;
24	33	15	1
25	34	15	2
26	35	15	3
\.


--
-- Data for Name: items_guild_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.items_guild_lnk (id, item_id, guild_id, item_ord) FROM stdin;
31	33	10	1
32	34	10	2
33	35	10	3
\.


--
-- Data for Name: items_rarity_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.items_rarity_lnk (id, item_id, rarity_id, item_ord) FROM stdin;
\.


--
-- Data for Name: items_runs_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.items_runs_lnk (id, item_id, run_id, run_ord, item_ord) FROM stdin;
\.


--
-- Data for Name: items_tags_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.items_tags_lnk (id, item_id, tag_id, tag_ord, item_ord) FROM stdin;
\.


--
-- Data for Name: items_visits_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.items_visits_lnk (id, item_id, visit_id, visit_ord, item_ord) FROM stdin;
\.


--
-- Data for Name: museums; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.museums (id, document_id, name, lat, lng, geohash, location, radius, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
3	rlutni64i1vz8zdz24qn38fv	Pole Horse De Saint-Lô	49.11721840000001	-1.0770386	gbxprmx8x	{"lat": 49.11721840000001, "lng": -1.0770386}	800	2025-12-15 15:41:12.562	2025-12-16 07:56:59.269	\N	\N	1	\N
12	rlutni64i1vz8zdz24qn38fv	Pole Horse De Saint-Lô	49.11721840000001	-1.0770386	gbxprmx8x	{"lat": 49.11721840000001, "lng": -1.0770386}	800	2025-12-15 15:41:12.562	2025-12-16 07:56:59.269	2025-12-16 07:56:59.288	\N	1	\N
5	qxokyuhw0uvft4h3sm15r26v	Departmental Archives De La Manche	49.11579510000001	-1.0809746	gbxprmkb5	{"lat": 49.11579510000001, "lng": -1.0809746}	400	2025-12-15 15:41:12.678	2025-12-16 08:12:08.316	\N	\N	1	\N
14	qxokyuhw0uvft4h3sm15r26v	Departmental Archives De La Manche	49.11579510000001	-1.0809746	gbxprmkb5	{"lat": 49.11579510000001, "lng": -1.0809746}	400	2025-12-15 15:41:12.678	2025-12-16 08:12:08.316	2025-12-16 08:12:08.329	\N	1	\N
9	z5rqmjt1102bea7llyics2rh	Museum of Fine Arts	49.11700619999999	-1.0878218	gbxprjrz7	{"lat": 49.11700619999999, "lng": -1.0878218}	400	2025-12-15 15:41:12.882	2025-12-16 08:12:15.528	\N	\N	1	\N
16	z5rqmjt1102bea7llyics2rh	Museum of Fine Arts	49.11700619999999	-1.0878218	gbxprjrz7	{"lat": 49.11700619999999, "lng": -1.0878218}	400	2025-12-15 15:41:12.882	2025-12-16 08:12:15.528	2025-12-16 08:12:15.544	\N	1	\N
7	af2688a57qn1xfv36xebmnrp	Musée du Bocage Normand	49.10450869999999	-1.0766467	gbxpre0n2	{"lat": 49.10450869999999, "lng": -1.0766467}	400	2025-12-15 15:41:12.786	2025-12-16 08:12:21.29	\N	\N	1	\N
17	af2688a57qn1xfv36xebmnrp	Musée du Bocage Normand	49.10450869999999	-1.0766467	gbxpre0n2	{"lat": 49.10450869999999, "lng": -1.0766467}	400	2025-12-15 15:41:12.786	2025-12-16 08:12:21.29	2025-12-16 08:12:21.304	\N	1	\N
1	b00y25f9nk4g0h1gd3t5pyf7	Pheede	49.1175662	-1.0918043	gbxprjsfx	{"lat": 49.1175662, "lng": -1.0918043}	180	2025-12-15 15:41:12.345	2025-12-16 08:12:29.738	\N	\N	1	\N
18	b00y25f9nk4g0h1gd3t5pyf7	Pheede	49.1175662	-1.0918043	gbxprjsfx	{"lat": 49.1175662, "lng": -1.0918043}	180	2025-12-15 15:41:12.345	2025-12-16 08:12:29.738	2025-12-16 08:12:29.752	\N	1	\N
\.


--
-- Data for Name: museums_tags_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.museums_tags_lnk (id, museum_id, tag_id, tag_ord, museum_ord) FROM stdin;
21	5	1	3	1
22	5	9	4	1
13	9	4	1	3
23	9	3	3	1
24	9	1	4	2
25	7	1	2	3
1	1	4	1	1
26	1	3	2	2
27	3	1	3	4
28	3	13	4	1
37	16	4	1	4
40	18	4	1	2
44	12	21	1	4
41	14	21	1	1
42	16	21	2	2
43	17	21	1	3
46	12	23	2	1
47	14	25	2	1
\.


--
-- Data for Name: npcs; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.npcs (id, document_id, firstname, lastname, pronouns, quests_entry_available, expedition_entry_available, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
13	r4vkzupc71dkooppij5hnlpw	Toren	Brauvin	he	2	2	2025-12-15 15:33:29.424	2025-12-16 08:11:01.988	\N	\N	1	\N
15	r4vkzupc71dkooppij5hnlpw	Toren	Brauvin	he	2	2	2025-12-15 15:33:29.424	2025-12-16 08:11:01.988	2025-12-16 08:11:02.009	\N	1	\N
11	imvk45a3cdov9jdnihmgnzmd	Bram	Thobas	he	2	2	2025-12-15 15:33:29.363	2025-12-16 08:11:18.608	\N	\N	1	\N
16	imvk45a3cdov9jdnihmgnzmd	Bram	Thobas	he	2	2	2025-12-15 15:33:29.363	2025-12-16 08:11:18.608	2025-12-16 08:11:18.632	\N	1	\N
5	xx7xggk5232fqg9vlxd6npdb	Toben	Montivert	he	2	2	2025-12-15 15:33:29.175	2025-12-16 08:11:31.681	\N	\N	1	\N
17	xx7xggk5232fqg9vlxd6npdb	Toben	Montivert	he	2	2	2025-12-15 15:33:29.175	2025-12-16 08:11:31.681	2025-12-16 08:11:31.699	\N	1	\N
9	b75qhpmdw4yvu791uuso66jf	Marn	Thobas	he	2	2	2025-12-15 15:33:29.298	2025-12-16 08:11:37.382	\N	\N	1	\N
18	b75qhpmdw4yvu791uuso66jf	Marn	Thobas	he	2	2	2025-12-15 15:33:29.298	2025-12-16 08:11:37.382	2025-12-16 08:11:37.402	\N	1	\N
7	j94rtwmquwblf83a26ezgb1a	Denrick	Largent	he	2	2	2025-12-15 15:33:29.233	2025-12-16 08:11:44.14	\N	\N	1	\N
20	j94rtwmquwblf83a26ezgb1a	Denrick	Largent	he	2	2	2025-12-15 15:33:29.233	2025-12-16 08:11:44.14	2025-12-16 08:11:44.161	\N	1	\N
3	nlivv26vf3m1r8plzme4hh31	Garen	Fouldier	he	2	2	2025-12-15 15:33:29.083	2025-12-16 08:11:50.629	\N	\N	1	\N
22	nlivv26vf3m1r8plzme4hh31	Garen	Fouldier	he	2	2	2025-12-15 15:33:29.083	2025-12-16 08:11:50.629	2025-12-16 08:11:50.647	\N	1	\N
1	idclf66kb5m7vfohs0v8t9ox	Malori	Marnett	she	2	2	2025-12-15 15:33:29.001	2025-12-16 08:11:57.301	\N	\N	1	\N
24	idclf66kb5m7vfohs0v8t9ox	Malori	Marnett	she	2	2	2025-12-15 15:33:29.001	2025-12-16 08:11:57.301	2025-12-16 08:11:57.321	\N	1	\N
\.


--
-- Data for Name: pois; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.pois (id, document_id, name, lat, lng, geohash, location, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	lqsytx2gc3j6ecbb0yuigvax	Eglise Saint-Georges-Montcocq	49.12475549999999	-1.0916814	gbxprnvh3	{"lat": 49.12475549999999, "lng": -1.0916814}	2025-12-15 15:41:12.98	2025-12-15 15:41:12.98	\N	\N	\N	\N
2	lqsytx2gc3j6ecbb0yuigvax	Eglise Saint-Georges-Montcocq	49.12475549999999	-1.0916814	gbxprnvh3	{"lat": 49.12475549999999, "lng": -1.0916814}	2025-12-15 15:41:12.98	2025-12-15 15:41:12.98	2025-12-15 15:41:13.01	\N	\N	\N
3	skulc8jmbqluj9695y1q05w6	Eglise Protestante Evangélique	49.1161153	-1.1012418	gbxpqvq45	{"lat": 49.1161153, "lng": -1.1012418}	2025-12-15 15:41:13.094	2025-12-15 15:41:13.094	\N	\N	\N	\N
4	skulc8jmbqluj9695y1q05w6	Eglise Protestante Evangélique	49.1161153	-1.1012418	gbxpqvq45	{"lat": 49.1161153, "lng": -1.1012418}	2025-12-15 15:41:13.094	2025-12-15 15:41:13.094	2025-12-15 15:41:13.112	\N	\N	\N
5	yq8ck7ganxjyt05s73stsmz3	Paroisse Saint-Georges-Montcocq	49.1302773	-1.0947743	gbxprpfu9	{"lat": 49.1302773, "lng": -1.0947743}	2025-12-15 15:41:13.183	2025-12-15 15:41:13.183	\N	\N	\N	\N
6	yq8ck7ganxjyt05s73stsmz3	Paroisse Saint-Georges-Montcocq	49.1302773	-1.0947743	gbxprpfu9	{"lat": 49.1302773, "lng": -1.0947743}	2025-12-15 15:41:13.183	2025-12-15 15:41:13.183	2025-12-15 15:41:13.2	\N	\N	\N
7	luzkdup54jm1dhky3800fei2	Chapelle de la Madeleine	49.1172592	-1.0611048	gbxprve2f	{"lat": 49.1172592, "lng": -1.0611048}	2025-12-15 15:41:13.27	2025-12-15 15:41:13.27	\N	\N	\N	\N
8	luzkdup54jm1dhky3800fei2	Chapelle de la Madeleine	49.1172592	-1.0611048	gbxprve2f	{"lat": 49.1172592, "lng": -1.0611048}	2025-12-15 15:41:13.27	2025-12-15 15:41:13.27	2025-12-15 15:41:13.288	\N	\N	\N
9	c0bdvmbpl8l3yfe6sdqbwbnd	Paroisse St Lô	49.115188	-1.0935621	gbxprj5sw	{"lat": 49.115188, "lng": -1.0935621}	2025-12-15 15:41:13.361	2025-12-15 15:41:13.361	\N	\N	\N	\N
10	c0bdvmbpl8l3yfe6sdqbwbnd	Paroisse St Lô	49.115188	-1.0935621	gbxprj5sw	{"lat": 49.115188, "lng": -1.0935621}	2025-12-15 15:41:13.361	2025-12-15 15:41:13.361	2025-12-15 15:41:13.377	\N	\N	\N
11	wg7xbn7025d42kstmgqgz9pw	Église Sainte-Croix de Saint-Lô	49.1163147	-1.0851875	gbxprm3g3	{"lat": 49.1163147, "lng": -1.0851875}	2025-12-15 15:41:13.449	2025-12-15 15:41:13.449	\N	\N	\N	\N
12	wg7xbn7025d42kstmgqgz9pw	Église Sainte-Croix de Saint-Lô	49.1163147	-1.0851875	gbxprm3g3	{"lat": 49.1163147, "lng": -1.0851875}	2025-12-15 15:41:13.449	2025-12-15 15:41:13.449	2025-12-15 15:41:13.467	\N	\N	\N
13	uh3yj2coh8gsqi85s5w8lmtn	Église Évangélique Baptiste Chemin Nouveau	49.11823709999999	-1.0839685	gbxprmdwm	{"lat": 49.11823709999999, "lng": -1.0839685}	2025-12-15 15:41:13.529	2025-12-15 15:41:13.529	\N	\N	\N	\N
14	uh3yj2coh8gsqi85s5w8lmtn	Église Évangélique Baptiste Chemin Nouveau	49.11823709999999	-1.0839685	gbxprmdwm	{"lat": 49.11823709999999, "lng": -1.0839685}	2025-12-15 15:41:13.529	2025-12-15 15:41:13.529	2025-12-15 15:41:13.548	\N	\N	\N
15	zbnia86kcuhzkbqtem0jxrcq	Temple Protestant (EPUF Saint-Lô)	49.1123323	-1.0878872	gbxprhxu4	{"lat": 49.1123323, "lng": -1.0878872}	2025-12-15 15:41:13.613	2025-12-15 15:41:13.613	\N	\N	\N	\N
16	zbnia86kcuhzkbqtem0jxrcq	Temple Protestant (EPUF Saint-Lô)	49.1123323	-1.0878872	gbxprhxu4	{"lat": 49.1123323, "lng": -1.0878872}	2025-12-15 15:41:13.613	2025-12-15 15:41:13.613	2025-12-15 15:41:13.631	\N	\N	\N
17	any8rlcv6zrdbj8igi3n4b8j	Église Notre-Dame de Saint-Lô	49.1153209	-1.0942457	gbxprj5jq	{"lat": 49.1153209, "lng": -1.0942457}	2025-12-15 15:41:13.703	2025-12-15 15:41:13.703	\N	\N	\N	\N
18	any8rlcv6zrdbj8igi3n4b8j	Église Notre-Dame de Saint-Lô	49.1153209	-1.0942457	gbxprj5jq	{"lat": 49.1153209, "lng": -1.0942457}	2025-12-15 15:41:13.703	2025-12-15 15:41:13.703	2025-12-15 15:41:13.72	\N	\N	\N
19	rx5qdot6nzih5mxjkng7g4wd	Église Saint-Jean-Baptiste d'Agneaux	49.11527590000001	-1.1128985	gbxpqtjt5	{"lat": 49.11527590000001, "lng": -1.1128985}	2025-12-15 15:41:13.791	2025-12-15 15:41:13.791	\N	\N	\N	\N
20	rx5qdot6nzih5mxjkng7g4wd	Église Saint-Jean-Baptiste d'Agneaux	49.11527590000001	-1.1128985	gbxpqtjt5	{"lat": 49.11527590000001, "lng": -1.1128985}	2025-12-15 15:41:13.791	2025-12-15 15:41:13.791	2025-12-15 15:41:13.809	\N	\N	\N
21	ahr0cppmp0ab33vdem599xna	Chapelle Sainte-Marie	49.12055410000001	-1.12082	gbxpqqpgg	{"lat": 49.12055410000001, "lng": -1.12082}	2025-12-15 15:41:13.875	2025-12-15 15:41:13.875	\N	\N	\N	\N
22	ahr0cppmp0ab33vdem599xna	Chapelle Sainte-Marie	49.12055410000001	-1.12082	gbxpqqpgg	{"lat": 49.12055410000001, "lng": -1.12082}	2025-12-15 15:41:13.875	2025-12-15 15:41:13.875	2025-12-15 15:41:13.895	\N	\N	\N
23	f53kbqrnj4er1yqsupcq0z0g	Église Saint-Ouen	49.0898695	-1.0732579	gbxpr8d3p	{"lat": 49.0898695, "lng": -1.0732579}	2025-12-15 15:41:13.967	2025-12-15 15:41:13.967	\N	\N	\N	\N
24	f53kbqrnj4er1yqsupcq0z0g	Église Saint-Ouen	49.0898695	-1.0732579	gbxpr8d3p	{"lat": 49.0898695, "lng": -1.0732579}	2025-12-15 15:41:13.967	2025-12-15 15:41:13.967	2025-12-15 15:41:13.983	\N	\N	\N
25	uv1lo7nvho5vqbkclakyhyun	Église Saint-Ébremond de La Barre-de-Semilly	49.11216959999999	-1.0347306	gbxr2kwe1	{"lat": 49.11216959999999, "lng": -1.0347306}	2025-12-15 15:41:14.07	2025-12-15 15:41:14.07	\N	\N	\N	\N
26	uv1lo7nvho5vqbkclakyhyun	Église Saint-Ébremond de La Barre-de-Semilly	49.11216959999999	-1.0347306	gbxr2kwe1	{"lat": 49.11216959999999, "lng": -1.0347306}	2025-12-15 15:41:14.07	2025-12-15 15:41:14.07	2025-12-15 15:41:14.086	\N	\N	\N
27	zt936nikvt6oxi0lnl9w0x67	Église Saint-Pierre	49.1395431	-1.0499288	gbxr81e6w	{"lat": 49.1395431, "lng": -1.0499288}	2025-12-15 15:41:14.149	2025-12-15 15:41:14.149	\N	\N	\N	\N
28	zt936nikvt6oxi0lnl9w0x67	Église Saint-Pierre	49.1395431	-1.0499288	gbxr81e6w	{"lat": 49.1395431, "lng": -1.0499288}	2025-12-15 15:41:14.149	2025-12-15 15:41:14.149	2025-12-15 15:41:14.165	\N	\N	\N
29	bkh5qrluh22ry6f97rc2csst	Église Notre-Dame	49.147508	-1.0878035	gbxpx5pbu	{"lat": 49.147508, "lng": -1.0878035}	2025-12-15 15:41:14.246	2025-12-15 15:41:14.246	\N	\N	\N	\N
30	bkh5qrluh22ry6f97rc2csst	Église Notre-Dame	49.147508	-1.0878035	gbxpx5pbu	{"lat": 49.147508, "lng": -1.0878035}	2025-12-15 15:41:14.246	2025-12-15 15:41:14.246	2025-12-15 15:41:14.266	\N	\N	\N
31	vlwrfxfi027ebyb8is5821nb	Mosquée de Saint-Lô	49.112188	-1.0509799	gbxr2hden	{"lat": 49.112188, "lng": -1.0509799}	2025-12-15 15:41:14.408	2025-12-15 15:41:14.408	\N	\N	\N	\N
32	vlwrfxfi027ebyb8is5821nb	Mosquée de Saint-Lô	49.112188	-1.0509799	gbxr2hden	{"lat": 49.112188, "lng": -1.0509799}	2025-12-15 15:41:14.408	2025-12-15 15:41:14.408	2025-12-15 15:41:14.435	\N	\N	\N
33	t7v0p1ot3iw7uexygnqlun5g	Saint lo new mosque	49.0894289	-1.0729745	gbxpr86wt	{"lat": 49.0894289, "lng": -1.0729745}	2025-12-15 15:41:14.558	2025-12-15 15:41:14.558	\N	\N	\N	\N
34	t7v0p1ot3iw7uexygnqlun5g	Saint lo new mosque	49.0894289	-1.0729745	gbxpr86wt	{"lat": 49.0894289, "lng": -1.0729745}	2025-12-15 15:41:14.558	2025-12-15 15:41:14.558	2025-12-15 15:41:14.582	\N	\N	\N
35	szszzli58ds3lmu3o0v0yscn	Masjid jum'ah saint lo	49.0893984	-1.0724819	gbxpr87n3	{"lat": 49.0893984, "lng": -1.0724819}	2025-12-15 15:41:14.661	2025-12-15 15:41:14.661	\N	\N	\N	\N
36	szszzli58ds3lmu3o0v0yscn	Masjid jum'ah saint lo	49.0893984	-1.0724819	gbxpr87n3	{"lat": 49.0893984, "lng": -1.0724819}	2025-12-15 15:41:14.661	2025-12-15 15:41:14.661	2025-12-15 15:41:14.679	\N	\N	\N
37	xmdto8bzjhkch9qvvi01gup8	Les remparts de St Lô	49.11484600000001	-1.0950936	gbxprj4dd	{"lat": 49.11484600000001, "lng": -1.0950936}	2025-12-15 15:41:14.751	2025-12-15 15:41:14.751	\N	\N	\N	\N
38	xmdto8bzjhkch9qvvi01gup8	Les remparts de St Lô	49.11484600000001	-1.0950936	gbxprj4dd	{"lat": 49.11484600000001, "lng": -1.0950936}	2025-12-15 15:41:14.751	2025-12-15 15:41:14.751	2025-12-15 15:41:14.768	\N	\N	\N
39	j6bymzzd98se0znvjmzt7a67	Wandmalerei	49.11504739999999	-1.0968636	gbxprj17c	{"lat": 49.11504739999999, "lng": -1.0968636}	2025-12-15 15:41:14.829	2025-12-15 15:41:14.829	\N	\N	\N	\N
40	j6bymzzd98se0znvjmzt7a67	Wandmalerei	49.11504739999999	-1.0968636	gbxprj17c	{"lat": 49.11504739999999, "lng": -1.0968636}	2025-12-15 15:41:14.829	2025-12-15 15:41:14.829	2025-12-15 15:41:14.845	\N	\N	\N
41	hj7t2kmqgvlzj5m1zj1fgktx	Monument des Fusillés	49.10455229999999	-1.0922606	gbxpr5hwu	{"lat": 49.10455229999999, "lng": -1.0922606}	2025-12-15 15:41:14.909	2025-12-15 15:41:14.909	\N	\N	\N	\N
42	hj7t2kmqgvlzj5m1zj1fgktx	Monument des Fusillés	49.10455229999999	-1.0922606	gbxpr5hwu	{"lat": 49.10455229999999, "lng": -1.0922606}	2025-12-15 15:41:14.909	2025-12-15 15:41:14.909	2025-12-15 15:41:14.926	\N	\N	\N
\.


--
-- Data for Name: quests; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.quests (id, document_id, is_poi_a_completed, is_poi_b_completed, date_start, date_end, gold_earned, xp_earned, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: quests_guild_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.quests_guild_lnk (id, quest_id, guild_id, quest_ord) FROM stdin;
\.


--
-- Data for Name: quests_npc_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.quests_npc_lnk (id, quest_id, npc_id, quest_ord) FROM stdin;
\.


--
-- Data for Name: quests_poi_a_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.quests_poi_a_lnk (id, quest_id, poi_id, quest_ord) FROM stdin;
\.


--
-- Data for Name: quests_poi_b_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.quests_poi_b_lnk (id, quest_id, poi_id, quest_ord) FROM stdin;
\.


--
-- Data for Name: rarities; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.rarities (id, document_id, name, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	yk5dzvgdseckp0ze2n1vht8p	common	2025-12-15 15:33:28.449	2025-12-18 14:02:27.867	\N	\N	1	\N
9	yk5dzvgdseckp0ze2n1vht8p	common	2025-12-15 15:33:28.449	2025-12-18 14:02:27.867	2025-12-18 14:02:27.885	\N	1	\N
3	sb31x2jv7ba02m75zdruk63o	rare	2025-12-15 15:33:28.529	2025-12-18 14:02:32.399	\N	\N	1	\N
10	sb31x2jv7ba02m75zdruk63o	rare	2025-12-15 15:33:28.529	2025-12-18 14:02:32.399	2025-12-18 14:02:32.413	\N	1	\N
5	e16y0qfibdsvs9uhwa2nrfs9	epic	2025-12-15 15:33:28.588	2025-12-18 14:02:36.551	\N	\N	1	\N
11	e16y0qfibdsvs9uhwa2nrfs9	epic	2025-12-15 15:33:28.588	2025-12-18 14:02:36.551	2025-12-18 14:02:36.564	\N	1	\N
7	bfujhhvf1lbiemiea05z41oq	legendary	2025-12-15 15:33:28.632	2025-12-18 14:02:42.183	\N	\N	1	\N
12	bfujhhvf1lbiemiea05z41oq	legendary	2025-12-15 15:33:28.632	2025-12-18 14:02:42.183	2025-12-18 14:02:42.196	\N	1	\N
13	x7hl315rs12j3s6sux36828b	Commun	2025-12-18 14:47:27.224	2025-12-18 14:47:27.224	\N	\N	\N	\N
14	x7hl315rs12j3s6sux36828b	Commun	2025-12-18 14:47:27.224	2025-12-18 14:47:27.224	2025-12-18 14:47:27.248	\N	\N	\N
15	gtl0rkwkpyt02o8p6c3u0xpe	Rare	2025-12-18 14:47:27.27	2025-12-18 14:47:27.27	\N	\N	\N	\N
16	gtl0rkwkpyt02o8p6c3u0xpe	Rare	2025-12-18 14:47:27.27	2025-12-18 14:47:27.27	2025-12-18 14:47:27.296	\N	\N	\N
17	xhi45ekg7xnz4ger9hqs4k56	Épique	2025-12-18 14:47:27.317	2025-12-18 14:47:27.317	\N	\N	\N	\N
18	xhi45ekg7xnz4ger9hqs4k56	Épique	2025-12-18 14:47:27.317	2025-12-18 14:47:27.317	2025-12-18 14:47:27.329	\N	\N	\N
19	mgxvimegkqajp3j5dqyq5qjw	Légendaire	2025-12-18 14:47:27.354	2025-12-18 14:47:27.354	\N	\N	\N	\N
20	mgxvimegkqajp3j5dqyq5qjw	Légendaire	2025-12-18 14:47:27.354	2025-12-18 14:47:27.354	2025-12-18 14:47:27.362	\N	\N	\N
\.


--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.runs (id, document_id, dps, date_start, date_end, gold_earned, xp_earned, threshold_reached, target_threshold, entry_unlocked, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: runs_guild_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.runs_guild_lnk (id, run_id, guild_id, run_ord) FROM stdin;
\.


--
-- Data for Name: runs_museum_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.runs_museum_lnk (id, run_id, museum_id, run_ord) FROM stdin;
\.


--
-- Data for Name: runs_npc_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.runs_npc_lnk (id, run_id, npc_id, run_ord) FROM stdin;
\.


--
-- Data for Name: strapi_ai_localization_jobs; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_ai_localization_jobs (id, content_type, related_document_id, source_locale, target_locales, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: strapi_api_token_permissions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_api_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_api_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_api_token_permissions_token_lnk (id, api_token_permission_id, api_token_id, api_token_permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_api_tokens; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_api_tokens (id, document_id, name, description, type, access_key, encrypted_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	i7bk62wmmo7036xyze4y5fpm	Read Only	A default API token with read-only permissions, only used for accessing resources	read-only	7b2741dfae9d270a2bd046a7ecf35c046fdf591540af08a64833f9159a6bd5708accd37decac3f60a6f9f43d19faf3344ab63a7eecd6a4c32693a4d2193b5592	v1:8f636ed2c868f259823b768385645868:9be895d2aa140cfca04903a51fd00b1d4348363b84523cbbf1df8ea2826a0895521e0d49fba5d146db1dd53f656d7402785f034b9aae915ac1b3c0af26b0aef015ffe6005e22970c04210ba960390db265dbf567c7e4617e3c6fa9249510b260316b6a9a5807e6f8204b03a9f95e7097e65ee6a4b2bcac02cee209e14569beb250b16c080f83c197c81c353e1a2757f0180b94a8e754f3a23eb8c706c2d1bf389406d3870666907fdfe490f50dde8e87bda9136dd58852d1b9eb7883f8d4a48d376eb5965b116e80a5b6eb8d2ff5bfa5b7bbd7d2718d8bde7787be30a6b7460554ede5fe35956575951bc5ba8f0ecc35d97a900bae907cf635031b8e58a1bcd6:561bf1617cf86f0c573587ceff775eb1	\N	\N	\N	2025-12-15 15:33:28.342	2025-12-15 15:33:28.342	2025-12-15 15:33:28.342	\N	\N	\N
2	woud8ldncaszc68gtluncbze	Full Access	A default API token with full access permissions, used for accessing or modifying resources	full-access	32d7ef0b83067d29de3a0d455ef5b12b58e26e833b1bf6ed1bea1fefd386341ed9f8ac793fb3b152209cc0152241fd17215d31695bcae03f9525a471c01e5360	v1:1e7ff53e3006a8e4001bc43ff337c483:b4c35cdb23bb75ec7780133e1974b4d6ac8fd95309a7d3825fcc4a29f392cf91390b5fa61088d82dc5b9e99cd9f213b96f7fb39ea99f2a54baf7b2f7c1f22eded0faf7c7cf3c0aca54007714c86133759e69dcad692107bfc007b3e79b1619407f153611d843e89bdb3881673f4a69e376960e065af433aedb2a557ea730c50c5a4113d3348b6d32c35c21164ed09b5d2747084e521aee2c48c46435168a200597d95f3129bbc5e6846daaaab52382fde7656318be3d66fd04820af83f0e38b1306e88abf48018a1f1aa562cabc30c80b4dbe62b85ffe9bb682679821a1c9242cfb70a08c5feabd65237e8a8fc176c72c08dfd729a7d9c1be54a33c61bf0ac27:40eb745eabbc43905ae833d7e89c529e	2025-12-15 15:41:12.232	\N	\N	2025-12-15 15:33:28.361	2025-12-15 15:41:12.232	2025-12-15 15:33:28.361	\N	\N	\N
\.


--
-- Data for Name: strapi_core_store_settings; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_core_store_settings (id, key, value, type, environment, tag) FROM stdin;
1	strapi_unidirectional-join-table-repair-ran	true	boolean	\N	\N
3	plugin_content_manager_configuration_content_types::plugin::upload.file	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"alternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"alternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caption","searchable":true,"sortable":true}},"width":{"edit":{"label":"width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"width","searchable":true,"sortable":true}},"height":{"edit":{"label":"height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"size","searchable":true,"sortable":true}},"url":{"edit":{"label":"url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"previewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"previewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider_metadata","searchable":false,"sortable":false}},"folder":{"edit":{"label":"folder","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"folder","searchable":true,"sortable":true}},"folderPath":{"edit":{"label":"folderPath","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"folderPath","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","alternativeText","caption"],"edit":[[{"name":"name","size":6},{"name":"alternativeText","size":6}],[{"name":"caption","size":6},{"name":"width","size":4}],[{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"hash","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"previewUrl","size":6}],[{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}],[{"name":"folder","size":6},{"name":"folderPath","size":6}]]},"uid":"plugin::upload.file"}	object	\N	\N
4	plugin_content_manager_configuration_content_types::plugin::upload.folder	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"pathId":{"edit":{"label":"pathId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"pathId","searchable":true,"sortable":true}},"parent":{"edit":{"label":"parent","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"parent","searchable":true,"sortable":true}},"children":{"edit":{"label":"children","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"children","searchable":false,"sortable":false}},"files":{"edit":{"label":"files","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"files","searchable":false,"sortable":false}},"path":{"edit":{"label":"path","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"path","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","pathId","parent"],"edit":[[{"name":"name","size":6},{"name":"pathId","size":4}],[{"name":"parent","size":6},{"name":"children","size":6}],[{"name":"files","size":6},{"name":"path","size":6}]]},"uid":"plugin::upload.folder"}	object	\N	\N
5	plugin_content_manager_configuration_content_types::plugin::content-releases.release	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"releasedAt":{"edit":{"label":"releasedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"releasedAt","searchable":true,"sortable":true}},"scheduledAt":{"edit":{"label":"scheduledAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"scheduledAt","searchable":true,"sortable":true}},"timezone":{"edit":{"label":"timezone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"timezone","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"actions":{"edit":{"label":"actions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"contentType"},"list":{"label":"actions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","releasedAt","scheduledAt"],"edit":[[{"name":"name","size":6},{"name":"releasedAt","size":6}],[{"name":"scheduledAt","size":6},{"name":"timezone","size":6}],[{"name":"status","size":6},{"name":"actions","size":6}]]},"uid":"plugin::content-releases.release"}	object	\N	\N
6	plugin_content_manager_configuration_content_types::plugin::users-permissions.role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"users","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"permissions","size":6}],[{"name":"users","size":6}]]},"uid":"plugin::users-permissions.role"}	object	\N	\N
8	plugin_content_manager_configuration_content_types::api::dialog.dialog	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"documentId","defaultSortBy":"documentId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"text_type":{"edit":{"label":"text_type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"text_type","searchable":true,"sortable":true}},"dialogues":{"edit":{"label":"dialogues","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"dialogues","searchable":false,"sortable":false}},"npc":{"edit":{"label":"npc","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"npc","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","text_type","npc","createdAt"],"edit":[[{"name":"text_type","size":6}],[{"name":"dialogues","size":12}],[{"name":"npc","size":6}]]},"uid":"api::dialog.dialog"}	object	\N	\N
9	plugin_content_manager_configuration_content_types::plugin::users-permissions.user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"confirmationToken":{"edit":{"label":"confirmationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"confirmationToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"guild":{"edit":{"label":"guild","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"guild","searchable":true,"sortable":true}},"age":{"edit":{"label":"age","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"age","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"role","size":6}],[{"name":"guild","size":6},{"name":"age","size":4}]]},"uid":"plugin::users-permissions.user"}	object	\N	\N
10	plugin_content_manager_configuration_content_types::plugin::content-releases.release-action	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"contentType","defaultSortBy":"contentType","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"contentType":{"edit":{"label":"contentType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentType","searchable":true,"sortable":true}},"entryDocumentId":{"edit":{"label":"entryDocumentId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"entryDocumentId","searchable":true,"sortable":true}},"release":{"edit":{"label":"release","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"release","searchable":true,"sortable":true}},"isEntryValid":{"edit":{"label":"isEntryValid","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isEntryValid","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","type","contentType","entryDocumentId"],"edit":[[{"name":"type","size":6},{"name":"contentType","size":6}],[{"name":"entryDocumentId","size":6},{"name":"release","size":6}],[{"name":"isEntryValid","size":4}]]},"uid":"plugin::content-releases.release-action"}	object	\N	\N
12	plugin_content_manager_configuration_content_types::api::friendship.friendship	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"documentId","defaultSortBy":"documentId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"quests_entry_unlocked":{"edit":{"label":"quests_entry_unlocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"quests_entry_unlocked","searchable":true,"sortable":true}},"expedition_entry_unlocked":{"edit":{"label":"expedition_entry_unlocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expedition_entry_unlocked","searchable":true,"sortable":true}},"npc":{"edit":{"label":"npc","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"npc","searchable":true,"sortable":true}},"guild":{"edit":{"label":"guild","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"guild","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","quests_entry_unlocked","expedition_entry_unlocked","npc"],"edit":[[{"name":"quests_entry_unlocked","size":4},{"name":"expedition_entry_unlocked","size":4}],[{"name":"npc","size":6},{"name":"guild","size":6}]]},"uid":"api::friendship.friendship"}	object	\N	\N
30	plugin_content_manager_configuration_content_types::admin::api-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"encryptedKey":{"edit":{"label":"encryptedKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"encryptedKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"accessKey","size":6}],[{"name":"encryptedKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::api-token"}	object	\N	\N
2	strapi_content_types_schema	{"plugin::upload.file":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"files"}}},"indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null}],"plugin":"upload","globalId":"UploadFile","uid":"plugin::upload.file","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"file"},"plugin::upload.folder":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"upload_folders"}}},"indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"}],"plugin":"upload","globalId":"UploadFolder","uid":"plugin::upload.folder","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true}},"kind":"collectionType"},"modelName":"folder"},"plugin::i18n.locale":{"info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::i18n.locale","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"i18n_locale"}}},"plugin":"i18n","collectionName":"i18n_locale","globalId":"I18NLocale","uid":"plugin::i18n.locale","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"i18n_locale","info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false}},"kind":"collectionType"},"modelName":"locale"},"plugin::content-releases.release":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_releases"}}},"plugin":"content-releases","globalId":"ContentReleasesRelease","uid":"plugin::content-releases.release","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"}},"kind":"collectionType"},"modelName":"release"},"plugin::content-releases.release-action":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_release_actions"}}},"plugin":"content-releases","globalId":"ContentReleasesReleaseAction","uid":"plugin::content-releases.release-action","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"}},"kind":"collectionType"},"modelName":"release-action"},"plugin::review-workflows.workflow":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflow","uid":"plugin::review-workflows.workflow","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"}},"kind":"collectionType"},"modelName":"workflow"},"plugin::review-workflows.workflow-stage":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0","draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow-stage","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows_stages"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflowStage","uid":"plugin::review-workflows.workflow-stage","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false}},"kind":"collectionType"},"modelName":"workflow-stage"},"plugin::users-permissions.permission":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_permissions"}}},"plugin":"users-permissions","globalId":"UsersPermissionsPermission","uid":"plugin::users-permissions.permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false}},"kind":"collectionType"},"modelName":"permission","options":{"draftAndPublish":false}},"plugin::users-permissions.role":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_roles"}}},"plugin":"users-permissions","globalId":"UsersPermissionsRole","uid":"plugin::users-permissions.role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false}},"kind":"collectionType"},"modelName":"role","options":{"draftAndPublish":false}},"plugin::users-permissions.user":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"draftAndPublish":false},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"guild":{"type":"relation","relation":"oneToOne","target":"api::guild.guild"},"age":{"type":"integer"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"confirmationToken":{"hidden":true},"provider":{"hidden":true}}},"plugin":"users-permissions","globalId":"UsersPermissionsUser","kind":"collectionType","pluginOptions":{},"__filename__":"schema.json","uid":"plugin::users-permissions.user","modelType":"contentType","__schema__":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"draftAndPublish":false},"pluginOptions":{},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"guild":{"type":"relation","relation":"oneToOne","target":"api::guild.guild"},"age":{"type":"integer"}},"kind":"collectionType"},"modelName":"user"},"api::character.character":{"kind":"collectionType","collectionName":"characters","info":{"singularName":"character","pluralName":"characters","displayName":"Character"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"firstname":{"type":"string","required":true},"lastname":{"type":"string","required":true},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"characters"},"items":{"type":"relation","relation":"oneToMany","target":"api::item.item","mappedBy":"character"},"icon":{"type":"media","multiple":false,"allowedTypes":["images","files","videos","audios"]},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::character.character","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"characters"}}},"apiName":"character","globalId":"Character","uid":"api::character.character","modelType":"contentType","__schema__":{"collectionName":"characters","info":{"singularName":"character","pluralName":"characters","displayName":"Character"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"firstname":{"type":"string","required":true},"lastname":{"type":"string","required":true},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"characters"},"items":{"type":"relation","relation":"oneToMany","target":"api::item.item","mappedBy":"character"},"icon":{"type":"media","multiple":false,"allowedTypes":["images","files","videos","audios"]}},"kind":"collectionType"},"modelName":"character","actions":{},"lifecycles":{}},"api::dialog.dialog":{"kind":"collectionType","collectionName":"dialogs","info":{"singularName":"dialog","pluralName":"dialogs","displayName":"Dialog"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"text_type":{"type":"enumeration","enum":["quest_description","expedition_appear","expedition_fail","quest_complete","journal_entries"],"required":true},"dialogues":{"type":"json","required":true},"npc":{"type":"relation","relation":"manyToOne","target":"api::npc.npc","inversedBy":"dialogs"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::dialog.dialog","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"dialogs"}}},"apiName":"dialog","globalId":"Dialog","uid":"api::dialog.dialog","modelType":"contentType","__schema__":{"collectionName":"dialogs","info":{"singularName":"dialog","pluralName":"dialogs","displayName":"Dialog"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"text_type":{"type":"enumeration","enum":["quest_description","expedition_appear","expedition_fail","quest_complete","journal_entries"],"required":true},"dialogues":{"type":"json","required":true},"npc":{"type":"relation","relation":"manyToOne","target":"api::npc.npc","inversedBy":"dialogs"}},"kind":"collectionType"},"modelName":"dialog","actions":{},"lifecycles":{}},"api::friendship.friendship":{"kind":"collectionType","collectionName":"friendships","info":{"singularName":"friendship","pluralName":"friendships","displayName":"Friendship"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"quests_entry_unlocked":{"type":"integer","default":0,"required":true},"expedition_entry_unlocked":{"type":"integer","default":0,"required":true},"npc":{"type":"relation","relation":"manyToOne","target":"api::npc.npc","inversedBy":"friendships"},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"friendships"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::friendship.friendship","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"friendships"}}},"apiName":"friendship","globalId":"Friendship","uid":"api::friendship.friendship","modelType":"contentType","__schema__":{"collectionName":"friendships","info":{"singularName":"friendship","pluralName":"friendships","displayName":"Friendship"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"quests_entry_unlocked":{"type":"integer","default":0,"required":true},"expedition_entry_unlocked":{"type":"integer","default":0,"required":true},"npc":{"type":"relation","relation":"manyToOne","target":"api::npc.npc","inversedBy":"friendships"},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"friendships"}},"kind":"collectionType"},"modelName":"friendship","actions":{},"lifecycles":{}},"api::guild.guild":{"kind":"collectionType","collectionName":"guilds","info":{"singularName":"guild","pluralName":"guilds","displayName":"Guild"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"gold":{"type":"integer","default":0,"required":true},"exp":{"type":"biginteger","default":"0"},"scrap":{"type":"integer","default":0,"required":true},"user":{"type":"relation","relation":"oneToOne","target":"plugin::users-permissions.user"},"characters":{"type":"relation","relation":"oneToMany","target":"api::character.character","mappedBy":"guild"},"items":{"type":"relation","relation":"oneToMany","target":"api::item.item","mappedBy":"guild"},"visits":{"type":"relation","relation":"oneToMany","target":"api::visit.visit","mappedBy":"guild"},"runs":{"type":"relation","relation":"oneToMany","target":"api::run.run","mappedBy":"guild"},"friendships":{"type":"relation","relation":"oneToMany","target":"api::friendship.friendship","mappedBy":"guild"},"quests":{"type":"relation","relation":"oneToMany","target":"api::quest.quest","mappedBy":"guild"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::guild.guild","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"guilds"}}},"apiName":"guild","globalId":"Guild","uid":"api::guild.guild","modelType":"contentType","__schema__":{"collectionName":"guilds","info":{"singularName":"guild","pluralName":"guilds","displayName":"Guild"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"gold":{"type":"integer","default":0,"required":true},"exp":{"type":"biginteger","default":"0"},"scrap":{"type":"integer","default":0,"required":true},"user":{"type":"relation","relation":"oneToOne","target":"plugin::users-permissions.user"},"characters":{"type":"relation","relation":"oneToMany","target":"api::character.character","mappedBy":"guild"},"items":{"type":"relation","relation":"oneToMany","target":"api::item.item","mappedBy":"guild"},"visits":{"type":"relation","relation":"oneToMany","target":"api::visit.visit","mappedBy":"guild"},"runs":{"type":"relation","relation":"oneToMany","target":"api::run.run","mappedBy":"guild"},"friendships":{"type":"relation","relation":"oneToMany","target":"api::friendship.friendship","mappedBy":"guild"},"quests":{"type":"relation","relation":"oneToMany","target":"api::quest.quest","mappedBy":"guild"}},"kind":"collectionType"},"modelName":"guild","actions":{},"lifecycles":{}},"api::item.item":{"kind":"collectionType","collectionName":"items","info":{"singularName":"item","pluralName":"items","displayName":"Item"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"level":{"type":"integer","required":true},"index_damage":{"type":"integer","required":true},"slot":{"type":"enumeration","required":true,"enum":["weapon","helmet","charm"]},"isScrapped":{"type":"boolean","required":true,"default":false},"rarity":{"type":"relation","relation":"manyToOne","target":"api::rarity.rarity","inversedBy":"items"},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"items"},"character":{"type":"relation","relation":"manyToOne","target":"api::character.character","inversedBy":"items"},"tags":{"type":"relation","relation":"manyToMany","target":"api::tag.tag","inversedBy":"items"},"runs":{"type":"relation","relation":"manyToMany","target":"api::run.run","inversedBy":"items"},"visits":{"type":"relation","relation":"manyToMany","target":"api::visit.visit","inversedBy":"items"},"icon":{"type":"media","multiple":false,"allowedTypes":["images","files","videos","audios"]},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::item.item","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"items"}}},"apiName":"item","globalId":"Item","uid":"api::item.item","modelType":"contentType","__schema__":{"collectionName":"items","info":{"singularName":"item","pluralName":"items","displayName":"Item"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"level":{"type":"integer","required":true},"index_damage":{"type":"integer","required":true},"slot":{"type":"enumeration","required":true,"enum":["weapon","helmet","charm"]},"isScrapped":{"type":"boolean","required":true,"default":false},"rarity":{"type":"relation","relation":"manyToOne","target":"api::rarity.rarity","inversedBy":"items"},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"items"},"character":{"type":"relation","relation":"manyToOne","target":"api::character.character","inversedBy":"items"},"tags":{"type":"relation","relation":"manyToMany","target":"api::tag.tag","inversedBy":"items"},"runs":{"type":"relation","relation":"manyToMany","target":"api::run.run","inversedBy":"items"},"visits":{"type":"relation","relation":"manyToMany","target":"api::visit.visit","inversedBy":"items"},"icon":{"type":"media","multiple":false,"allowedTypes":["images","files","videos","audios"]}},"kind":"collectionType"},"modelName":"item","actions":{},"lifecycles":{}},"api::museum.museum":{"kind":"collectionType","collectionName":"museums","info":{"singularName":"museum","pluralName":"museums","displayName":"Museum"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"lat":{"type":"float","required":false},"lng":{"type":"float","required":false},"geohash":{"type":"string"},"tags":{"type":"relation","relation":"manyToMany","target":"api::tag.tag","inversedBy":"museums"},"runs":{"type":"relation","relation":"oneToMany","target":"api::run.run","mappedBy":"museum"},"location":{"type":"json","customField":"plugin::geodata.geojson","options":{"info":true}},"radius":{"type":"integer"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::museum.museum","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"museums"}}},"apiName":"museum","globalId":"Museum","uid":"api::museum.museum","modelType":"contentType","__schema__":{"collectionName":"museums","info":{"singularName":"museum","pluralName":"museums","displayName":"Museum"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"lat":{"type":"float","required":false},"lng":{"type":"float","required":false},"geohash":{"type":"string"},"tags":{"type":"relation","relation":"manyToMany","target":"api::tag.tag","inversedBy":"museums"},"runs":{"type":"relation","relation":"oneToMany","target":"api::run.run","mappedBy":"museum"},"location":{"type":"customField","customField":"plugin::geodata.geojson","options":{"info":true}},"radius":{"type":"integer"}},"kind":"collectionType"},"modelName":"museum","actions":{},"lifecycles":{}},"api::npc.npc":{"kind":"collectionType","collectionName":"npcs","info":{"singularName":"npc","pluralName":"npcs","displayName":"Npc"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"firstname":{"type":"string","required":true},"lastname":{"type":"string","required":true},"pronouns":{"type":"enumeration","enum":["he","she","they"],"required":true,"default":"they"},"quests_entry_available":{"type":"integer","default":0,"required":true},"expedition_entry_available":{"type":"integer","default":0,"required":true},"friendships":{"type":"relation","relation":"oneToMany","target":"api::friendship.friendship","mappedBy":"npc"},"quests":{"type":"relation","relation":"oneToMany","target":"api::quest.quest","mappedBy":"npc"},"dialogs":{"type":"relation","relation":"oneToMany","target":"api::dialog.dialog","mappedBy":"npc"},"runs":{"type":"relation","relation":"oneToMany","target":"api::run.run","mappedBy":"npc"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::npc.npc","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"npcs"}}},"apiName":"npc","globalId":"Npc","uid":"api::npc.npc","modelType":"contentType","__schema__":{"collectionName":"npcs","info":{"singularName":"npc","pluralName":"npcs","displayName":"Npc"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"firstname":{"type":"string","required":true},"lastname":{"type":"string","required":true},"pronouns":{"type":"enumeration","enum":["he","she","they"],"required":true,"default":"they"},"quests_entry_available":{"type":"integer","default":0,"required":true},"expedition_entry_available":{"type":"integer","default":0,"required":true},"friendships":{"type":"relation","relation":"oneToMany","target":"api::friendship.friendship","mappedBy":"npc"},"quests":{"type":"relation","relation":"oneToMany","target":"api::quest.quest","mappedBy":"npc"},"dialogs":{"type":"relation","relation":"oneToMany","target":"api::dialog.dialog","mappedBy":"npc"},"runs":{"type":"relation","relation":"oneToMany","target":"api::run.run","mappedBy":"npc"}},"kind":"collectionType"},"modelName":"npc","actions":{},"lifecycles":{}},"api::poi.poi":{"kind":"collectionType","collectionName":"pois","info":{"singularName":"poi","pluralName":"pois","displayName":"POI"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"lat":{"type":"float","required":false},"lng":{"type":"float","required":false},"geohash":{"type":"string"},"visits":{"type":"relation","relation":"oneToMany","target":"api::visit.visit","mappedBy":"poi"},"quests_a":{"type":"relation","relation":"oneToMany","target":"api::quest.quest","mappedBy":"poi_a"},"quests_b":{"type":"relation","relation":"oneToMany","target":"api::quest.quest","mappedBy":"poi_b"},"location":{"type":"json","customField":"plugin::geodata.geojson","options":{"info":true}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::poi.poi","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"pois"}}},"apiName":"poi","globalId":"Poi","uid":"api::poi.poi","modelType":"contentType","__schema__":{"collectionName":"pois","info":{"singularName":"poi","pluralName":"pois","displayName":"POI"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"lat":{"type":"float","required":false},"lng":{"type":"float","required":false},"geohash":{"type":"string"},"visits":{"type":"relation","relation":"oneToMany","target":"api::visit.visit","mappedBy":"poi"},"quests_a":{"type":"relation","relation":"oneToMany","target":"api::quest.quest","mappedBy":"poi_a"},"quests_b":{"type":"relation","relation":"oneToMany","target":"api::quest.quest","mappedBy":"poi_b"},"location":{"type":"customField","customField":"plugin::geodata.geojson","options":{"info":true}}},"kind":"collectionType"},"modelName":"poi","actions":{},"lifecycles":{}},"api::quest.quest":{"kind":"collectionType","collectionName":"quests","info":{"singularName":"quest","pluralName":"quests","displayName":"Quest"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"is_poi_a_completed":{"type":"boolean","default":false,"required":true},"is_poi_b_completed":{"type":"boolean","default":false,"required":true},"date_start":{"type":"datetime","required":true},"date_end":{"type":"datetime"},"gold_earned":{"type":"integer","default":0,"required":true},"xp_earned":{"type":"integer","default":0,"required":true},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"quests"},"npc":{"type":"relation","relation":"manyToOne","target":"api::npc.npc","inversedBy":"quests"},"poi_a":{"type":"relation","relation":"manyToOne","target":"api::poi.poi","inversedBy":"quests_a"},"poi_b":{"type":"relation","relation":"manyToOne","target":"api::poi.poi","inversedBy":"quests_b"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::quest.quest","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"quests"}}},"apiName":"quest","globalId":"Quest","uid":"api::quest.quest","modelType":"contentType","__schema__":{"collectionName":"quests","info":{"singularName":"quest","pluralName":"quests","displayName":"Quest"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"is_poi_a_completed":{"type":"boolean","default":false,"required":true},"is_poi_b_completed":{"type":"boolean","default":false,"required":true},"date_start":{"type":"datetime","required":true},"date_end":{"type":"datetime"},"gold_earned":{"type":"integer","default":0,"required":true},"xp_earned":{"type":"integer","default":0,"required":true},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"quests"},"npc":{"type":"relation","relation":"manyToOne","target":"api::npc.npc","inversedBy":"quests"},"poi_a":{"type":"relation","relation":"manyToOne","target":"api::poi.poi","inversedBy":"quests_a"},"poi_b":{"type":"relation","relation":"manyToOne","target":"api::poi.poi","inversedBy":"quests_b"}},"kind":"collectionType"},"modelName":"quest","actions":{},"lifecycles":{}},"api::rarity.rarity":{"kind":"collectionType","collectionName":"rarities","info":{"singularName":"rarity","pluralName":"rarities","displayName":"Rarity"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"items":{"type":"relation","relation":"oneToMany","target":"api::item.item","mappedBy":"rarity"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::rarity.rarity","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"rarities"}}},"apiName":"rarity","globalId":"Rarity","uid":"api::rarity.rarity","modelType":"contentType","__schema__":{"collectionName":"rarities","info":{"singularName":"rarity","pluralName":"rarities","displayName":"Rarity"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"items":{"type":"relation","relation":"oneToMany","target":"api::item.item","mappedBy":"rarity"}},"kind":"collectionType"},"modelName":"rarity","actions":{},"lifecycles":{}},"api::run.run":{"kind":"collectionType","collectionName":"runs","info":{"singularName":"run","pluralName":"runs","displayName":"Run"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"dps":{"type":"integer","required":true},"date_start":{"type":"datetime","required":true},"date_end":{"type":"datetime"},"gold_earned":{"type":"integer","default":0,"required":true},"xp_earned":{"type":"integer","default":0,"required":true},"threshold_reached":{"type":"integer","default":0,"required":true},"target_threshold":{"type":"integer"},"entry_unlocked":{"type":"boolean"},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"runs"},"museum":{"type":"relation","relation":"manyToOne","target":"api::museum.museum","inversedBy":"runs"},"npc":{"type":"relation","relation":"manyToOne","target":"api::npc.npc","inversedBy":"runs"},"items":{"type":"relation","relation":"manyToMany","target":"api::item.item","mappedBy":"runs"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::run.run","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"runs"}}},"apiName":"run","globalId":"Run","uid":"api::run.run","modelType":"contentType","__schema__":{"collectionName":"runs","info":{"singularName":"run","pluralName":"runs","displayName":"Run"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"dps":{"type":"integer","required":true},"date_start":{"type":"datetime","required":true},"date_end":{"type":"datetime"},"gold_earned":{"type":"integer","default":0,"required":true},"xp_earned":{"type":"integer","default":0,"required":true},"threshold_reached":{"type":"integer","default":0,"required":true},"target_threshold":{"type":"integer"},"entry_unlocked":{"type":"boolean"},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"runs"},"museum":{"type":"relation","relation":"manyToOne","target":"api::museum.museum","inversedBy":"runs"},"npc":{"type":"relation","relation":"manyToOne","target":"api::npc.npc","inversedBy":"runs"},"items":{"type":"relation","relation":"manyToMany","target":"api::item.item","mappedBy":"runs"}},"kind":"collectionType"},"modelName":"run","actions":{},"lifecycles":{}},"api::tag.tag":{"kind":"collectionType","collectionName":"tags","info":{"singularName":"tag","pluralName":"tags","displayName":"Tag"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"items":{"type":"relation","relation":"manyToMany","target":"api::item.item","mappedBy":"tags"},"museums":{"type":"relation","relation":"manyToMany","target":"api::museum.museum","mappedBy":"tags"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::tag.tag","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"tags"}}},"apiName":"tag","globalId":"Tag","uid":"api::tag.tag","modelType":"contentType","__schema__":{"collectionName":"tags","info":{"singularName":"tag","pluralName":"tags","displayName":"Tag"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"name":{"type":"string","required":true},"items":{"type":"relation","relation":"manyToMany","target":"api::item.item","mappedBy":"tags"},"museums":{"type":"relation","relation":"manyToMany","target":"api::museum.museum","mappedBy":"tags"}},"kind":"collectionType"},"modelName":"tag","actions":{},"lifecycles":{}},"api::visit.visit":{"kind":"collectionType","collectionName":"visits","info":{"singularName":"visit","pluralName":"visits","displayName":"Visit"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"open_count":{"type":"integer","default":0,"required":true},"last_opened_at":{"type":"datetime"},"total_gold_earned":{"type":"integer","default":0,"required":true},"total_exp_earned":{"type":"integer","default":0,"required":true},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"visits"},"poi":{"type":"relation","relation":"manyToOne","target":"api::poi.poi","inversedBy":"visits"},"items":{"type":"relation","relation":"manyToMany","target":"api::item.item","mappedBy":"visits"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::visit.visit","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"visits"}}},"apiName":"visit","globalId":"Visit","uid":"api::visit.visit","modelType":"contentType","__schema__":{"collectionName":"visits","info":{"singularName":"visit","pluralName":"visits","displayName":"Visit"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"open_count":{"type":"integer","default":0,"required":true},"last_opened_at":{"type":"datetime"},"total_gold_earned":{"type":"integer","default":0,"required":true},"total_exp_earned":{"type":"integer","default":0,"required":true},"guild":{"type":"relation","relation":"manyToOne","target":"api::guild.guild","inversedBy":"visits"},"poi":{"type":"relation","relation":"manyToOne","target":"api::poi.poi","inversedBy":"visits"},"items":{"type":"relation","relation":"manyToMany","target":"api::item.item","mappedBy":"visits"}},"kind":"collectionType"},"modelName":"visit","actions":{},"lifecycles":{}},"admin::permission":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_permissions"}}},"plugin":"admin","globalId":"AdminPermission","uid":"admin::permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"}},"kind":"collectionType"},"modelName":"permission"},"admin::user":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"registrationToken":{"hidden":true}}},"plugin":"admin","globalId":"AdminUser","uid":"admin::user","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false}},"kind":"collectionType"},"modelName":"user","options":{"draftAndPublish":false}},"admin::role":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_roles"}}},"plugin":"admin","globalId":"AdminRole","uid":"admin::role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"}},"kind":"collectionType"},"modelName":"role"},"admin::api-token":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_tokens"}}},"plugin":"admin","globalId":"AdminApiToken","uid":"admin::api-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"api-token"},"admin::api-token-permission":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_token_permissions"}}},"plugin":"admin","globalId":"AdminApiTokenPermission","uid":"admin::api-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"}},"kind":"collectionType"},"modelName":"api-token-permission"},"admin::transfer-token":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_tokens"}}},"plugin":"admin","globalId":"AdminTransferToken","uid":"admin::transfer-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"transfer-token"},"admin::transfer-token-permission":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_token_permissions"}}},"plugin":"admin","globalId":"AdminTransferTokenPermission","uid":"admin::transfer-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"}},"kind":"collectionType"},"modelName":"transfer-token-permission"},"admin::session":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::session","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_sessions"}}},"plugin":"admin","globalId":"AdminSession","uid":"admin::session","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"session"}}	object	\N	\N
11	plugin_content_manager_configuration_content_types::plugin::i18n.locale	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","createdAt"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}]]},"uid":"plugin::i18n.locale"}	object	\N	\N
13	plugin_content_manager_configuration_content_types::api::guild.guild	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"gold":{"edit":{"label":"gold","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"gold","searchable":true,"sortable":true}},"exp":{"edit":{"label":"exp","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"exp","searchable":true,"sortable":true}},"scrap":{"edit":{"label":"scrap","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"scrap","searchable":true,"sortable":true}},"user":{"edit":{"label":"user","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"user","searchable":true,"sortable":true}},"characters":{"edit":{"label":"characters","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"characters","searchable":false,"sortable":false}},"items":{"edit":{"label":"items","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"items","searchable":false,"sortable":false}},"visits":{"edit":{"label":"visits","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"visits","searchable":false,"sortable":false}},"runs":{"edit":{"label":"runs","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"runs","searchable":false,"sortable":false}},"friendships":{"edit":{"label":"friendships","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"friendships","searchable":false,"sortable":false}},"quests":{"edit":{"label":"quests","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"quests","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","gold","exp"],"edit":[[{"name":"name","size":6},{"name":"gold","size":4}],[{"name":"exp","size":4},{"name":"scrap","size":4}],[{"name":"user","size":6},{"name":"characters","size":6}],[{"name":"items","size":6},{"name":"visits","size":6}],[{"name":"runs","size":6},{"name":"friendships","size":6}],[{"name":"quests","size":6}]]},"uid":"api::guild.guild"}	object	\N	\N
18	plugin_content_manager_configuration_content_types::api::quest.quest	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"documentId","defaultSortBy":"documentId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"is_poi_a_completed":{"edit":{"label":"is_poi_a_completed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"is_poi_a_completed","searchable":true,"sortable":true}},"is_poi_b_completed":{"edit":{"label":"is_poi_b_completed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"is_poi_b_completed","searchable":true,"sortable":true}},"date_start":{"edit":{"label":"date_start","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"date_start","searchable":true,"sortable":true}},"date_end":{"edit":{"label":"date_end","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"date_end","searchable":true,"sortable":true}},"gold_earned":{"edit":{"label":"gold_earned","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"gold_earned","searchable":true,"sortable":true}},"xp_earned":{"edit":{"label":"xp_earned","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"xp_earned","searchable":true,"sortable":true}},"guild":{"edit":{"label":"guild","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"guild","searchable":true,"sortable":true}},"npc":{"edit":{"label":"npc","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"npc","searchable":true,"sortable":true}},"poi_a":{"edit":{"label":"poi_a","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"poi_a","searchable":true,"sortable":true}},"poi_b":{"edit":{"label":"poi_b","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"poi_b","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","is_poi_a_completed","is_poi_b_completed","date_start"],"edit":[[{"name":"is_poi_a_completed","size":4},{"name":"is_poi_b_completed","size":4}],[{"name":"date_start","size":6},{"name":"date_end","size":6}],[{"name":"gold_earned","size":4},{"name":"xp_earned","size":4}],[{"name":"guild","size":6},{"name":"npc","size":6}],[{"name":"poi_a","size":6},{"name":"poi_b","size":6}]]},"uid":"api::quest.quest"}	object	\N	\N
20	plugin_content_manager_configuration_content_types::api::run.run	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"documentId","defaultSortBy":"documentId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"dps":{"edit":{"label":"dps","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"dps","searchable":true,"sortable":true}},"date_start":{"edit":{"label":"date_start","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"date_start","searchable":true,"sortable":true}},"date_end":{"edit":{"label":"date_end","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"date_end","searchable":true,"sortable":true}},"gold_earned":{"edit":{"label":"gold_earned","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"gold_earned","searchable":true,"sortable":true}},"xp_earned":{"edit":{"label":"xp_earned","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"xp_earned","searchable":true,"sortable":true}},"threshold_reached":{"edit":{"label":"threshold_reached","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"threshold_reached","searchable":true,"sortable":true}},"target_threshold":{"edit":{"label":"target_threshold","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"target_threshold","searchable":true,"sortable":true}},"entry_unlocked":{"edit":{"label":"entry_unlocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"entry_unlocked","searchable":true,"sortable":true}},"guild":{"edit":{"label":"guild","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"guild","searchable":true,"sortable":true}},"museum":{"edit":{"label":"museum","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"museum","searchable":true,"sortable":true}},"npc":{"edit":{"label":"npc","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"npc","searchable":true,"sortable":true}},"items":{"edit":{"label":"items","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"items","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","dps","date_start","date_end"],"edit":[[{"name":"dps","size":4},{"name":"date_start","size":6}],[{"name":"date_end","size":6},{"name":"gold_earned","size":4}],[{"name":"xp_earned","size":4},{"name":"threshold_reached","size":4},{"name":"target_threshold","size":4}],[{"name":"entry_unlocked","size":4},{"name":"guild","size":6}],[{"name":"museum","size":6},{"name":"npc","size":6}],[{"name":"items","size":6}]]},"uid":"api::run.run"}	object	\N	\N
28	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"stages":{"edit":{"label":"stages","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stages","searchable":false,"sortable":false}},"stageRequiredToPublish":{"edit":{"label":"stageRequiredToPublish","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stageRequiredToPublish","searchable":true,"sortable":true}},"contentTypes":{"edit":{"label":"contentTypes","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentTypes","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","stages","stageRequiredToPublish"],"edit":[[{"name":"name","size":6},{"name":"stages","size":6}],[{"name":"stageRequiredToPublish","size":6}],[{"name":"contentTypes","size":12}]]},"uid":"plugin::review-workflows.workflow"}	object	\N	\N
15	plugin_content_manager_configuration_content_types::api::museum.museum	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"lat":{"edit":{"label":"lat","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lat","searchable":true,"sortable":true}},"lng":{"edit":{"label":"lng","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lng","searchable":true,"sortable":true}},"geohash":{"edit":{"label":"geohash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"geohash","searchable":true,"sortable":true}},"tags":{"edit":{"label":"tags","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"tags","searchable":false,"sortable":false}},"runs":{"edit":{"label":"runs","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"runs","searchable":false,"sortable":false}},"location":{"edit":{"label":"location","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"location","searchable":false,"sortable":false}},"radius":{"edit":{"label":"radius","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"radius","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","lat","lng"],"edit":[[{"name":"name","size":6},{"name":"lat","size":4}],[{"name":"lng","size":4},{"name":"geohash","size":6}],[{"name":"tags","size":6},{"name":"runs","size":6}],[{"name":"location","size":12}],[{"name":"radius","size":4}]]},"uid":"api::museum.museum"}	object	\N	\N
21	plugin_content_manager_configuration_content_types::api::tag.tag	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"items":{"edit":{"label":"items","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"items","searchable":false,"sortable":false}},"museums":{"edit":{"label":"museums","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"museums","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","items","museums"],"edit":[[{"name":"name","size":6},{"name":"items","size":6}],[{"name":"museums","size":6}]]},"uid":"api::tag.tag"}	object	\N	\N
27	plugin_content_manager_configuration_content_types::admin::session	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"userId","defaultSortBy":"userId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"userId":{"edit":{"label":"userId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"userId","searchable":true,"sortable":true}},"sessionId":{"edit":{"label":"sessionId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"sessionId","searchable":true,"sortable":true}},"childId":{"edit":{"label":"childId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"childId","searchable":true,"sortable":true}},"deviceId":{"edit":{"label":"deviceId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"deviceId","searchable":true,"sortable":true}},"origin":{"edit":{"label":"origin","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"origin","searchable":true,"sortable":true}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"absoluteExpiresAt":{"edit":{"label":"absoluteExpiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"absoluteExpiresAt","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","userId","sessionId","childId"],"edit":[[{"name":"userId","size":6},{"name":"sessionId","size":6}],[{"name":"childId","size":6},{"name":"deviceId","size":6}],[{"name":"origin","size":6},{"name":"expiresAt","size":6}],[{"name":"absoluteExpiresAt","size":6},{"name":"status","size":6}],[{"name":"type","size":6}]]},"uid":"admin::session"}	object	\N	\N
14	plugin_content_manager_configuration_content_types::api::item.item	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"level":{"edit":{"label":"level","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"level","searchable":true,"sortable":true}},"index_damage":{"edit":{"label":"index_damage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"index_damage","searchable":true,"sortable":true}},"slot":{"edit":{"label":"slot","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slot","searchable":true,"sortable":true}},"isScrapped":{"edit":{"label":"isScrapped","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isScrapped","searchable":true,"sortable":true}},"rarity":{"edit":{"label":"rarity","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"rarity","searchable":true,"sortable":true}},"guild":{"edit":{"label":"guild","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"guild","searchable":true,"sortable":true}},"character":{"edit":{"label":"character","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"character","searchable":true,"sortable":true}},"tags":{"edit":{"label":"tags","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"tags","searchable":false,"sortable":false}},"runs":{"edit":{"label":"runs","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"runs","searchable":false,"sortable":false}},"visits":{"edit":{"label":"visits","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"visits","searchable":false,"sortable":false}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","level","index_damage"],"edit":[[{"name":"name","size":6},{"name":"level","size":4}],[{"name":"index_damage","size":4},{"name":"slot","size":6}],[{"name":"isScrapped","size":4},{"name":"rarity","size":6}],[{"name":"guild","size":6},{"name":"character","size":6}],[{"name":"tags","size":6},{"name":"runs","size":6}],[{"name":"visits","size":6},{"name":"icon","size":6}]]},"uid":"api::item.item"}	object	\N	\N
16	plugin_content_manager_configuration_content_types::api::npc.npc	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastname","searchable":true,"sortable":true}},"pronouns":{"edit":{"label":"pronouns","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"pronouns","searchable":true,"sortable":true}},"quests_entry_available":{"edit":{"label":"quests_entry_available","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"quests_entry_available","searchable":true,"sortable":true}},"expedition_entry_available":{"edit":{"label":"expedition_entry_available","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expedition_entry_available","searchable":true,"sortable":true}},"friendships":{"edit":{"label":"friendships","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"friendships","searchable":false,"sortable":false}},"quests":{"edit":{"label":"quests","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"quests","searchable":false,"sortable":false}},"dialogs":{"edit":{"label":"dialogs","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"dialogs","searchable":false,"sortable":false}},"runs":{"edit":{"label":"runs","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"runs","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","pronouns"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"pronouns","size":6},{"name":"quests_entry_available","size":4}],[{"name":"expedition_entry_available","size":4},{"name":"friendships","size":6}],[{"name":"quests","size":6},{"name":"dialogs","size":6}],[{"name":"runs","size":6}]]},"uid":"api::npc.npc"}	object	\N	\N
24	plugin_content_manager_configuration_content_types::admin::transfer-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","accessKey"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"accessKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::transfer-token"}	object	\N	\N
17	plugin_content_manager_configuration_content_types::plugin::users-permissions.permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","role","createdAt"],"edit":[[{"name":"action","size":6},{"name":"role","size":6}]]},"uid":"plugin::users-permissions.permission"}	object	\N	\N
25	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow-stage	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"color":{"edit":{"label":"color","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"color","searchable":true,"sortable":true}},"workflow":{"edit":{"label":"workflow","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"workflow","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","color","workflow"],"edit":[[{"name":"name","size":6},{"name":"color","size":6}],[{"name":"workflow","size":6},{"name":"permissions","size":6}]]},"uid":"plugin::review-workflows.workflow-stage"}	object	\N	\N
19	plugin_content_manager_configuration_content_types::api::rarity.rarity	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"items":{"edit":{"label":"items","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"items","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","items","createdAt"],"edit":[[{"name":"name","size":6},{"name":"items","size":6}]]},"uid":"api::rarity.rarity"}	object	\N	\N
26	plugin_content_manager_configuration_content_types::admin::permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"actionParameters":{"edit":{"label":"actionParameters","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"actionParameters","searchable":false,"sortable":false}},"subject":{"edit":{"label":"subject","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"subject","searchable":true,"sortable":true}},"properties":{"edit":{"label":"properties","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"properties","searchable":false,"sortable":false}},"conditions":{"edit":{"label":"conditions","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"conditions","searchable":false,"sortable":false}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","subject","role"],"edit":[[{"name":"action","size":6}],[{"name":"actionParameters","size":12}],[{"name":"subject","size":6}],[{"name":"properties","size":12}],[{"name":"conditions","size":12}],[{"name":"role","size":6}]]},"uid":"admin::permission"}	object	\N	\N
22	plugin_content_manager_configuration_content_types::api::visit.visit	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"documentId","defaultSortBy":"documentId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"open_count":{"edit":{"label":"open_count","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"open_count","searchable":true,"sortable":true}},"last_opened_at":{"edit":{"label":"last_opened_at","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"last_opened_at","searchable":true,"sortable":true}},"total_gold_earned":{"edit":{"label":"total_gold_earned","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"total_gold_earned","searchable":true,"sortable":true}},"total_exp_earned":{"edit":{"label":"total_exp_earned","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"total_exp_earned","searchable":true,"sortable":true}},"guild":{"edit":{"label":"guild","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"guild","searchable":true,"sortable":true}},"poi":{"edit":{"label":"poi","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"poi","searchable":true,"sortable":true}},"items":{"edit":{"label":"items","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"items","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","open_count","last_opened_at","total_gold_earned"],"edit":[[{"name":"open_count","size":4},{"name":"last_opened_at","size":6}],[{"name":"total_gold_earned","size":4},{"name":"total_exp_earned","size":4}],[{"name":"guild","size":6},{"name":"poi","size":6}],[{"name":"items","size":6}]]},"uid":"api::visit.visit"}	object	\N	\N
41	core_admin_auth	{"providers":{"autoRegister":false,"defaultRole":null,"ssoLockedRoles":null}}	object	\N	\N
23	plugin_content_manager_configuration_content_types::admin::api-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::api-token-permission"}	object	\N	\N
29	plugin_content_manager_configuration_content_types::api::poi.poi	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"lat":{"edit":{"label":"lat","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lat","searchable":true,"sortable":true}},"lng":{"edit":{"label":"lng","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lng","searchable":true,"sortable":true}},"geohash":{"edit":{"label":"geohash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"geohash","searchable":true,"sortable":true}},"visits":{"edit":{"label":"visits","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"visits","searchable":false,"sortable":false}},"quests_a":{"edit":{"label":"quests_a","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"quests_a","searchable":false,"sortable":false}},"quests_b":{"edit":{"label":"quests_b","description":"","placeholder":"","visible":true,"editable":true,"mainField":"documentId"},"list":{"label":"quests_b","searchable":false,"sortable":false}},"location":{"edit":{"label":"location","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"location","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","lat","lng"],"edit":[[{"name":"name","size":6},{"name":"lat","size":4}],[{"name":"lng","size":4},{"name":"geohash","size":6}],[{"name":"visits","size":6},{"name":"quests_a","size":6}],[{"name":"quests_b","size":6}],[{"name":"location","size":12}]]},"uid":"api::poi.poi"}	object	\N	\N
31	plugin_content_manager_configuration_content_types::admin::role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"users","searchable":false,"sortable":false}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","description"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}],[{"name":"description","size":6},{"name":"users","size":6}],[{"name":"permissions","size":6}]]},"uid":"admin::role"}	object	\N	\N
32	plugin_content_manager_configuration_content_types::admin::user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastname","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"registrationToken":{"edit":{"label":"registrationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"registrationToken","searchable":true,"sortable":true}},"isActive":{"edit":{"label":"isActive","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isActive","searchable":true,"sortable":true}},"roles":{"edit":{"label":"roles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"roles","searchable":false,"sortable":false}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"preferedLanguage":{"edit":{"label":"preferedLanguage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"preferedLanguage","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","username"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"isActive","size":4}],[{"name":"roles","size":6},{"name":"blocked","size":4}],[{"name":"preferedLanguage","size":6}]]},"uid":"admin::user"}	object	\N	\N
33	plugin_content_manager_configuration_content_types::admin::transfer-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::transfer-token-permission"}	object	\N	\N
34	plugin_upload_settings	{"sizeOptimization":true,"responsiveDimensions":true,"autoOrientation":false,"aiMetadata":true}	object	\N	\N
35	plugin_upload_view_configuration	{"pageSize":10,"sort":"createdAt:DESC"}	object	\N	\N
37	plugin_i18n_default_locale	"en"	string	\N	\N
38	plugin_users-permissions_grant	{"email":{"icon":"envelope","enabled":true},"discord":{"icon":"discord","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/discord/callback","scope":["identify","email"]},"facebook":{"icon":"facebook-square","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/facebook/callback","scope":["email"]},"google":{"icon":"google","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/google/callback","scope":["email"]},"github":{"icon":"github","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/github/callback","scope":["user","user:email"]},"microsoft":{"icon":"windows","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/microsoft/callback","scope":["user.read"]},"twitter":{"icon":"twitter","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/twitter/callback"},"instagram":{"icon":"instagram","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/instagram/callback","scope":["user_profile"]},"vk":{"icon":"vk","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/vk/callback","scope":["email"]},"twitch":{"icon":"twitch","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/twitch/callback","scope":["user:read:email"]},"linkedin":{"icon":"linkedin","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/linkedin/callback","scope":["r_liteprofile","r_emailaddress"]},"cognito":{"icon":"aws","enabled":false,"key":"","secret":"","subdomain":"my.subdomain.com","callback":"api/auth/cognito/callback","scope":["email","openid","profile"]},"reddit":{"icon":"reddit","enabled":false,"key":"","secret":"","callback":"api/auth/reddit/callback","scope":["identity"]},"auth0":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"my-tenant.eu","callback":"api/auth/auth0/callback","scope":["openid","email","profile"]},"cas":{"icon":"book","enabled":false,"key":"","secret":"","callback":"api/auth/cas/callback","scope":["openid email"],"subdomain":"my.subdomain.com/cas"},"patreon":{"icon":"","enabled":false,"key":"","secret":"","callback":"api/auth/patreon/callback","scope":["identity","identity[email]"]},"keycloak":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"myKeycloakProvider.com/realms/myrealm","callback":"api/auth/keycloak/callback","scope":["openid","email","profile"]}}	object	\N	\N
39	plugin_users-permissions_email	{"reset_password":{"display":"Email.template.reset_password","icon":"sync","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\\n\\n<p>But don’t worry! You can use the following link to reset your password:</p>\\n<p><%= URL %>?code=<%= TOKEN %></p>\\n\\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\\n\\n<p>You have to confirm your email address. Please click on the link below.</p>\\n\\n<p><%= URL %>?confirmation=<%= CODE %></p>\\n\\n<p>Thanks.</p>"}}}	object	\N	\N
40	plugin_users-permissions_advanced	{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_reset_password":null,"email_confirmation_redirection":null,"default_role":"authenticated"}	object	\N	\N
36	plugin_upload_metrics	{"weeklySchedule":"59 27 15 * * 0","lastWeeklyUpdate":1766935679123}	object	\N	\N
7	plugin_content_manager_configuration_content_types::api::character.character	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastname","searchable":true,"sortable":true}},"guild":{"edit":{"label":"guild","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"guild","searchable":true,"sortable":true}},"items":{"edit":{"label":"items","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"items","searchable":false,"sortable":false}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","icon"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"guild","size":6}],[{"name":"items","size":6},{"name":"icon","size":6}]]},"uid":"api::character.character"}	object	\N	\N
\.


--
-- Data for Name: strapi_database_schema; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_database_schema (id, schema, "time", hash) FROM stdin;
2	{"tables":[{"name":"files","indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null},{"name":"files_documents_idx","columns":["document_id","locale","published_at"]},{"name":"files_created_by_id_fk","columns":["created_by_id"]},{"name":"files_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"files_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"files_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"alternative_text","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"caption","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"width","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"height","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"formats","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hash","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ext","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"mime","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"size","type":"decimal","args":[10,2],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"preview_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider_metadata","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"folder_path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"upload_folders","indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"},{"name":"upload_folders_documents_idx","columns":["document_id","locale","published_at"]},{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"]},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"i18n_locale","indexes":[{"name":"i18n_locale_documents_idx","columns":["document_id","locale","published_at"]},{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"]},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_releases","indexes":[{"name":"strapi_releases_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"released_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"scheduled_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"timezone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_release_actions","indexes":[{"name":"strapi_release_actions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"entry_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_entry_valid","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows","indexes":[{"name":"strapi_workflows_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_types","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_workflows_stages","indexes":[{"name":"strapi_workflows_stages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"color","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_permissions","indexes":[{"name":"up_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_roles","indexes":[{"name":"up_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_users","indexes":[{"name":"up_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_users_created_by_id_fk","columns":["created_by_id"]},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmation_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"age","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"characters","indexes":[{"name":"characters_documents_idx","columns":["document_id","locale","published_at"]},{"name":"characters_created_by_id_fk","columns":["created_by_id"]},{"name":"characters_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"characters_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"characters_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"firstname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lastname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"dialogs","indexes":[{"name":"dialogs_documents_idx","columns":["document_id","locale","published_at"]},{"name":"dialogs_created_by_id_fk","columns":["created_by_id"]},{"name":"dialogs_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"dialogs_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"dialogs_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"text_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"dialogues","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"friendships","indexes":[{"name":"friendships_documents_idx","columns":["document_id","locale","published_at"]},{"name":"friendships_created_by_id_fk","columns":["created_by_id"]},{"name":"friendships_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"friendships_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"friendships_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"quests_entry_unlocked","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expedition_entry_unlocked","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"guilds","indexes":[{"name":"guilds_documents_idx","columns":["document_id","locale","published_at"]},{"name":"guilds_created_by_id_fk","columns":["created_by_id"]},{"name":"guilds_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"guilds_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"guilds_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"gold","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"exp","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"scrap","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"items","indexes":[{"name":"items_documents_idx","columns":["document_id","locale","published_at"]},{"name":"items_created_by_id_fk","columns":["created_by_id"]},{"name":"items_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"items_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"items_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"level","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"index_damage","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slot","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_scrapped","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"museums","indexes":[{"name":"museums_documents_idx","columns":["document_id","locale","published_at"]},{"name":"museums_created_by_id_fk","columns":["created_by_id"]},{"name":"museums_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"museums_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"museums_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lat","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lng","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"geohash","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"location","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"radius","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"npcs","indexes":[{"name":"npcs_documents_idx","columns":["document_id","locale","published_at"]},{"name":"npcs_created_by_id_fk","columns":["created_by_id"]},{"name":"npcs_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"npcs_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"npcs_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"firstname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lastname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"pronouns","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"quests_entry_available","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expedition_entry_available","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"pois","indexes":[{"name":"pois_documents_idx","columns":["document_id","locale","published_at"]},{"name":"pois_created_by_id_fk","columns":["created_by_id"]},{"name":"pois_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"pois_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"pois_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lat","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lng","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"geohash","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"location","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"quests","indexes":[{"name":"quests_documents_idx","columns":["document_id","locale","published_at"]},{"name":"quests_created_by_id_fk","columns":["created_by_id"]},{"name":"quests_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"quests_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"quests_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_poi_a_completed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_poi_b_completed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"date_start","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"date_end","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"gold_earned","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"xp_earned","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"rarities","indexes":[{"name":"rarities_documents_idx","columns":["document_id","locale","published_at"]},{"name":"rarities_created_by_id_fk","columns":["created_by_id"]},{"name":"rarities_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"rarities_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"rarities_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"runs","indexes":[{"name":"runs_documents_idx","columns":["document_id","locale","published_at"]},{"name":"runs_created_by_id_fk","columns":["created_by_id"]},{"name":"runs_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"runs_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"runs_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"dps","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"date_start","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"date_end","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"gold_earned","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"xp_earned","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"threshold_reached","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"target_threshold","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"entry_unlocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"tags","indexes":[{"name":"tags_documents_idx","columns":["document_id","locale","published_at"]},{"name":"tags_created_by_id_fk","columns":["created_by_id"]},{"name":"tags_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"tags_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"tags_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"visits","indexes":[{"name":"visits_documents_idx","columns":["document_id","locale","published_at"]},{"name":"visits_created_by_id_fk","columns":["created_by_id"]},{"name":"visits_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"visits_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"visits_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"open_count","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_opened_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"total_gold_earned","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"total_exp_earned","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_permissions","indexes":[{"name":"admin_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action_parameters","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"subject","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"properties","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"conditions","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_users","indexes":[{"name":"admin_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_users_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"firstname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lastname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"registration_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_active","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"prefered_language","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_roles","indexes":[{"name":"admin_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_tokens","indexes":[{"name":"strapi_api_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"encrypted_key","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_token_permissions","indexes":[{"name":"strapi_api_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_tokens","indexes":[{"name":"strapi_transfer_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_token_permissions","indexes":[{"name":"strapi_transfer_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_sessions","indexes":[{"name":"strapi_sessions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"user_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"session_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"child_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"device_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"origin","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"absolute_expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_core_store_settings","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"environment","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"tag","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_webhooks","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"headers","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"events","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enabled","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_history_versions","indexes":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"]}],"foreignKeys":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"data","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"schema","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_ai_localization_jobs","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"source_locale","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"target_locales","type":"jsonb","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"files_related_mph","indexes":[{"name":"files_related_mph_fk","columns":["file_id"]},{"name":"files_related_mph_oidx","columns":["order"]},{"name":"files_related_mph_idix","columns":["related_id"]}],"foreignKeys":[{"name":"files_related_mph_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_folder_lnk","indexes":[{"name":"files_folder_lnk_fk","columns":["file_id"]},{"name":"files_folder_lnk_ifk","columns":["folder_id"]},{"name":"files_folder_lnk_uq","columns":["file_id","folder_id"],"type":"unique"},{"name":"files_folder_lnk_oifk","columns":["file_ord"]}],"foreignKeys":[{"name":"files_folder_lnk_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"},{"name":"files_folder_lnk_ifk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"file_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"upload_folders_parent_lnk","indexes":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"]},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"]},{"name":"upload_folders_parent_lnk_uq","columns":["folder_id","inv_folder_id"],"type":"unique"},{"name":"upload_folders_parent_lnk_oifk","columns":["folder_ord"]}],"foreignKeys":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_release_actions_release_lnk","indexes":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"]},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"]},{"name":"strapi_release_actions_release_lnk_uq","columns":["release_action_id","release_id"],"type":"unique"},{"name":"strapi_release_actions_release_lnk_oifk","columns":["release_action_ord"]}],"foreignKeys":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"],"referencedColumns":["id"],"referencedTable":"strapi_release_actions","onDelete":"CASCADE"},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"],"referencedColumns":["id"],"referencedTable":"strapi_releases","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"release_action_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_action_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stage_required_to_publish_lnk","indexes":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_uq","columns":["workflow_id","workflow_stage_id"],"type":"unique"}],"foreignKeys":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_workflow_lnk","indexes":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"]},{"name":"strapi_workflows_stages_workflow_lnk_uq","columns":["workflow_stage_id","workflow_id"],"type":"unique"},{"name":"strapi_workflows_stages_workflow_lnk_oifk","columns":["workflow_stage_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_permissions_lnk","indexes":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"]},{"name":"strapi_workflows_stages_permissions_lnk_uq","columns":["workflow_stage_id","permission_id"],"type":"unique"},{"name":"strapi_workflows_stages_permissions_lnk_ofk","columns":["permission_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_permissions_role_lnk","indexes":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"up_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"up_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"up_permissions","onDelete":"CASCADE"},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users_role_lnk","indexes":[{"name":"up_users_role_lnk_fk","columns":["user_id"]},{"name":"up_users_role_lnk_ifk","columns":["role_id"]},{"name":"up_users_role_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"up_users_role_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"up_users_role_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"},{"name":"up_users_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users_guild_lnk","indexes":[{"name":"up_users_guild_lnk_fk","columns":["user_id"]},{"name":"up_users_guild_lnk_ifk","columns":["guild_id"]},{"name":"up_users_guild_lnk_uq","columns":["user_id","guild_id"],"type":"unique"}],"foreignKeys":[{"name":"up_users_guild_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"},{"name":"up_users_guild_lnk_ifk","columns":["guild_id"],"referencedColumns":["id"],"referencedTable":"guilds","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"guild_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"characters_guild_lnk","indexes":[{"name":"characters_guild_lnk_fk","columns":["character_id"]},{"name":"characters_guild_lnk_ifk","columns":["guild_id"]},{"name":"characters_guild_lnk_uq","columns":["character_id","guild_id"],"type":"unique"},{"name":"characters_guild_lnk_oifk","columns":["character_ord"]}],"foreignKeys":[{"name":"characters_guild_lnk_fk","columns":["character_id"],"referencedColumns":["id"],"referencedTable":"characters","onDelete":"CASCADE"},{"name":"characters_guild_lnk_ifk","columns":["guild_id"],"referencedColumns":["id"],"referencedTable":"guilds","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"character_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"guild_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"character_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"dialogs_npc_lnk","indexes":[{"name":"dialogs_npc_lnk_fk","columns":["dialog_id"]},{"name":"dialogs_npc_lnk_ifk","columns":["npc_id"]},{"name":"dialogs_npc_lnk_uq","columns":["dialog_id","npc_id"],"type":"unique"},{"name":"dialogs_npc_lnk_oifk","columns":["dialog_ord"]}],"foreignKeys":[{"name":"dialogs_npc_lnk_fk","columns":["dialog_id"],"referencedColumns":["id"],"referencedTable":"dialogs","onDelete":"CASCADE"},{"name":"dialogs_npc_lnk_ifk","columns":["npc_id"],"referencedColumns":["id"],"referencedTable":"npcs","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"dialog_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"npc_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"dialog_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"friendships_npc_lnk","indexes":[{"name":"friendships_npc_lnk_fk","columns":["friendship_id"]},{"name":"friendships_npc_lnk_ifk","columns":["npc_id"]},{"name":"friendships_npc_lnk_uq","columns":["friendship_id","npc_id"],"type":"unique"},{"name":"friendships_npc_lnk_oifk","columns":["friendship_ord"]}],"foreignKeys":[{"name":"friendships_npc_lnk_fk","columns":["friendship_id"],"referencedColumns":["id"],"referencedTable":"friendships","onDelete":"CASCADE"},{"name":"friendships_npc_lnk_ifk","columns":["npc_id"],"referencedColumns":["id"],"referencedTable":"npcs","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"friendship_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"npc_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"friendship_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"friendships_guild_lnk","indexes":[{"name":"friendships_guild_lnk_fk","columns":["friendship_id"]},{"name":"friendships_guild_lnk_ifk","columns":["guild_id"]},{"name":"friendships_guild_lnk_uq","columns":["friendship_id","guild_id"],"type":"unique"},{"name":"friendships_guild_lnk_oifk","columns":["friendship_ord"]}],"foreignKeys":[{"name":"friendships_guild_lnk_fk","columns":["friendship_id"],"referencedColumns":["id"],"referencedTable":"friendships","onDelete":"CASCADE"},{"name":"friendships_guild_lnk_ifk","columns":["guild_id"],"referencedColumns":["id"],"referencedTable":"guilds","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"friendship_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"guild_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"friendship_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"guilds_user_lnk","indexes":[{"name":"guilds_user_lnk_fk","columns":["guild_id"]},{"name":"guilds_user_lnk_ifk","columns":["user_id"]},{"name":"guilds_user_lnk_uq","columns":["guild_id","user_id"],"type":"unique"}],"foreignKeys":[{"name":"guilds_user_lnk_fk","columns":["guild_id"],"referencedColumns":["id"],"referencedTable":"guilds","onDelete":"CASCADE"},{"name":"guilds_user_lnk_ifk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"guild_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"items_rarity_lnk","indexes":[{"name":"items_rarity_lnk_fk","columns":["item_id"]},{"name":"items_rarity_lnk_ifk","columns":["rarity_id"]},{"name":"items_rarity_lnk_uq","columns":["item_id","rarity_id"],"type":"unique"},{"name":"items_rarity_lnk_oifk","columns":["item_ord"]}],"foreignKeys":[{"name":"items_rarity_lnk_fk","columns":["item_id"],"referencedColumns":["id"],"referencedTable":"items","onDelete":"CASCADE"},{"name":"items_rarity_lnk_ifk","columns":["rarity_id"],"referencedColumns":["id"],"referencedTable":"rarities","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"item_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"rarity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"item_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"items_guild_lnk","indexes":[{"name":"items_guild_lnk_fk","columns":["item_id"]},{"name":"items_guild_lnk_ifk","columns":["guild_id"]},{"name":"items_guild_lnk_uq","columns":["item_id","guild_id"],"type":"unique"},{"name":"items_guild_lnk_oifk","columns":["item_ord"]}],"foreignKeys":[{"name":"items_guild_lnk_fk","columns":["item_id"],"referencedColumns":["id"],"referencedTable":"items","onDelete":"CASCADE"},{"name":"items_guild_lnk_ifk","columns":["guild_id"],"referencedColumns":["id"],"referencedTable":"guilds","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"item_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"guild_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"item_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"items_character_lnk","indexes":[{"name":"items_character_lnk_fk","columns":["item_id"]},{"name":"items_character_lnk_ifk","columns":["character_id"]},{"name":"items_character_lnk_uq","columns":["item_id","character_id"],"type":"unique"},{"name":"items_character_lnk_oifk","columns":["item_ord"]}],"foreignKeys":[{"name":"items_character_lnk_fk","columns":["item_id"],"referencedColumns":["id"],"referencedTable":"items","onDelete":"CASCADE"},{"name":"items_character_lnk_ifk","columns":["character_id"],"referencedColumns":["id"],"referencedTable":"characters","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"item_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"character_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"item_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"items_tags_lnk","indexes":[{"name":"items_tags_lnk_fk","columns":["item_id"]},{"name":"items_tags_lnk_ifk","columns":["tag_id"]},{"name":"items_tags_lnk_uq","columns":["item_id","tag_id"],"type":"unique"},{"name":"items_tags_lnk_ofk","columns":["tag_ord"]},{"name":"items_tags_lnk_oifk","columns":["item_ord"]}],"foreignKeys":[{"name":"items_tags_lnk_fk","columns":["item_id"],"referencedColumns":["id"],"referencedTable":"items","onDelete":"CASCADE"},{"name":"items_tags_lnk_ifk","columns":["tag_id"],"referencedColumns":["id"],"referencedTable":"tags","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"item_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"tag_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"tag_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"item_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"items_runs_lnk","indexes":[{"name":"items_runs_lnk_fk","columns":["item_id"]},{"name":"items_runs_lnk_ifk","columns":["run_id"]},{"name":"items_runs_lnk_uq","columns":["item_id","run_id"],"type":"unique"},{"name":"items_runs_lnk_ofk","columns":["run_ord"]},{"name":"items_runs_lnk_oifk","columns":["item_ord"]}],"foreignKeys":[{"name":"items_runs_lnk_fk","columns":["item_id"],"referencedColumns":["id"],"referencedTable":"items","onDelete":"CASCADE"},{"name":"items_runs_lnk_ifk","columns":["run_id"],"referencedColumns":["id"],"referencedTable":"runs","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"item_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"run_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"run_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"item_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"items_visits_lnk","indexes":[{"name":"items_visits_lnk_fk","columns":["item_id"]},{"name":"items_visits_lnk_ifk","columns":["visit_id"]},{"name":"items_visits_lnk_uq","columns":["item_id","visit_id"],"type":"unique"},{"name":"items_visits_lnk_ofk","columns":["visit_ord"]},{"name":"items_visits_lnk_oifk","columns":["item_ord"]}],"foreignKeys":[{"name":"items_visits_lnk_fk","columns":["item_id"],"referencedColumns":["id"],"referencedTable":"items","onDelete":"CASCADE"},{"name":"items_visits_lnk_ifk","columns":["visit_id"],"referencedColumns":["id"],"referencedTable":"visits","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"item_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"visit_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"visit_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"item_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"museums_tags_lnk","indexes":[{"name":"museums_tags_lnk_fk","columns":["museum_id"]},{"name":"museums_tags_lnk_ifk","columns":["tag_id"]},{"name":"museums_tags_lnk_uq","columns":["museum_id","tag_id"],"type":"unique"},{"name":"museums_tags_lnk_ofk","columns":["tag_ord"]},{"name":"museums_tags_lnk_oifk","columns":["museum_ord"]}],"foreignKeys":[{"name":"museums_tags_lnk_fk","columns":["museum_id"],"referencedColumns":["id"],"referencedTable":"museums","onDelete":"CASCADE"},{"name":"museums_tags_lnk_ifk","columns":["tag_id"],"referencedColumns":["id"],"referencedTable":"tags","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"museum_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"tag_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"tag_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"museum_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"quests_guild_lnk","indexes":[{"name":"quests_guild_lnk_fk","columns":["quest_id"]},{"name":"quests_guild_lnk_ifk","columns":["guild_id"]},{"name":"quests_guild_lnk_uq","columns":["quest_id","guild_id"],"type":"unique"},{"name":"quests_guild_lnk_oifk","columns":["quest_ord"]}],"foreignKeys":[{"name":"quests_guild_lnk_fk","columns":["quest_id"],"referencedColumns":["id"],"referencedTable":"quests","onDelete":"CASCADE"},{"name":"quests_guild_lnk_ifk","columns":["guild_id"],"referencedColumns":["id"],"referencedTable":"guilds","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"quest_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"guild_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"quest_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"quests_npc_lnk","indexes":[{"name":"quests_npc_lnk_fk","columns":["quest_id"]},{"name":"quests_npc_lnk_ifk","columns":["npc_id"]},{"name":"quests_npc_lnk_uq","columns":["quest_id","npc_id"],"type":"unique"},{"name":"quests_npc_lnk_oifk","columns":["quest_ord"]}],"foreignKeys":[{"name":"quests_npc_lnk_fk","columns":["quest_id"],"referencedColumns":["id"],"referencedTable":"quests","onDelete":"CASCADE"},{"name":"quests_npc_lnk_ifk","columns":["npc_id"],"referencedColumns":["id"],"referencedTable":"npcs","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"quest_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"npc_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"quest_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"quests_poi_a_lnk","indexes":[{"name":"quests_poi_a_lnk_fk","columns":["quest_id"]},{"name":"quests_poi_a_lnk_ifk","columns":["poi_id"]},{"name":"quests_poi_a_lnk_uq","columns":["quest_id","poi_id"],"type":"unique"},{"name":"quests_poi_a_lnk_oifk","columns":["quest_ord"]}],"foreignKeys":[{"name":"quests_poi_a_lnk_fk","columns":["quest_id"],"referencedColumns":["id"],"referencedTable":"quests","onDelete":"CASCADE"},{"name":"quests_poi_a_lnk_ifk","columns":["poi_id"],"referencedColumns":["id"],"referencedTable":"pois","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"quest_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"poi_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"quest_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"quests_poi_b_lnk","indexes":[{"name":"quests_poi_b_lnk_fk","columns":["quest_id"]},{"name":"quests_poi_b_lnk_ifk","columns":["poi_id"]},{"name":"quests_poi_b_lnk_uq","columns":["quest_id","poi_id"],"type":"unique"},{"name":"quests_poi_b_lnk_oifk","columns":["quest_ord"]}],"foreignKeys":[{"name":"quests_poi_b_lnk_fk","columns":["quest_id"],"referencedColumns":["id"],"referencedTable":"quests","onDelete":"CASCADE"},{"name":"quests_poi_b_lnk_ifk","columns":["poi_id"],"referencedColumns":["id"],"referencedTable":"pois","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"quest_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"poi_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"quest_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"runs_guild_lnk","indexes":[{"name":"runs_guild_lnk_fk","columns":["run_id"]},{"name":"runs_guild_lnk_ifk","columns":["guild_id"]},{"name":"runs_guild_lnk_uq","columns":["run_id","guild_id"],"type":"unique"},{"name":"runs_guild_lnk_oifk","columns":["run_ord"]}],"foreignKeys":[{"name":"runs_guild_lnk_fk","columns":["run_id"],"referencedColumns":["id"],"referencedTable":"runs","onDelete":"CASCADE"},{"name":"runs_guild_lnk_ifk","columns":["guild_id"],"referencedColumns":["id"],"referencedTable":"guilds","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"run_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"guild_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"run_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"runs_museum_lnk","indexes":[{"name":"runs_museum_lnk_fk","columns":["run_id"]},{"name":"runs_museum_lnk_ifk","columns":["museum_id"]},{"name":"runs_museum_lnk_uq","columns":["run_id","museum_id"],"type":"unique"},{"name":"runs_museum_lnk_oifk","columns":["run_ord"]}],"foreignKeys":[{"name":"runs_museum_lnk_fk","columns":["run_id"],"referencedColumns":["id"],"referencedTable":"runs","onDelete":"CASCADE"},{"name":"runs_museum_lnk_ifk","columns":["museum_id"],"referencedColumns":["id"],"referencedTable":"museums","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"run_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"museum_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"run_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"runs_npc_lnk","indexes":[{"name":"runs_npc_lnk_fk","columns":["run_id"]},{"name":"runs_npc_lnk_ifk","columns":["npc_id"]},{"name":"runs_npc_lnk_uq","columns":["run_id","npc_id"],"type":"unique"},{"name":"runs_npc_lnk_oifk","columns":["run_ord"]}],"foreignKeys":[{"name":"runs_npc_lnk_fk","columns":["run_id"],"referencedColumns":["id"],"referencedTable":"runs","onDelete":"CASCADE"},{"name":"runs_npc_lnk_ifk","columns":["npc_id"],"referencedColumns":["id"],"referencedTable":"npcs","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"run_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"npc_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"run_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"visits_guild_lnk","indexes":[{"name":"visits_guild_lnk_fk","columns":["visit_id"]},{"name":"visits_guild_lnk_ifk","columns":["guild_id"]},{"name":"visits_guild_lnk_uq","columns":["visit_id","guild_id"],"type":"unique"},{"name":"visits_guild_lnk_oifk","columns":["visit_ord"]}],"foreignKeys":[{"name":"visits_guild_lnk_fk","columns":["visit_id"],"referencedColumns":["id"],"referencedTable":"visits","onDelete":"CASCADE"},{"name":"visits_guild_lnk_ifk","columns":["guild_id"],"referencedColumns":["id"],"referencedTable":"guilds","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"visit_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"guild_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"visit_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"visits_poi_lnk","indexes":[{"name":"visits_poi_lnk_fk","columns":["visit_id"]},{"name":"visits_poi_lnk_ifk","columns":["poi_id"]},{"name":"visits_poi_lnk_uq","columns":["visit_id","poi_id"],"type":"unique"},{"name":"visits_poi_lnk_oifk","columns":["visit_ord"]}],"foreignKeys":[{"name":"visits_poi_lnk_fk","columns":["visit_id"],"referencedColumns":["id"],"referencedTable":"visits","onDelete":"CASCADE"},{"name":"visits_poi_lnk_ifk","columns":["poi_id"],"referencedColumns":["id"],"referencedTable":"pois","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"visit_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"poi_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"visit_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_permissions_role_lnk","indexes":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"admin_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"admin_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_users_roles_lnk","indexes":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"]},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"]},{"name":"admin_users_roles_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"admin_users_roles_lnk_ofk","columns":["role_ord"]},{"name":"admin_users_roles_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"admin_users","onDelete":"CASCADE"},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_token_permissions_token_lnk","indexes":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"]},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"]},{"name":"strapi_api_token_permissions_token_lnk_uq","columns":["api_token_permission_id","api_token_id"],"type":"unique"},{"name":"strapi_api_token_permissions_token_lnk_oifk","columns":["api_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_token_permissions","onDelete":"CASCADE"},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"api_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_transfer_token_permissions_token_lnk","indexes":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_uq","columns":["transfer_token_permission_id","transfer_token_id"],"type":"unique"},{"name":"strapi_transfer_token_permissions_token_lnk_oifk","columns":["transfer_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_token_permissions","onDelete":"CASCADE"},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"transfer_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]}]}	2025-12-18 13:19:41.384	878c8f6673b598e6d46bc07cdc62da957742c65a9f93e6ea80ebdfa8d0eb135f
\.


--
-- Data for Name: strapi_history_versions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_history_versions (id, content_type, related_document_id, locale, status, data, schema, created_at, created_by_id) FROM stdin;
\.


--
-- Data for Name: strapi_migrations; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_migrations (id, name, "time") FROM stdin;
\.


--
-- Data for Name: strapi_migrations_internal; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_migrations_internal (id, name, "time") FROM stdin;
1	5.0.0-rename-identifiers-longer-than-max-length	2025-12-15 15:30:03.073
2	5.0.0-02-created-document-id	2025-12-15 15:30:03.356
3	5.0.0-03-created-locale	2025-12-15 15:30:03.643
4	5.0.0-04-created-published-at	2025-12-15 15:30:03.908
5	5.0.0-05-drop-slug-fields-index	2025-12-15 15:30:04.162
6	core::5.0.0-discard-drafts	2025-12-15 15:30:04.436
\.


--
-- Data for Name: strapi_release_actions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_release_actions (id, document_id, type, content_type, entry_document_id, locale, is_entry_valid, created_at, updated_at, published_at, created_by_id, updated_by_id) FROM stdin;
\.


--
-- Data for Name: strapi_release_actions_release_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_release_actions_release_lnk (id, release_action_id, release_id, release_action_ord) FROM stdin;
\.


--
-- Data for Name: strapi_releases; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_releases (id, document_id, name, released_at, scheduled_at, timezone, status, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_sessions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_sessions (id, document_id, user_id, session_id, child_id, device_id, origin, expires_at, absolute_expires_at, status, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	b8mintz41inm9uhevmyu5nzv	1	625bb616189347c74912ec2e36a7483b	\N	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-15 17:38:33.083	2026-01-14 15:38:33.083	active	session	2025-12-15 15:38:33.083	2025-12-15 15:38:33.083	2025-12-15 15:38:33.086	\N	\N	\N
2	oic89f8bw9rw32co6rdlce87	1	7ab824b20544cd1d754fbbfe54c1512f	\N	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-15 21:58:53.506	2026-01-14 19:58:53.506	active	session	2025-12-15 19:58:53.506	2025-12-15 19:58:53.506	2025-12-15 19:58:53.508	\N	\N	\N
3	ivjz0tlo94o7xlbgkjdbbdmc	1	4300f5232bb2668d36d495c032ad5da5	52f3e194d2347f91b9812b951b010575	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-16 09:53:51.894	2026-01-15 07:53:51.894	rotated	session	2025-12-16 07:53:51.894	2025-12-16 08:27:47.948	2025-12-16 07:53:51.895	\N	\N	\N
5	uzl8s2uhj5ke9ntus1cf2c5a	1	322bbd46c85073c0b22e0553363a13fd	\N	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-16 12:13:56.656	2026-01-15 07:53:51.894	active	session	2025-12-16 10:13:56.656	2025-12-16 10:13:56.656	2025-12-16 10:13:56.657	\N	\N	\N
4	wwg4s83bk5tngmua5wpw323s	1	52f3e194d2347f91b9812b951b010575	322bbd46c85073c0b22e0553363a13fd	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-16 10:27:47.935	2026-01-15 07:53:51.894	rotated	session	2025-12-16 08:27:47.938	2025-12-16 10:13:56.664	2025-12-16 08:27:47.939	\N	\N	\N
7	jzs529xis0b7s89objawvhr9	1	de0a515e3e1c47ae1023361fdda5ba59	\N	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-30 14:33:49.651	2026-01-15 14:02:33.484	active	refresh	2025-12-16 14:33:49.652	2025-12-16 14:33:49.652	2025-12-16 14:33:49.654	\N	\N	\N
6	l2b56g9b84umtneh511cqadw	1	f62334f7082d994cfe8f4d79ee5f1ab1	de0a515e3e1c47ae1023361fdda5ba59	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-30 14:02:33.484	2026-01-15 14:02:33.484	rotated	refresh	2025-12-16 14:02:33.484	2025-12-16 14:33:49.66	2025-12-16 14:02:33.486	\N	\N	\N
8	dqo2gm17epggmbpfpvv3wo84	1	99a40c644a0338a4d254efe8c89b51ef	\N	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-30 19:19:51.784	2026-01-15 19:19:51.784	active	refresh	2025-12-16 19:19:51.785	2025-12-16 19:19:51.785	2025-12-16 19:19:51.79	\N	\N	\N
9	yzyirwse8at7s5wkmsgnqoo2	1	03caadce9a814457a5f4d97a793be0dd	4b111d28f28faec49cbf7233d0e1450c	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-31 09:25:14	2026-01-16 09:25:14	rotated	refresh	2025-12-17 09:25:14	2025-12-17 10:02:35.123	2025-12-17 09:25:14.001	\N	\N	\N
10	tdg1lhcctsopupv9z5oiyjwg	1	4b111d28f28faec49cbf7233d0e1450c	67a5656231883219a1f3e02bea90bccd	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2025-12-31 10:02:35.11	2026-01-16 09:25:14	rotated	refresh	2025-12-17 10:02:35.111	2025-12-18 08:16:23.013	2025-12-17 10:02:35.112	\N	\N	\N
11	v0lbghhvi4xa75kw31rvc7gq	1	67a5656231883219a1f3e02bea90bccd	363190e861b11edd14f2ecd86d00e608	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2026-01-01 08:16:22.986	2026-01-16 09:25:14	rotated	refresh	2025-12-18 08:16:22.987	2025-12-18 09:22:52.036	2025-12-18 08:16:22.991	\N	\N	\N
12	aud4o0zgj24z2or1o5n4167k	1	363190e861b11edd14f2ecd86d00e608	6b10c2800ea8193f669926b033a1de0d	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2026-01-01 09:22:52.023	2026-01-16 09:25:14	rotated	refresh	2025-12-18 09:22:52.024	2025-12-18 09:54:15.973	2025-12-18 09:22:52.026	\N	\N	\N
13	awqy8osq3a4lzifegctxvmmg	1	6b10c2800ea8193f669926b033a1de0d	469db691fa71b522ebccb22dc86bb896	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2026-01-01 09:54:15.953	2026-01-16 09:25:14	rotated	refresh	2025-12-18 09:54:15.954	2025-12-18 11:02:30.079	2025-12-18 09:54:15.957	\N	\N	\N
14	uskbpzayq1ajv2utgkiecxro	1	469db691fa71b522ebccb22dc86bb896	8534024ccb33a47432690e5df393512f	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2026-01-01 11:02:30.062	2026-01-16 09:25:14	rotated	refresh	2025-12-18 11:02:30.063	2025-12-18 13:15:07.34	2025-12-18 11:02:30.066	\N	\N	\N
15	faqtgh40uha4pgm3eubea07j	1	8534024ccb33a47432690e5df393512f	d66eb9a4b373d761973b6fe1d34edc2d	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2026-01-01 13:15:07.324	2026-01-16 09:25:14	rotated	refresh	2025-12-18 13:15:07.325	2025-12-18 13:55:40.669	2025-12-18 13:15:07.328	\N	\N	\N
16	tzz3y075l779po282v7c3rms	1	d66eb9a4b373d761973b6fe1d34edc2d	fb72c5eb2361c6db5721aa0d6f37cd84	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2026-01-01 13:55:40.657	2026-01-16 09:25:14	rotated	refresh	2025-12-18 13:55:40.657	2025-12-18 14:55:23.219	2025-12-18 13:55:40.658	\N	\N	\N
18	lvpfb10s5fduou9qzleza1ad	1	572b5d618b9c6ba59009bd7e1baf01f3	\N	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2026-01-01 15:33:49.816	2026-01-16 09:25:14	active	refresh	2025-12-18 15:33:49.818	2025-12-18 15:33:49.818	2025-12-18 15:33:49.83	\N	\N	\N
17	z0scp3b2hqzl0lxq5f8fcose	1	fb72c5eb2361c6db5721aa0d6f37cd84	572b5d618b9c6ba59009bd7e1baf01f3	9a290ed8-db9e-4230-87ff-7dfc5baefb1a	admin	2026-01-01 14:55:23.194	2026-01-16 09:25:14	rotated	refresh	2025-12-18 14:55:23.195	2025-12-18 15:33:49.847	2025-12-18 14:55:23.197	\N	\N	\N
19	i3lngq6bhbbr0benqtge1aa2	1	115d849fe2fc29ddfeff1d83535f1dd8	982b02ab284f041953c713724940b9f7	fcd2b4b5-454a-4fef-bcbb-7e2f37512779	admin	2026-01-11 16:08:05.406	2026-01-27 16:08:05.406	rotated	refresh	2025-12-28 16:08:05.406	2025-12-29 01:11:10.341	2025-12-28 16:08:05.406	\N	\N	\N
21	vdhadonndytqzsgxk4mleulk	1	f6c01af19d4ff6ae5d58fa3f42c0a5e1	\N	fcd2b4b5-454a-4fef-bcbb-7e2f37512779	admin	2026-01-17 14:53:41.398	2026-01-27 16:08:05.406	active	refresh	2026-01-03 14:53:41.399	2026-01-03 14:53:41.399	2026-01-03 14:53:41.401	\N	\N	\N
20	axgylsoxgxw7z84u7hi0yjtl	1	982b02ab284f041953c713724940b9f7	f6c01af19d4ff6ae5d58fa3f42c0a5e1	fcd2b4b5-454a-4fef-bcbb-7e2f37512779	admin	2026-01-12 01:11:10.064	2026-01-27 16:08:05.406	rotated	refresh	2025-12-29 01:11:10.077	2026-01-03 14:53:41.417	2025-12-29 01:11:10.104	\N	\N	\N
\.


--
-- Data for Name: strapi_transfer_token_permissions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_transfer_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_transfer_token_permissions_token_lnk (id, transfer_token_permission_id, transfer_token_id, transfer_token_permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_transfer_tokens; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_transfer_tokens (id, document_id, name, description, access_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_webhooks; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_webhooks (id, name, url, headers, events, enabled) FROM stdin;
\.


--
-- Data for Name: strapi_workflows; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows (id, document_id, name, content_types, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows_stage_required_to_publish_lnk (id, workflow_id, workflow_stage_id) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows_stages (id, document_id, name, color, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages_permissions_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows_stages_permissions_lnk (id, workflow_stage_id, permission_id, permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages_workflow_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.strapi_workflows_stages_workflow_lnk (id, workflow_stage_id, workflow_id, workflow_stage_ord) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.tags (id, document_id, name, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
3	a9gwgdr4mzvkedxl857iuze3	Art	2025-12-15 15:33:28.743	2025-12-15 15:33:28.743	\N	\N	\N	\N
4	a9gwgdr4mzvkedxl857iuze3	Art	2025-12-15 15:33:28.743	2025-12-15 15:33:28.743	2025-12-15 15:33:28.768	\N	\N	\N
7	hhaw5wzs6i23kw1oljn879zz	Nature	2025-12-15 15:33:28.858	2025-12-15 15:33:28.858	\N	\N	\N	\N
8	hhaw5wzs6i23kw1oljn879zz	Nature	2025-12-15 15:33:28.858	2025-12-15 15:33:28.858	2025-12-15 15:33:28.872	\N	\N	\N
1	nsilz4z7s0oia8zedioq1m7q	History	2025-12-15 15:33:28.678	2025-12-18 14:09:56.781	\N	\N	1	\N
21	nsilz4z7s0oia8zedioq1m7q	History	2025-12-15 15:33:28.678	2025-12-18 14:09:56.781	2025-12-18 14:09:56.801	\N	1	\N
13	jg5havt8lrbpjzql60jww3qu	Make	2025-12-15 15:41:12.489	2025-12-18 14:11:36.392	\N	\N	1	\N
23	jg5havt8lrbpjzql60jww3qu	Make	2025-12-15 15:41:12.489	2025-12-18 14:11:36.392	2025-12-18 14:11:36.407	\N	1	\N
5	ig3qmylzplgwo478yfy0nc3y	Science	2025-12-15 15:33:28.808	2025-12-18 14:11:43.174	\N	\N	1	\N
24	ig3qmylzplgwo478yfy0nc3y	Science	2025-12-15 15:33:28.808	2025-12-18 14:11:43.174	2025-12-18 14:11:43.191	\N	1	\N
9	iazsuzhsweea3adnakubq8ht	Society	2025-12-15 15:33:28.907	2025-12-18 14:11:51.566	\N	\N	1	\N
25	iazsuzhsweea3adnakubq8ht	Society	2025-12-15 15:33:28.907	2025-12-18 14:11:51.566	2025-12-18 14:11:51.583	\N	1	\N
26	llbblqkhhwj8fu65gpz09r60	Histoire	2025-12-18 14:47:27.393	2025-12-18 14:47:27.393	\N	\N	\N	\N
27	llbblqkhhwj8fu65gpz09r60	Histoire	2025-12-18 14:47:27.393	2025-12-18 14:47:27.393	2025-12-18 14:47:27.407	\N	\N	\N
28	zgwwhe4d3jin2aw4muzog06z	Sciences	2025-12-18 14:47:27.427	2025-12-18 14:47:27.427	\N	\N	\N	\N
29	zgwwhe4d3jin2aw4muzog06z	Sciences	2025-12-18 14:47:27.427	2025-12-18 14:47:27.427	2025-12-18 14:47:27.439	\N	\N	\N
30	opn3ndhxzrivxx6xcg3hot6b	Société	2025-12-18 14:47:27.456	2025-12-18 14:47:27.456	\N	\N	\N	\N
31	opn3ndhxzrivxx6xcg3hot6b	Société	2025-12-18 14:47:27.456	2025-12-18 14:47:27.456	2025-12-18 14:47:27.463	\N	\N	\N
32	o894qmvruqc4bcrgii923do5	Savoir-Faire	2025-12-18 14:47:27.476	2025-12-18 14:47:27.476	\N	\N	\N	\N
33	o894qmvruqc4bcrgii923do5	Savoir-Faire	2025-12-18 14:47:27.476	2025-12-18 14:47:27.476	2025-12-18 14:47:27.483	\N	\N	\N
\.


--
-- Data for Name: up_permissions; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	k7q6zpq36se6xfn9wepp91k7	plugin::users-permissions.user.me	2025-12-15 15:33:23.916	2025-12-15 15:33:23.916	2025-12-15 15:33:23.917	\N	\N	\N
2	jz2d90rrwc5zorcumpia6h6x	plugin::users-permissions.auth.changePassword	2025-12-15 15:33:23.916	2025-12-15 15:33:23.916	2025-12-15 15:33:23.918	\N	\N	\N
3	vfdwwy1wk9enebx98wshcahu	plugin::users-permissions.auth.callback	2025-12-15 15:33:23.993	2025-12-15 15:33:23.993	2025-12-15 15:33:23.994	\N	\N	\N
4	gum2bkuy7dgziumtpw7a7m2v	plugin::users-permissions.auth.connect	2025-12-15 15:33:23.993	2025-12-15 15:33:23.993	2025-12-15 15:33:23.995	\N	\N	\N
5	q1u4u0q5nydjjysawb9sxi2b	plugin::users-permissions.auth.forgotPassword	2025-12-15 15:33:23.993	2025-12-15 15:33:23.993	2025-12-15 15:33:23.997	\N	\N	\N
6	ju0ht0ix9fejxlbipabgb1cs	plugin::users-permissions.auth.resetPassword	2025-12-15 15:33:23.993	2025-12-15 15:33:23.993	2025-12-15 15:33:23.998	\N	\N	\N
8	ynm5iyjvdj6stjg8euj9309v	plugin::users-permissions.auth.emailConfirmation	2025-12-15 15:33:23.993	2025-12-15 15:33:23.993	2025-12-15 15:33:24	\N	\N	\N
7	d42fmv6chf23st6jpqxxm521	plugin::users-permissions.auth.register	2025-12-15 15:33:23.993	2025-12-15 15:33:23.993	2025-12-15 15:33:23.999	\N	\N	\N
9	vsaifq5eo9sdm6edc0712u0h	plugin::users-permissions.auth.sendEmailConfirmation	2025-12-15 15:33:23.993	2025-12-15 15:33:23.993	2025-12-15 15:33:24.002	\N	\N	\N
11	d4w78z4owrp2boi50xsa0ojr	api::guild.guild.find	2025-12-18 08:22:44.295	2025-12-18 08:22:44.295	2025-12-18 08:22:44.296	\N	\N	\N
12	poipp6r9q0wbfeemj188sqss	api::dialog.dialog.find	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.531	\N	\N	\N
13	uw6qn4nt18w1wcsa4gqq1uql	api::dialog.dialog.findOne	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.532	\N	\N	\N
14	jk4nbscd96j1cbfupf6ir4jl	api::museum.museum.find	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.532	\N	\N	\N
15	n9qti6ijg4mwqazva3qx3x1z	api::museum.museum.findOne	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.533	\N	\N	\N
16	jreutm1bgmaurg9ur35lqq57	api::npc.npc.find	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.533	\N	\N	\N
17	t7p7heepsrhc8c5biqfv12jd	api::poi.poi.findOne	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.535	\N	\N	\N
21	ma3svofgu0lr2l692o15m54o	api::tag.tag.find	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.536	\N	\N	\N
20	gl2znq5bqjw4b69xagtrjnti	api::poi.poi.find	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.534	\N	\N	\N
19	k7ns4b8hn7vlpg51lijs5avg	api::rarity.rarity.find	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.535	\N	\N	\N
18	yioqipaj3nz8mddxrc5fo2m1	api::npc.npc.findOne	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.534	\N	\N	\N
22	nbxs06fnfvv88maryquu1uh9	api::rarity.rarity.findOne	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.535	\N	\N	\N
23	nmv1zgk0u7t1fbfktess602a	api::tag.tag.findOne	2025-12-18 11:03:47.53	2025-12-18 11:03:47.53	2025-12-18 11:03:47.536	\N	\N	\N
24	qxqy92rrm8sf9n4kihisfffl	api::character.character.find	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.292	\N	\N	\N
25	sgdcdsspyvt0yxv736ghi7c7	api::character.character.findOne	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.293	\N	\N	\N
26	azccw1fua580s3yew44r1pbx	api::friendship.friendship.find	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.295	\N	\N	\N
27	psy9p8zwwxdgzkoerlv4487c	api::friendship.friendship.findOne	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.295	\N	\N	\N
28	rz6b7ml0m02e464rfzinlyrt	api::guild.guild.findOne	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.296	\N	\N	\N
29	wky70wqhsroy0948des0hol2	api::item.item.find	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.296	\N	\N	\N
30	p1o9umxo9xe7ihxbnmw8yv62	api::item.item.findOne	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.296	\N	\N	\N
31	bc27oux01bfn0x8ftt95yw0n	api::quest.quest.find	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.296	\N	\N	\N
32	a243a5317k1b56tlvpo15p7e	api::quest.quest.findOne	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.297	\N	\N	\N
33	y7th2k9lqnccxq0stfn5v1zd	api::run.run.find	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.297	\N	\N	\N
34	el8xl7j9nur8a8c3yyb7ljuy	api::run.run.findOne	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.298	\N	\N	\N
35	kreb7u9wmbeta3t0y7ux2puj	api::visit.visit.find	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.299	\N	\N	\N
36	seswqittv6qmyyckcd1u279f	api::visit.visit.findOne	2025-12-18 11:09:30.291	2025-12-18 11:09:30.291	2025-12-18 11:09:30.299	\N	\N	\N
38	ffgksioao09v7dylrkqd21mo	api::character.character.update	2025-12-18 14:55:52.421	2025-12-18 14:55:52.421	2025-12-18 14:55:52.422	\N	\N	\N
39	fovwkwcrww0oih4pxw75zw9n	plugin::upload.content-api.find	2025-12-18 15:00:06.456	2025-12-18 15:00:06.456	2025-12-18 15:00:06.457	\N	\N	\N
40	uns413v1rzjpkj1uqso0dgp8	api::character.character.create	2025-12-18 15:34:02.962	2025-12-18 15:34:02.962	2025-12-18 15:34:02.963	\N	\N	\N
42	gjk074pur49a8ksnlekz05f5	api::character.character.getCharacterIcons	2025-12-18 15:51:12.243	2025-12-18 15:51:12.243	2025-12-18 15:51:12.244	\N	\N	\N
48	sy7arjf8rlw6kpvj4pmhjkz4	api::guild.guild.setup	2025-12-28 20:59:28.529	2025-12-28 20:59:28.529	2025-12-28 20:59:28.53	\N	\N	\N
49	ng5kv4gx6sxoc0elz12667j5	api::item.item.getItemIcons	2025-12-28 20:59:28.563	2025-12-28 20:59:28.563	2025-12-28 20:59:28.563	\N	\N	\N
\.


--
-- Data for Name: up_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	1	1
2	2	1	1
3	4	2	1
4	3	2	1
5	5	2	1
6	9	2	1
7	8	2	1
8	6	2	2
9	7	2	2
11	11	1	3
12	13	1	4
13	18	1	4
14	21	1	4
15	15	1	4
16	12	1	4
17	14	1	4
18	17	1	4
19	20	1	4
20	19	1	4
21	16	1	4
22	22	1	5
23	23	1	5
24	24	1	6
25	25	1	6
26	30	1	6
27	29	1	6
28	26	1	6
29	27	1	6
30	28	1	6
31	31	1	6
32	32	1	6
33	34	1	7
34	33	1	7
35	36	1	8
36	35	1	8
38	38	1	9
39	39	1	10
40	40	1	11
42	42	2	3
48	48	1	12
49	49	1	13
\.


--
-- Data for Name: up_roles; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_roles (id, document_id, name, description, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	hhqil5em58wl7t8dpgwrqh00	Authenticated	Default role given to authenticated user.	authenticated	2025-12-15 15:33:23.879	2025-12-18 15:47:08.667	2025-12-15 15:33:23.88	\N	\N	\N
2	uxtilgw99o8tq661aka4shrf	Public	Default role given to unauthenticated user.	public	2025-12-15 15:33:23.891	2025-12-18 15:51:12.234	2025-12-15 15:33:23.893	\N	\N	\N
\.


--
-- Data for Name: up_users; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_users (id, document_id, username, email, provider, password, reset_password_token, confirmation_token, confirmed, blocked, age, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
9	ke14ybdpu1cg2bb2rg4c9ru8	Skycun	ledanoisb@gmail.com	local	$2a$10$YgqKtTU.lPolmninK9OJ6u8qHyjvuPuLe3cJY1AWp8A9skxkvynpa	\N	\N	t	f	\N	2025-12-29 01:30:11.903	2025-12-29 01:30:11.903	2025-12-29 01:30:11.906	\N	\N	\N
\.


--
-- Data for Name: up_users_guild_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_users_guild_lnk (id, user_id, guild_id) FROM stdin;
\.


--
-- Data for Name: up_users_role_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.up_users_role_lnk (id, user_id, role_id, user_ord) FROM stdin;
9	9	1	1
\.


--
-- Data for Name: upload_folders; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.upload_folders (id, document_id, name, path_id, path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	hdk1wd0z4l22o13u01kuc7ik	weapons	1	/1	2025-12-18 13:16:12.64	2025-12-18 13:16:12.64	2025-12-18 13:16:12.64	1	1	\N
2	egj4dfrvjrmbqbhdarbw5yyt	charms	2	/2	2025-12-18 13:16:18.338	2025-12-18 13:16:18.338	2025-12-18 13:16:18.338	1	1	\N
3	tn64grlczjsketem2keux8ty	helmets	3	/3	2025-12-18 13:16:31.349	2025-12-18 13:16:31.349	2025-12-18 13:16:31.35	1	1	\N
4	kvu7v9zi1pybuflpzi7nvsz3	icons	4	/4	2025-12-18 13:16:40.299	2025-12-18 13:16:40.299	2025-12-18 13:16:40.299	1	1	\N
5	ggq58gul6yd0wronctrnj5vo	characters	5	/5	2025-12-18 13:16:44.022	2025-12-18 13:16:44.022	2025-12-18 13:16:44.022	1	1	\N
\.


--
-- Data for Name: upload_folders_parent_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.upload_folders_parent_lnk (id, folder_id, inv_folder_id, folder_ord) FROM stdin;
\.


--
-- Data for Name: visits; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.visits (id, document_id, open_count, last_opened_at, total_gold_earned, total_exp_earned, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: visits_guild_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.visits_guild_lnk (id, visit_id, guild_id, visit_ord) FROM stdin;
\.


--
-- Data for Name: visits_poi_lnk; Type: TABLE DATA; Schema: public; Owner: strapi
--

COPY public.visits_poi_lnk (id, visit_id, poi_id, visit_ord) FROM stdin;
\.


--
-- Name: admin_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_permissions_id_seq', 258, true);


--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_permissions_role_lnk_id_seq', 258, true);


--
-- Name: admin_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_roles_id_seq', 3, true);


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 3, true);


--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.admin_users_roles_lnk_id_seq', 5, true);


--
-- Name: characters_guild_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.characters_guild_lnk_id_seq', 19, true);


--
-- Name: characters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.characters_id_seq', 15, true);


--
-- Name: dialogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.dialogs_id_seq', 21, true);


--
-- Name: dialogs_npc_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.dialogs_npc_lnk_id_seq', 38, true);


--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.files_folder_lnk_id_seq', 34, true);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.files_id_seq', 23, true);


--
-- Name: files_related_mph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.files_related_mph_id_seq', 63, true);


--
-- Name: friendships_guild_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.friendships_guild_lnk_id_seq', 1, false);


--
-- Name: friendships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.friendships_id_seq', 1, false);


--
-- Name: friendships_npc_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.friendships_npc_lnk_id_seq', 1, false);


--
-- Name: guilds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.guilds_id_seq', 10, true);


--
-- Name: guilds_user_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.guilds_user_lnk_id_seq', 7, true);


--
-- Name: i18n_locale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.i18n_locale_id_seq', 1, true);


--
-- Name: items_character_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.items_character_lnk_id_seq', 26, true);


--
-- Name: items_guild_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.items_guild_lnk_id_seq', 33, true);


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.items_id_seq', 35, true);


--
-- Name: items_rarity_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.items_rarity_lnk_id_seq', 18, true);


--
-- Name: items_runs_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.items_runs_lnk_id_seq', 1, false);


--
-- Name: items_tags_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.items_tags_lnk_id_seq', 24, true);


--
-- Name: items_visits_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.items_visits_lnk_id_seq', 1, false);


--
-- Name: museums_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.museums_id_seq', 18, true);


--
-- Name: museums_tags_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.museums_tags_lnk_id_seq', 47, true);


--
-- Name: npcs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.npcs_id_seq', 24, true);


--
-- Name: pois_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.pois_id_seq', 42, true);


--
-- Name: quests_guild_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.quests_guild_lnk_id_seq', 1, false);


--
-- Name: quests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.quests_id_seq', 1, false);


--
-- Name: quests_npc_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.quests_npc_lnk_id_seq', 1, false);


--
-- Name: quests_poi_a_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.quests_poi_a_lnk_id_seq', 1, false);


--
-- Name: quests_poi_b_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.quests_poi_b_lnk_id_seq', 1, false);


--
-- Name: rarities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.rarities_id_seq', 20, true);


--
-- Name: runs_guild_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.runs_guild_lnk_id_seq', 1, false);


--
-- Name: runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.runs_id_seq', 1, false);


--
-- Name: runs_museum_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.runs_museum_lnk_id_seq', 1, false);


--
-- Name: runs_npc_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.runs_npc_lnk_id_seq', 1, false);


--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_ai_localization_jobs_id_seq', 1, false);


--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_id_seq', 1, false);


--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_token_lnk_id_seq', 1, false);


--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_api_tokens_id_seq', 2, true);


--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_core_store_settings_id_seq', 41, true);


--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_database_schema_id_seq', 2, true);


--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_history_versions_id_seq', 1, false);


--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_migrations_id_seq', 1, false);


--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_migrations_internal_id_seq', 6, true);


--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_release_actions_id_seq', 1, false);


--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_release_actions_release_lnk_id_seq', 1, false);


--
-- Name: strapi_releases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_releases_id_seq', 1, false);


--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_sessions_id_seq', 21, true);


--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_id_seq', 1, false);


--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_token_lnk_id_seq', 1, false);


--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_transfer_tokens_id_seq', 1, false);


--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_webhooks_id_seq', 1, false);


--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_id_seq', 1, false);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_permissions_lnk_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_workflow_lnk_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.tags_id_seq', 33, true);


--
-- Name: up_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_permissions_id_seq', 49, true);


--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_permissions_role_lnk_id_seq', 49, true);


--
-- Name: up_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_roles_id_seq', 2, true);


--
-- Name: up_users_guild_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_users_guild_lnk_id_seq', 4, true);


--
-- Name: up_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_users_id_seq', 9, true);


--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.up_users_role_lnk_id_seq', 9, true);


--
-- Name: upload_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.upload_folders_id_seq', 5, true);


--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.upload_folders_parent_lnk_id_seq', 1, false);


--
-- Name: visits_guild_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.visits_guild_lnk_id_seq', 1, false);


--
-- Name: visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.visits_id_seq', 1, false);


--
-- Name: visits_poi_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: strapi
--

SELECT pg_catalog.setval('public.visits_poi_lnk_id_seq', 1, false);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: admin_roles admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: characters_guild_lnk characters_guild_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.characters_guild_lnk
    ADD CONSTRAINT characters_guild_lnk_pkey PRIMARY KEY (id);


--
-- Name: characters_guild_lnk characters_guild_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.characters_guild_lnk
    ADD CONSTRAINT characters_guild_lnk_uq UNIQUE (character_id, guild_id);


--
-- Name: characters characters_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.characters
    ADD CONSTRAINT characters_pkey PRIMARY KEY (id);


--
-- Name: dialogs_npc_lnk dialogs_npc_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.dialogs_npc_lnk
    ADD CONSTRAINT dialogs_npc_lnk_pkey PRIMARY KEY (id);


--
-- Name: dialogs_npc_lnk dialogs_npc_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.dialogs_npc_lnk
    ADD CONSTRAINT dialogs_npc_lnk_uq UNIQUE (dialog_id, npc_id);


--
-- Name: dialogs dialogs_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.dialogs
    ADD CONSTRAINT dialogs_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_uq UNIQUE (file_id, folder_id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: files_related_mph files_related_mph_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_pkey PRIMARY KEY (id);


--
-- Name: friendships_guild_lnk friendships_guild_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_guild_lnk
    ADD CONSTRAINT friendships_guild_lnk_pkey PRIMARY KEY (id);


--
-- Name: friendships_guild_lnk friendships_guild_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_guild_lnk
    ADD CONSTRAINT friendships_guild_lnk_uq UNIQUE (friendship_id, guild_id);


--
-- Name: friendships_npc_lnk friendships_npc_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_npc_lnk
    ADD CONSTRAINT friendships_npc_lnk_pkey PRIMARY KEY (id);


--
-- Name: friendships_npc_lnk friendships_npc_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_npc_lnk
    ADD CONSTRAINT friendships_npc_lnk_uq UNIQUE (friendship_id, npc_id);


--
-- Name: friendships friendships_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_pkey PRIMARY KEY (id);


--
-- Name: guilds guilds_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.guilds
    ADD CONSTRAINT guilds_pkey PRIMARY KEY (id);


--
-- Name: guilds_user_lnk guilds_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.guilds_user_lnk
    ADD CONSTRAINT guilds_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: guilds_user_lnk guilds_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.guilds_user_lnk
    ADD CONSTRAINT guilds_user_lnk_uq UNIQUE (guild_id, user_id);


--
-- Name: i18n_locale i18n_locale_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_pkey PRIMARY KEY (id);


--
-- Name: items_character_lnk items_character_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_character_lnk
    ADD CONSTRAINT items_character_lnk_pkey PRIMARY KEY (id);


--
-- Name: items_character_lnk items_character_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_character_lnk
    ADD CONSTRAINT items_character_lnk_uq UNIQUE (item_id, character_id);


--
-- Name: items_guild_lnk items_guild_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_guild_lnk
    ADD CONSTRAINT items_guild_lnk_pkey PRIMARY KEY (id);


--
-- Name: items_guild_lnk items_guild_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_guild_lnk
    ADD CONSTRAINT items_guild_lnk_uq UNIQUE (item_id, guild_id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: items_rarity_lnk items_rarity_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_rarity_lnk
    ADD CONSTRAINT items_rarity_lnk_pkey PRIMARY KEY (id);


--
-- Name: items_rarity_lnk items_rarity_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_rarity_lnk
    ADD CONSTRAINT items_rarity_lnk_uq UNIQUE (item_id, rarity_id);


--
-- Name: items_runs_lnk items_runs_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_runs_lnk
    ADD CONSTRAINT items_runs_lnk_pkey PRIMARY KEY (id);


--
-- Name: items_runs_lnk items_runs_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_runs_lnk
    ADD CONSTRAINT items_runs_lnk_uq UNIQUE (item_id, run_id);


--
-- Name: items_tags_lnk items_tags_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_tags_lnk
    ADD CONSTRAINT items_tags_lnk_pkey PRIMARY KEY (id);


--
-- Name: items_tags_lnk items_tags_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_tags_lnk
    ADD CONSTRAINT items_tags_lnk_uq UNIQUE (item_id, tag_id);


--
-- Name: items_visits_lnk items_visits_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_visits_lnk
    ADD CONSTRAINT items_visits_lnk_pkey PRIMARY KEY (id);


--
-- Name: items_visits_lnk items_visits_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_visits_lnk
    ADD CONSTRAINT items_visits_lnk_uq UNIQUE (item_id, visit_id);


--
-- Name: museums museums_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.museums
    ADD CONSTRAINT museums_pkey PRIMARY KEY (id);


--
-- Name: museums_tags_lnk museums_tags_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.museums_tags_lnk
    ADD CONSTRAINT museums_tags_lnk_pkey PRIMARY KEY (id);


--
-- Name: museums_tags_lnk museums_tags_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.museums_tags_lnk
    ADD CONSTRAINT museums_tags_lnk_uq UNIQUE (museum_id, tag_id);


--
-- Name: npcs npcs_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.npcs
    ADD CONSTRAINT npcs_pkey PRIMARY KEY (id);


--
-- Name: pois pois_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.pois
    ADD CONSTRAINT pois_pkey PRIMARY KEY (id);


--
-- Name: quests_guild_lnk quests_guild_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_guild_lnk
    ADD CONSTRAINT quests_guild_lnk_pkey PRIMARY KEY (id);


--
-- Name: quests_guild_lnk quests_guild_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_guild_lnk
    ADD CONSTRAINT quests_guild_lnk_uq UNIQUE (quest_id, guild_id);


--
-- Name: quests_npc_lnk quests_npc_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_npc_lnk
    ADD CONSTRAINT quests_npc_lnk_pkey PRIMARY KEY (id);


--
-- Name: quests_npc_lnk quests_npc_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_npc_lnk
    ADD CONSTRAINT quests_npc_lnk_uq UNIQUE (quest_id, npc_id);


--
-- Name: quests quests_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests
    ADD CONSTRAINT quests_pkey PRIMARY KEY (id);


--
-- Name: quests_poi_a_lnk quests_poi_a_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_a_lnk
    ADD CONSTRAINT quests_poi_a_lnk_pkey PRIMARY KEY (id);


--
-- Name: quests_poi_a_lnk quests_poi_a_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_a_lnk
    ADD CONSTRAINT quests_poi_a_lnk_uq UNIQUE (quest_id, poi_id);


--
-- Name: quests_poi_b_lnk quests_poi_b_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_b_lnk
    ADD CONSTRAINT quests_poi_b_lnk_pkey PRIMARY KEY (id);


--
-- Name: quests_poi_b_lnk quests_poi_b_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_b_lnk
    ADD CONSTRAINT quests_poi_b_lnk_uq UNIQUE (quest_id, poi_id);


--
-- Name: rarities rarities_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.rarities
    ADD CONSTRAINT rarities_pkey PRIMARY KEY (id);


--
-- Name: runs_guild_lnk runs_guild_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_guild_lnk
    ADD CONSTRAINT runs_guild_lnk_pkey PRIMARY KEY (id);


--
-- Name: runs_guild_lnk runs_guild_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_guild_lnk
    ADD CONSTRAINT runs_guild_lnk_uq UNIQUE (run_id, guild_id);


--
-- Name: runs_museum_lnk runs_museum_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_museum_lnk
    ADD CONSTRAINT runs_museum_lnk_pkey PRIMARY KEY (id);


--
-- Name: runs_museum_lnk runs_museum_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_museum_lnk
    ADD CONSTRAINT runs_museum_lnk_uq UNIQUE (run_id, museum_id);


--
-- Name: runs_npc_lnk runs_npc_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_npc_lnk
    ADD CONSTRAINT runs_npc_lnk_pkey PRIMARY KEY (id);


--
-- Name: runs_npc_lnk runs_npc_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_npc_lnk
    ADD CONSTRAINT runs_npc_lnk_uq UNIQUE (run_id, npc_id);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (id);


--
-- Name: strapi_ai_localization_jobs strapi_ai_localization_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs
    ADD CONSTRAINT strapi_ai_localization_jobs_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_uq UNIQUE (api_token_permission_id, api_token_id);


--
-- Name: strapi_api_tokens strapi_api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_core_store_settings strapi_core_store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_core_store_settings
    ADD CONSTRAINT strapi_core_store_settings_pkey PRIMARY KEY (id);


--
-- Name: strapi_database_schema strapi_database_schema_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_database_schema
    ADD CONSTRAINT strapi_database_schema_pkey PRIMARY KEY (id);


--
-- Name: strapi_history_versions strapi_history_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations_internal strapi_migrations_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_migrations_internal
    ADD CONSTRAINT strapi_migrations_internal_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations strapi_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_migrations
    ADD CONSTRAINT strapi_migrations_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions strapi_release_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_uq UNIQUE (release_action_id, release_id);


--
-- Name: strapi_releases strapi_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_pkey PRIMARY KEY (id);


--
-- Name: strapi_sessions strapi_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_uq UNIQUE (transfer_token_permission_id, transfer_token_id);


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_webhooks strapi_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_webhooks
    ADD CONSTRAINT strapi_webhooks_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows strapi_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_uq UNIQUE (workflow_id, workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_uq UNIQUE (workflow_stage_id, permission_id);


--
-- Name: strapi_workflows_stages strapi_workflows_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_uq UNIQUE (workflow_stage_id, workflow_id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: up_permissions up_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: up_roles up_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_pkey PRIMARY KEY (id);


--
-- Name: up_users_guild_lnk up_users_guild_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_guild_lnk
    ADD CONSTRAINT up_users_guild_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_users_guild_lnk up_users_guild_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_guild_lnk
    ADD CONSTRAINT up_users_guild_lnk_uq UNIQUE (user_id, guild_id);


--
-- Name: up_users up_users_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_pkey PRIMARY KEY (id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_uq UNIQUE (folder_id, inv_folder_id);


--
-- Name: upload_folders upload_folders_path_id_index; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_id_index UNIQUE (path_id);


--
-- Name: upload_folders upload_folders_path_index; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_index UNIQUE (path);


--
-- Name: upload_folders upload_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_pkey PRIMARY KEY (id);


--
-- Name: visits_guild_lnk visits_guild_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_guild_lnk
    ADD CONSTRAINT visits_guild_lnk_pkey PRIMARY KEY (id);


--
-- Name: visits_guild_lnk visits_guild_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_guild_lnk
    ADD CONSTRAINT visits_guild_lnk_uq UNIQUE (visit_id, guild_id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: visits_poi_lnk visits_poi_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_poi_lnk
    ADD CONSTRAINT visits_poi_lnk_pkey PRIMARY KEY (id);


--
-- Name: visits_poi_lnk visits_poi_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_poi_lnk
    ADD CONSTRAINT visits_poi_lnk_uq UNIQUE (visit_id, poi_id);


--
-- Name: admin_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_created_by_id_fk ON public.admin_permissions USING btree (created_by_id);


--
-- Name: admin_permissions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_documents_idx ON public.admin_permissions USING btree (document_id, locale, published_at);


--
-- Name: admin_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_role_lnk_fk ON public.admin_permissions_role_lnk USING btree (permission_id);


--
-- Name: admin_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_role_lnk_ifk ON public.admin_permissions_role_lnk USING btree (role_id);


--
-- Name: admin_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_role_lnk_oifk ON public.admin_permissions_role_lnk USING btree (permission_ord);


--
-- Name: admin_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_permissions_updated_by_id_fk ON public.admin_permissions USING btree (updated_by_id);


--
-- Name: admin_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_roles_created_by_id_fk ON public.admin_roles USING btree (created_by_id);


--
-- Name: admin_roles_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_roles_documents_idx ON public.admin_roles USING btree (document_id, locale, published_at);


--
-- Name: admin_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_roles_updated_by_id_fk ON public.admin_roles USING btree (updated_by_id);


--
-- Name: admin_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_created_by_id_fk ON public.admin_users USING btree (created_by_id);


--
-- Name: admin_users_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_documents_idx ON public.admin_users USING btree (document_id, locale, published_at);


--
-- Name: admin_users_roles_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_roles_lnk_fk ON public.admin_users_roles_lnk USING btree (user_id);


--
-- Name: admin_users_roles_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_roles_lnk_ifk ON public.admin_users_roles_lnk USING btree (role_id);


--
-- Name: admin_users_roles_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_roles_lnk_ofk ON public.admin_users_roles_lnk USING btree (role_ord);


--
-- Name: admin_users_roles_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_roles_lnk_oifk ON public.admin_users_roles_lnk USING btree (user_ord);


--
-- Name: admin_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX admin_users_updated_by_id_fk ON public.admin_users USING btree (updated_by_id);


--
-- Name: characters_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX characters_created_by_id_fk ON public.characters USING btree (created_by_id);


--
-- Name: characters_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX characters_documents_idx ON public.characters USING btree (document_id, locale, published_at);


--
-- Name: characters_guild_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX characters_guild_lnk_fk ON public.characters_guild_lnk USING btree (character_id);


--
-- Name: characters_guild_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX characters_guild_lnk_ifk ON public.characters_guild_lnk USING btree (guild_id);


--
-- Name: characters_guild_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX characters_guild_lnk_oifk ON public.characters_guild_lnk USING btree (character_ord);


--
-- Name: characters_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX characters_updated_by_id_fk ON public.characters USING btree (updated_by_id);


--
-- Name: dialogs_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX dialogs_created_by_id_fk ON public.dialogs USING btree (created_by_id);


--
-- Name: dialogs_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX dialogs_documents_idx ON public.dialogs USING btree (document_id, locale, published_at);


--
-- Name: dialogs_npc_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX dialogs_npc_lnk_fk ON public.dialogs_npc_lnk USING btree (dialog_id);


--
-- Name: dialogs_npc_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX dialogs_npc_lnk_ifk ON public.dialogs_npc_lnk USING btree (npc_id);


--
-- Name: dialogs_npc_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX dialogs_npc_lnk_oifk ON public.dialogs_npc_lnk USING btree (dialog_ord);


--
-- Name: dialogs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX dialogs_updated_by_id_fk ON public.dialogs USING btree (updated_by_id);


--
-- Name: files_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_created_by_id_fk ON public.files USING btree (created_by_id);


--
-- Name: files_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_documents_idx ON public.files USING btree (document_id, locale, published_at);


--
-- Name: files_folder_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_folder_lnk_fk ON public.files_folder_lnk USING btree (file_id);


--
-- Name: files_folder_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_folder_lnk_ifk ON public.files_folder_lnk USING btree (folder_id);


--
-- Name: files_folder_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_folder_lnk_oifk ON public.files_folder_lnk USING btree (file_ord);


--
-- Name: files_related_mph_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_related_mph_fk ON public.files_related_mph USING btree (file_id);


--
-- Name: files_related_mph_idix; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_related_mph_idix ON public.files_related_mph USING btree (related_id);


--
-- Name: files_related_mph_oidx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_related_mph_oidx ON public.files_related_mph USING btree ("order");


--
-- Name: files_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX files_updated_by_id_fk ON public.files USING btree (updated_by_id);


--
-- Name: friendships_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX friendships_created_by_id_fk ON public.friendships USING btree (created_by_id);


--
-- Name: friendships_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX friendships_documents_idx ON public.friendships USING btree (document_id, locale, published_at);


--
-- Name: friendships_guild_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX friendships_guild_lnk_fk ON public.friendships_guild_lnk USING btree (friendship_id);


--
-- Name: friendships_guild_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX friendships_guild_lnk_ifk ON public.friendships_guild_lnk USING btree (guild_id);


--
-- Name: friendships_guild_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX friendships_guild_lnk_oifk ON public.friendships_guild_lnk USING btree (friendship_ord);


--
-- Name: friendships_npc_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX friendships_npc_lnk_fk ON public.friendships_npc_lnk USING btree (friendship_id);


--
-- Name: friendships_npc_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX friendships_npc_lnk_ifk ON public.friendships_npc_lnk USING btree (npc_id);


--
-- Name: friendships_npc_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX friendships_npc_lnk_oifk ON public.friendships_npc_lnk USING btree (friendship_ord);


--
-- Name: friendships_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX friendships_updated_by_id_fk ON public.friendships USING btree (updated_by_id);


--
-- Name: guilds_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX guilds_created_by_id_fk ON public.guilds USING btree (created_by_id);


--
-- Name: guilds_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX guilds_documents_idx ON public.guilds USING btree (document_id, locale, published_at);


--
-- Name: guilds_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX guilds_updated_by_id_fk ON public.guilds USING btree (updated_by_id);


--
-- Name: guilds_user_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX guilds_user_lnk_fk ON public.guilds_user_lnk USING btree (guild_id);


--
-- Name: guilds_user_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX guilds_user_lnk_ifk ON public.guilds_user_lnk USING btree (user_id);


--
-- Name: i18n_locale_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX i18n_locale_created_by_id_fk ON public.i18n_locale USING btree (created_by_id);


--
-- Name: i18n_locale_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX i18n_locale_documents_idx ON public.i18n_locale USING btree (document_id, locale, published_at);


--
-- Name: i18n_locale_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX i18n_locale_updated_by_id_fk ON public.i18n_locale USING btree (updated_by_id);


--
-- Name: items_character_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_character_lnk_fk ON public.items_character_lnk USING btree (item_id);


--
-- Name: items_character_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_character_lnk_ifk ON public.items_character_lnk USING btree (character_id);


--
-- Name: items_character_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_character_lnk_oifk ON public.items_character_lnk USING btree (item_ord);


--
-- Name: items_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_created_by_id_fk ON public.items USING btree (created_by_id);


--
-- Name: items_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_documents_idx ON public.items USING btree (document_id, locale, published_at);


--
-- Name: items_guild_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_guild_lnk_fk ON public.items_guild_lnk USING btree (item_id);


--
-- Name: items_guild_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_guild_lnk_ifk ON public.items_guild_lnk USING btree (guild_id);


--
-- Name: items_guild_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_guild_lnk_oifk ON public.items_guild_lnk USING btree (item_ord);


--
-- Name: items_rarity_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_rarity_lnk_fk ON public.items_rarity_lnk USING btree (item_id);


--
-- Name: items_rarity_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_rarity_lnk_ifk ON public.items_rarity_lnk USING btree (rarity_id);


--
-- Name: items_rarity_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_rarity_lnk_oifk ON public.items_rarity_lnk USING btree (item_ord);


--
-- Name: items_runs_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_runs_lnk_fk ON public.items_runs_lnk USING btree (item_id);


--
-- Name: items_runs_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_runs_lnk_ifk ON public.items_runs_lnk USING btree (run_id);


--
-- Name: items_runs_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_runs_lnk_ofk ON public.items_runs_lnk USING btree (run_ord);


--
-- Name: items_runs_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_runs_lnk_oifk ON public.items_runs_lnk USING btree (item_ord);


--
-- Name: items_tags_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_tags_lnk_fk ON public.items_tags_lnk USING btree (item_id);


--
-- Name: items_tags_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_tags_lnk_ifk ON public.items_tags_lnk USING btree (tag_id);


--
-- Name: items_tags_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_tags_lnk_ofk ON public.items_tags_lnk USING btree (tag_ord);


--
-- Name: items_tags_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_tags_lnk_oifk ON public.items_tags_lnk USING btree (item_ord);


--
-- Name: items_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_updated_by_id_fk ON public.items USING btree (updated_by_id);


--
-- Name: items_visits_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_visits_lnk_fk ON public.items_visits_lnk USING btree (item_id);


--
-- Name: items_visits_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_visits_lnk_ifk ON public.items_visits_lnk USING btree (visit_id);


--
-- Name: items_visits_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_visits_lnk_ofk ON public.items_visits_lnk USING btree (visit_ord);


--
-- Name: items_visits_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX items_visits_lnk_oifk ON public.items_visits_lnk USING btree (item_ord);


--
-- Name: museums_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX museums_created_by_id_fk ON public.museums USING btree (created_by_id);


--
-- Name: museums_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX museums_documents_idx ON public.museums USING btree (document_id, locale, published_at);


--
-- Name: museums_tags_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX museums_tags_lnk_fk ON public.museums_tags_lnk USING btree (museum_id);


--
-- Name: museums_tags_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX museums_tags_lnk_ifk ON public.museums_tags_lnk USING btree (tag_id);


--
-- Name: museums_tags_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX museums_tags_lnk_ofk ON public.museums_tags_lnk USING btree (tag_ord);


--
-- Name: museums_tags_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX museums_tags_lnk_oifk ON public.museums_tags_lnk USING btree (museum_ord);


--
-- Name: museums_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX museums_updated_by_id_fk ON public.museums USING btree (updated_by_id);


--
-- Name: npcs_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX npcs_created_by_id_fk ON public.npcs USING btree (created_by_id);


--
-- Name: npcs_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX npcs_documents_idx ON public.npcs USING btree (document_id, locale, published_at);


--
-- Name: npcs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX npcs_updated_by_id_fk ON public.npcs USING btree (updated_by_id);


--
-- Name: pois_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX pois_created_by_id_fk ON public.pois USING btree (created_by_id);


--
-- Name: pois_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX pois_documents_idx ON public.pois USING btree (document_id, locale, published_at);


--
-- Name: pois_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX pois_updated_by_id_fk ON public.pois USING btree (updated_by_id);


--
-- Name: quests_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_created_by_id_fk ON public.quests USING btree (created_by_id);


--
-- Name: quests_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_documents_idx ON public.quests USING btree (document_id, locale, published_at);


--
-- Name: quests_guild_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_guild_lnk_fk ON public.quests_guild_lnk USING btree (quest_id);


--
-- Name: quests_guild_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_guild_lnk_ifk ON public.quests_guild_lnk USING btree (guild_id);


--
-- Name: quests_guild_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_guild_lnk_oifk ON public.quests_guild_lnk USING btree (quest_ord);


--
-- Name: quests_npc_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_npc_lnk_fk ON public.quests_npc_lnk USING btree (quest_id);


--
-- Name: quests_npc_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_npc_lnk_ifk ON public.quests_npc_lnk USING btree (npc_id);


--
-- Name: quests_npc_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_npc_lnk_oifk ON public.quests_npc_lnk USING btree (quest_ord);


--
-- Name: quests_poi_a_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_poi_a_lnk_fk ON public.quests_poi_a_lnk USING btree (quest_id);


--
-- Name: quests_poi_a_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_poi_a_lnk_ifk ON public.quests_poi_a_lnk USING btree (poi_id);


--
-- Name: quests_poi_a_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_poi_a_lnk_oifk ON public.quests_poi_a_lnk USING btree (quest_ord);


--
-- Name: quests_poi_b_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_poi_b_lnk_fk ON public.quests_poi_b_lnk USING btree (quest_id);


--
-- Name: quests_poi_b_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_poi_b_lnk_ifk ON public.quests_poi_b_lnk USING btree (poi_id);


--
-- Name: quests_poi_b_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_poi_b_lnk_oifk ON public.quests_poi_b_lnk USING btree (quest_ord);


--
-- Name: quests_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX quests_updated_by_id_fk ON public.quests USING btree (updated_by_id);


--
-- Name: rarities_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX rarities_created_by_id_fk ON public.rarities USING btree (created_by_id);


--
-- Name: rarities_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX rarities_documents_idx ON public.rarities USING btree (document_id, locale, published_at);


--
-- Name: rarities_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX rarities_updated_by_id_fk ON public.rarities USING btree (updated_by_id);


--
-- Name: runs_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_created_by_id_fk ON public.runs USING btree (created_by_id);


--
-- Name: runs_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_documents_idx ON public.runs USING btree (document_id, locale, published_at);


--
-- Name: runs_guild_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_guild_lnk_fk ON public.runs_guild_lnk USING btree (run_id);


--
-- Name: runs_guild_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_guild_lnk_ifk ON public.runs_guild_lnk USING btree (guild_id);


--
-- Name: runs_guild_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_guild_lnk_oifk ON public.runs_guild_lnk USING btree (run_ord);


--
-- Name: runs_museum_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_museum_lnk_fk ON public.runs_museum_lnk USING btree (run_id);


--
-- Name: runs_museum_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_museum_lnk_ifk ON public.runs_museum_lnk USING btree (museum_id);


--
-- Name: runs_museum_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_museum_lnk_oifk ON public.runs_museum_lnk USING btree (run_ord);


--
-- Name: runs_npc_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_npc_lnk_fk ON public.runs_npc_lnk USING btree (run_id);


--
-- Name: runs_npc_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_npc_lnk_ifk ON public.runs_npc_lnk USING btree (npc_id);


--
-- Name: runs_npc_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_npc_lnk_oifk ON public.runs_npc_lnk USING btree (run_ord);


--
-- Name: runs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX runs_updated_by_id_fk ON public.runs USING btree (updated_by_id);


--
-- Name: strapi_api_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_created_by_id_fk ON public.strapi_api_token_permissions USING btree (created_by_id);


--
-- Name: strapi_api_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_documents_idx ON public.strapi_api_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_token_lnk_fk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_id);


--
-- Name: strapi_api_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_token_lnk_ifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_id);


--
-- Name: strapi_api_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_token_lnk_oifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_ord);


--
-- Name: strapi_api_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_token_permissions_updated_by_id_fk ON public.strapi_api_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_api_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_tokens_created_by_id_fk ON public.strapi_api_tokens USING btree (created_by_id);


--
-- Name: strapi_api_tokens_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_tokens_documents_idx ON public.strapi_api_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_api_tokens_updated_by_id_fk ON public.strapi_api_tokens USING btree (updated_by_id);


--
-- Name: strapi_history_versions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_history_versions_created_by_id_fk ON public.strapi_history_versions USING btree (created_by_id);


--
-- Name: strapi_release_actions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_created_by_id_fk ON public.strapi_release_actions USING btree (created_by_id);


--
-- Name: strapi_release_actions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_documents_idx ON public.strapi_release_actions USING btree (document_id, locale, published_at);


--
-- Name: strapi_release_actions_release_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_release_lnk_fk ON public.strapi_release_actions_release_lnk USING btree (release_action_id);


--
-- Name: strapi_release_actions_release_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_release_lnk_ifk ON public.strapi_release_actions_release_lnk USING btree (release_id);


--
-- Name: strapi_release_actions_release_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_release_lnk_oifk ON public.strapi_release_actions_release_lnk USING btree (release_action_ord);


--
-- Name: strapi_release_actions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_release_actions_updated_by_id_fk ON public.strapi_release_actions USING btree (updated_by_id);


--
-- Name: strapi_releases_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_releases_created_by_id_fk ON public.strapi_releases USING btree (created_by_id);


--
-- Name: strapi_releases_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_releases_documents_idx ON public.strapi_releases USING btree (document_id, locale, published_at);


--
-- Name: strapi_releases_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_releases_updated_by_id_fk ON public.strapi_releases USING btree (updated_by_id);


--
-- Name: strapi_sessions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_sessions_created_by_id_fk ON public.strapi_sessions USING btree (created_by_id);


--
-- Name: strapi_sessions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_sessions_documents_idx ON public.strapi_sessions USING btree (document_id, locale, published_at);


--
-- Name: strapi_sessions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_sessions_updated_by_id_fk ON public.strapi_sessions USING btree (updated_by_id);


--
-- Name: strapi_transfer_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_created_by_id_fk ON public.strapi_transfer_token_permissions USING btree (created_by_id);


--
-- Name: strapi_transfer_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_documents_idx ON public.strapi_transfer_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_fk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_ifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_oifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_ord);


--
-- Name: strapi_transfer_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_token_permissions_updated_by_id_fk ON public.strapi_transfer_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_transfer_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_tokens_created_by_id_fk ON public.strapi_transfer_tokens USING btree (created_by_id);


--
-- Name: strapi_transfer_tokens_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_tokens_documents_idx ON public.strapi_transfer_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_transfer_tokens_updated_by_id_fk ON public.strapi_transfer_tokens USING btree (updated_by_id);


--
-- Name: strapi_workflows_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_created_by_id_fk ON public.strapi_workflows USING btree (created_by_id);


--
-- Name: strapi_workflows_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_documents_idx ON public.strapi_workflows USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_fk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_ifk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_created_by_id_fk ON public.strapi_workflows_stages USING btree (created_by_id);


--
-- Name: strapi_workflows_stages_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_documents_idx ON public.strapi_workflows_stages USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stages_permissions_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_fk ON public.strapi_workflows_stages_permissions_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ifk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ofk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ofk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_ord);


--
-- Name: strapi_workflows_stages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_updated_by_id_fk ON public.strapi_workflows_stages USING btree (updated_by_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_fk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_ifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_oifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_ord);


--
-- Name: strapi_workflows_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX strapi_workflows_updated_by_id_fk ON public.strapi_workflows USING btree (updated_by_id);


--
-- Name: tags_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX tags_created_by_id_fk ON public.tags USING btree (created_by_id);


--
-- Name: tags_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX tags_documents_idx ON public.tags USING btree (document_id, locale, published_at);


--
-- Name: tags_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX tags_updated_by_id_fk ON public.tags USING btree (updated_by_id);


--
-- Name: up_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_created_by_id_fk ON public.up_permissions USING btree (created_by_id);


--
-- Name: up_permissions_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_documents_idx ON public.up_permissions USING btree (document_id, locale, published_at);


--
-- Name: up_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_role_lnk_fk ON public.up_permissions_role_lnk USING btree (permission_id);


--
-- Name: up_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_role_lnk_ifk ON public.up_permissions_role_lnk USING btree (role_id);


--
-- Name: up_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_role_lnk_oifk ON public.up_permissions_role_lnk USING btree (permission_ord);


--
-- Name: up_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_permissions_updated_by_id_fk ON public.up_permissions USING btree (updated_by_id);


--
-- Name: up_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_roles_created_by_id_fk ON public.up_roles USING btree (created_by_id);


--
-- Name: up_roles_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_roles_documents_idx ON public.up_roles USING btree (document_id, locale, published_at);


--
-- Name: up_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_roles_updated_by_id_fk ON public.up_roles USING btree (updated_by_id);


--
-- Name: up_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_created_by_id_fk ON public.up_users USING btree (created_by_id);


--
-- Name: up_users_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_documents_idx ON public.up_users USING btree (document_id, locale, published_at);


--
-- Name: up_users_guild_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_guild_lnk_fk ON public.up_users_guild_lnk USING btree (user_id);


--
-- Name: up_users_guild_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_guild_lnk_ifk ON public.up_users_guild_lnk USING btree (guild_id);


--
-- Name: up_users_role_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_role_lnk_fk ON public.up_users_role_lnk USING btree (user_id);


--
-- Name: up_users_role_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_role_lnk_ifk ON public.up_users_role_lnk USING btree (role_id);


--
-- Name: up_users_role_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_role_lnk_oifk ON public.up_users_role_lnk USING btree (user_ord);


--
-- Name: up_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX up_users_updated_by_id_fk ON public.up_users USING btree (updated_by_id);


--
-- Name: upload_files_created_at_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_created_at_index ON public.files USING btree (created_at);


--
-- Name: upload_files_ext_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_ext_index ON public.files USING btree (ext);


--
-- Name: upload_files_folder_path_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_folder_path_index ON public.files USING btree (folder_path);


--
-- Name: upload_files_name_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_name_index ON public.files USING btree (name);


--
-- Name: upload_files_size_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_size_index ON public.files USING btree (size);


--
-- Name: upload_files_updated_at_index; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_files_updated_at_index ON public.files USING btree (updated_at);


--
-- Name: upload_folders_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_created_by_id_fk ON public.upload_folders USING btree (created_by_id);


--
-- Name: upload_folders_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_documents_idx ON public.upload_folders USING btree (document_id, locale, published_at);


--
-- Name: upload_folders_parent_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_parent_lnk_fk ON public.upload_folders_parent_lnk USING btree (folder_id);


--
-- Name: upload_folders_parent_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_parent_lnk_ifk ON public.upload_folders_parent_lnk USING btree (inv_folder_id);


--
-- Name: upload_folders_parent_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_parent_lnk_oifk ON public.upload_folders_parent_lnk USING btree (folder_ord);


--
-- Name: upload_folders_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX upload_folders_updated_by_id_fk ON public.upload_folders USING btree (updated_by_id);


--
-- Name: visits_created_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX visits_created_by_id_fk ON public.visits USING btree (created_by_id);


--
-- Name: visits_documents_idx; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX visits_documents_idx ON public.visits USING btree (document_id, locale, published_at);


--
-- Name: visits_guild_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX visits_guild_lnk_fk ON public.visits_guild_lnk USING btree (visit_id);


--
-- Name: visits_guild_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX visits_guild_lnk_ifk ON public.visits_guild_lnk USING btree (guild_id);


--
-- Name: visits_guild_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX visits_guild_lnk_oifk ON public.visits_guild_lnk USING btree (visit_ord);


--
-- Name: visits_poi_lnk_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX visits_poi_lnk_fk ON public.visits_poi_lnk USING btree (visit_id);


--
-- Name: visits_poi_lnk_ifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX visits_poi_lnk_ifk ON public.visits_poi_lnk USING btree (poi_id);


--
-- Name: visits_poi_lnk_oifk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX visits_poi_lnk_oifk ON public.visits_poi_lnk USING btree (visit_ord);


--
-- Name: visits_updated_by_id_fk; Type: INDEX; Schema: public; Owner: strapi
--

CREATE INDEX visits_updated_by_id_fk ON public.visits USING btree (updated_by_id);


--
-- Name: admin_permissions admin_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_permissions admin_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users admin_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_fk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE CASCADE;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_users admin_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: characters characters_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.characters
    ADD CONSTRAINT characters_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: characters_guild_lnk characters_guild_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.characters_guild_lnk
    ADD CONSTRAINT characters_guild_lnk_fk FOREIGN KEY (character_id) REFERENCES public.characters(id) ON DELETE CASCADE;


--
-- Name: characters_guild_lnk characters_guild_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.characters_guild_lnk
    ADD CONSTRAINT characters_guild_lnk_ifk FOREIGN KEY (guild_id) REFERENCES public.guilds(id) ON DELETE CASCADE;


--
-- Name: characters characters_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.characters
    ADD CONSTRAINT characters_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: dialogs dialogs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.dialogs
    ADD CONSTRAINT dialogs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: dialogs_npc_lnk dialogs_npc_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.dialogs_npc_lnk
    ADD CONSTRAINT dialogs_npc_lnk_fk FOREIGN KEY (dialog_id) REFERENCES public.dialogs(id) ON DELETE CASCADE;


--
-- Name: dialogs_npc_lnk dialogs_npc_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.dialogs_npc_lnk
    ADD CONSTRAINT dialogs_npc_lnk_ifk FOREIGN KEY (npc_id) REFERENCES public.npcs(id) ON DELETE CASCADE;


--
-- Name: dialogs dialogs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.dialogs
    ADD CONSTRAINT dialogs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: files files_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: files_folder_lnk files_folder_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files_folder_lnk files_folder_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_ifk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: files_related_mph files_related_mph_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files files_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: friendships friendships_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: friendships_guild_lnk friendships_guild_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_guild_lnk
    ADD CONSTRAINT friendships_guild_lnk_fk FOREIGN KEY (friendship_id) REFERENCES public.friendships(id) ON DELETE CASCADE;


--
-- Name: friendships_guild_lnk friendships_guild_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_guild_lnk
    ADD CONSTRAINT friendships_guild_lnk_ifk FOREIGN KEY (guild_id) REFERENCES public.guilds(id) ON DELETE CASCADE;


--
-- Name: friendships_npc_lnk friendships_npc_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_npc_lnk
    ADD CONSTRAINT friendships_npc_lnk_fk FOREIGN KEY (friendship_id) REFERENCES public.friendships(id) ON DELETE CASCADE;


--
-- Name: friendships_npc_lnk friendships_npc_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships_npc_lnk
    ADD CONSTRAINT friendships_npc_lnk_ifk FOREIGN KEY (npc_id) REFERENCES public.npcs(id) ON DELETE CASCADE;


--
-- Name: friendships friendships_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: guilds guilds_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.guilds
    ADD CONSTRAINT guilds_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: guilds guilds_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.guilds
    ADD CONSTRAINT guilds_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: guilds_user_lnk guilds_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.guilds_user_lnk
    ADD CONSTRAINT guilds_user_lnk_fk FOREIGN KEY (guild_id) REFERENCES public.guilds(id) ON DELETE CASCADE;


--
-- Name: guilds_user_lnk guilds_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.guilds_user_lnk
    ADD CONSTRAINT guilds_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: i18n_locale i18n_locale_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: i18n_locale i18n_locale_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: items_character_lnk items_character_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_character_lnk
    ADD CONSTRAINT items_character_lnk_fk FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: items_character_lnk items_character_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_character_lnk
    ADD CONSTRAINT items_character_lnk_ifk FOREIGN KEY (character_id) REFERENCES public.characters(id) ON DELETE CASCADE;


--
-- Name: items items_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: items_guild_lnk items_guild_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_guild_lnk
    ADD CONSTRAINT items_guild_lnk_fk FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: items_guild_lnk items_guild_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_guild_lnk
    ADD CONSTRAINT items_guild_lnk_ifk FOREIGN KEY (guild_id) REFERENCES public.guilds(id) ON DELETE CASCADE;


--
-- Name: items_rarity_lnk items_rarity_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_rarity_lnk
    ADD CONSTRAINT items_rarity_lnk_fk FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: items_rarity_lnk items_rarity_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_rarity_lnk
    ADD CONSTRAINT items_rarity_lnk_ifk FOREIGN KEY (rarity_id) REFERENCES public.rarities(id) ON DELETE CASCADE;


--
-- Name: items_runs_lnk items_runs_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_runs_lnk
    ADD CONSTRAINT items_runs_lnk_fk FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: items_runs_lnk items_runs_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_runs_lnk
    ADD CONSTRAINT items_runs_lnk_ifk FOREIGN KEY (run_id) REFERENCES public.runs(id) ON DELETE CASCADE;


--
-- Name: items_tags_lnk items_tags_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_tags_lnk
    ADD CONSTRAINT items_tags_lnk_fk FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: items_tags_lnk items_tags_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_tags_lnk
    ADD CONSTRAINT items_tags_lnk_ifk FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: items items_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: items_visits_lnk items_visits_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_visits_lnk
    ADD CONSTRAINT items_visits_lnk_fk FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: items_visits_lnk items_visits_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.items_visits_lnk
    ADD CONSTRAINT items_visits_lnk_ifk FOREIGN KEY (visit_id) REFERENCES public.visits(id) ON DELETE CASCADE;


--
-- Name: museums museums_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.museums
    ADD CONSTRAINT museums_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: museums_tags_lnk museums_tags_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.museums_tags_lnk
    ADD CONSTRAINT museums_tags_lnk_fk FOREIGN KEY (museum_id) REFERENCES public.museums(id) ON DELETE CASCADE;


--
-- Name: museums_tags_lnk museums_tags_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.museums_tags_lnk
    ADD CONSTRAINT museums_tags_lnk_ifk FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: museums museums_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.museums
    ADD CONSTRAINT museums_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: npcs npcs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.npcs
    ADD CONSTRAINT npcs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: npcs npcs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.npcs
    ADD CONSTRAINT npcs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pois pois_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.pois
    ADD CONSTRAINT pois_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pois pois_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.pois
    ADD CONSTRAINT pois_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: quests quests_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests
    ADD CONSTRAINT quests_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: quests_guild_lnk quests_guild_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_guild_lnk
    ADD CONSTRAINT quests_guild_lnk_fk FOREIGN KEY (quest_id) REFERENCES public.quests(id) ON DELETE CASCADE;


--
-- Name: quests_guild_lnk quests_guild_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_guild_lnk
    ADD CONSTRAINT quests_guild_lnk_ifk FOREIGN KEY (guild_id) REFERENCES public.guilds(id) ON DELETE CASCADE;


--
-- Name: quests_npc_lnk quests_npc_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_npc_lnk
    ADD CONSTRAINT quests_npc_lnk_fk FOREIGN KEY (quest_id) REFERENCES public.quests(id) ON DELETE CASCADE;


--
-- Name: quests_npc_lnk quests_npc_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_npc_lnk
    ADD CONSTRAINT quests_npc_lnk_ifk FOREIGN KEY (npc_id) REFERENCES public.npcs(id) ON DELETE CASCADE;


--
-- Name: quests_poi_a_lnk quests_poi_a_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_a_lnk
    ADD CONSTRAINT quests_poi_a_lnk_fk FOREIGN KEY (quest_id) REFERENCES public.quests(id) ON DELETE CASCADE;


--
-- Name: quests_poi_a_lnk quests_poi_a_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_a_lnk
    ADD CONSTRAINT quests_poi_a_lnk_ifk FOREIGN KEY (poi_id) REFERENCES public.pois(id) ON DELETE CASCADE;


--
-- Name: quests_poi_b_lnk quests_poi_b_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_b_lnk
    ADD CONSTRAINT quests_poi_b_lnk_fk FOREIGN KEY (quest_id) REFERENCES public.quests(id) ON DELETE CASCADE;


--
-- Name: quests_poi_b_lnk quests_poi_b_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests_poi_b_lnk
    ADD CONSTRAINT quests_poi_b_lnk_ifk FOREIGN KEY (poi_id) REFERENCES public.pois(id) ON DELETE CASCADE;


--
-- Name: quests quests_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.quests
    ADD CONSTRAINT quests_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: rarities rarities_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.rarities
    ADD CONSTRAINT rarities_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: rarities rarities_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.rarities
    ADD CONSTRAINT rarities_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: runs runs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: runs_guild_lnk runs_guild_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_guild_lnk
    ADD CONSTRAINT runs_guild_lnk_fk FOREIGN KEY (run_id) REFERENCES public.runs(id) ON DELETE CASCADE;


--
-- Name: runs_guild_lnk runs_guild_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_guild_lnk
    ADD CONSTRAINT runs_guild_lnk_ifk FOREIGN KEY (guild_id) REFERENCES public.guilds(id) ON DELETE CASCADE;


--
-- Name: runs_museum_lnk runs_museum_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_museum_lnk
    ADD CONSTRAINT runs_museum_lnk_fk FOREIGN KEY (run_id) REFERENCES public.runs(id) ON DELETE CASCADE;


--
-- Name: runs_museum_lnk runs_museum_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_museum_lnk
    ADD CONSTRAINT runs_museum_lnk_ifk FOREIGN KEY (museum_id) REFERENCES public.museums(id) ON DELETE CASCADE;


--
-- Name: runs_npc_lnk runs_npc_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_npc_lnk
    ADD CONSTRAINT runs_npc_lnk_fk FOREIGN KEY (run_id) REFERENCES public.runs(id) ON DELETE CASCADE;


--
-- Name: runs_npc_lnk runs_npc_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs_npc_lnk
    ADD CONSTRAINT runs_npc_lnk_ifk FOREIGN KEY (npc_id) REFERENCES public.npcs(id) ON DELETE CASCADE;


--
-- Name: runs runs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.runs
    ADD CONSTRAINT runs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_fk FOREIGN KEY (api_token_permission_id) REFERENCES public.strapi_api_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_ifk FOREIGN KEY (api_token_id) REFERENCES public.strapi_api_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens strapi_api_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens strapi_api_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_history_versions strapi_history_versions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions strapi_release_actions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_fk FOREIGN KEY (release_action_id) REFERENCES public.strapi_release_actions(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_ifk FOREIGN KEY (release_id) REFERENCES public.strapi_releases(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions strapi_release_actions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_fk FOREIGN KEY (transfer_token_permission_id) REFERENCES public.strapi_transfer_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_ifk FOREIGN KEY (transfer_token_id) REFERENCES public.strapi_transfer_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows strapi_workflows_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_fk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_ifk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_ifk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_ifk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows strapi_workflows_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: tags tags_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: tags tags_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions up_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.up_permissions(id) ON DELETE CASCADE;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_permissions up_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users up_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users_guild_lnk up_users_guild_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_guild_lnk
    ADD CONSTRAINT up_users_guild_lnk_fk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: up_users_guild_lnk up_users_guild_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_guild_lnk
    ADD CONSTRAINT up_users_guild_lnk_ifk FOREIGN KEY (guild_id) REFERENCES public.guilds(id) ON DELETE CASCADE;


--
-- Name: up_users_role_lnk up_users_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_fk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: up_users_role_lnk up_users_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_users up_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders upload_folders_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_fk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_ifk FOREIGN KEY (inv_folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders upload_folders_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: visits visits_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: visits_guild_lnk visits_guild_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_guild_lnk
    ADD CONSTRAINT visits_guild_lnk_fk FOREIGN KEY (visit_id) REFERENCES public.visits(id) ON DELETE CASCADE;


--
-- Name: visits_guild_lnk visits_guild_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_guild_lnk
    ADD CONSTRAINT visits_guild_lnk_ifk FOREIGN KEY (guild_id) REFERENCES public.guilds(id) ON DELETE CASCADE;


--
-- Name: visits_poi_lnk visits_poi_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_poi_lnk
    ADD CONSTRAINT visits_poi_lnk_fk FOREIGN KEY (visit_id) REFERENCES public.visits(id) ON DELETE CASCADE;


--
-- Name: visits_poi_lnk visits_poi_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits_poi_lnk
    ADD CONSTRAINT visits_poi_lnk_ifk FOREIGN KEY (poi_id) REFERENCES public.pois(id) ON DELETE CASCADE;


--
-- Name: visits visits_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: strapi
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 1Q6FpTmzVorBwVFNMr10zIIXpsCgrR9d8MNjDefQhcFeWj3schANdMJfTyEskkj

